const express = require('express');
const router = express.Router();

router.post('/upload', (req, res) => {
  // Dummy handler: simulate success response without actual file processing
  const { key, label, icon } = req.body;

  if (!key || !label || !icon) {
    return res.status(400).json({ message: 'Missing required fields' });
  }

  // Simulate a delay for async behavior
  setTimeout(() => {
    res.json({
      message: 'Dummy module upload successful',
      module: { key, label, icon },
    });
  }, 500);
});

module.exports = router;
