const express = require('express');
const multer = require('multer');
const unzipper = require('unzipper');
const fs = require('fs');
const path = require('path');

const router = express.Router();
const upload = multer({ dest: 'uploads/' });

router.post('/upload', upload.single('zipFile'), async (req, res) => {
  try {
    const { key, label, icon } = req.body;
    const zipFilePath = req.file.path;

    if (!key || !label || !icon || !zipFilePath) {
      return res.status(400).json({ message: 'Missing required fields' });
    }

    // Define the directory to extract files to
    const extractDir = path.join(__dirname, '../../modules', key);

    // Ensure the directory exists
    fs.mkdirSync(extractDir, { recursive: true });

    // Extract the zip file
    fs.createReadStream(zipFilePath)
      .pipe(unzipper.Extract({ path: extractDir }))
      .on('close', () => {
        // Delete the uploaded zip file after extraction
        fs.unlinkSync(zipFilePath);

        // TODO: Validate required files in extractDir if needed

        // Respond with module info
        res.json({
          message: 'Module uploaded and extracted successfully',
          module: { key, label, icon },
        });
      })
      .on('error', (err) => {
        fs.unlinkSync(zipFilePath);
        res.status(500).json({ message: 'Failed to extract zip file', error: err.message });
      });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

module.exports = router;
