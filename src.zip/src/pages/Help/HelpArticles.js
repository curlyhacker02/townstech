import React from "react"
import { Container, Row, Col, Card, CardHeader, CardBody } from "reactstrap"
import HelpSidebar from "./HelpSidebar"

const articles = [
  {
    id: 1,
    title: "How to get started",
    description: "A step-by-step guide to help you get started with our platform.",
  },
  {
    id: 2,
    title: "Managing your account",
    description: "Learn how to update your profile, change settings, and manage your account.",
  },
  {
    id: 3,
    title: "Billing and payments",
    description: "Information about billing cycles, payment methods, and invoices.",
  },
  {
    id: 4,
    title: "Troubleshooting common issues",
    description: "Solutions to common problems and how to get support.",
  },
]

const HelpArticles = () => {
  return (
    <Container fluid>
      <Row className="mb-4">
        <Col>
          <h4 className="page-title">Help Articles</h4>
        </Col>
      </Row>
      <Row>
        <Col md={3}>
          <HelpSidebar />
        </Col>
        <Col md={9}>
          {articles.map((article) => (
            <Card className="mb-3" key={article.id}>
              <CardHeader>{article.title}</CardHeader>
              <CardBody>
                <p>{article.description}</p>
              </CardBody>
            </Card>
          ))}
        </Col>
      </Row>
    </Container>
  )
}

export default HelpArticles
