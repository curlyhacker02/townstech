/* eslint-disable no-unused-vars */
import React, { useState } from "react"
import { Container, Row, Col, Card, CardHeader, CardBody, Input, InputGroup, InputGroupText } from "reactstrap"
import HelpSidebar from "./HelpSidebar"
import { FaQuestionCircle, FaBook, FaFolderOpen, FaClipboardList, FaTags } from "react-icons/fa"

const helpTopics = [
  {
    icon: <FaQuestionCircle size={30} />,
    title: "Help",
    description: "Find answers to frequently asked questions and general help topics.",
  },
  {
    icon: <FaBook size={30} />,
    title: "Help Articles",
    description: "Browse detailed articles covering various help topics.",
  },
  {
    icon: <FaFolderOpen size={30} />,
    title: "Help Categories",
    description: "Explore help topics organized by categories.",
  },
  {
    icon: <FaClipboardList size={30} />,
    title: "Knowledge Base",
    description: "Access the knowledge base for in-depth information and guides.",
  },
  {
    icon: <FaBook size={30} />,
    title: "Knowledge Base Articles",
    description: "Read articles from the knowledge base to solve your issues.",
  },
  {
    icon: <FaTags size={30} />,
    title: "Knowledge Base Categories",
    description: "Browse knowledge base content organized by categories.",
  },
]

const Help = () => {
  const [searchTerm, setSearchTerm] = useState("")

  const filteredTopics = helpTopics.filter((topic) =>
    topic.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    topic.description.toLowerCase().includes(searchTerm.toLowerCase())
  )

  return (
    <Container fluid>
      <Row className="mb-4">
        <Col>
          <h4 className="page-title">Help and Support</h4>
        </Col>
      </Row>
      <Row>
        <Col md={3}>
          <HelpSidebar />
        </Col>
        <Col md={9}>
          <Card className="mb-4">
            <CardBody>
              <InputGroup>
                <Input
                  placeholder="Search help topics..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
                <InputGroupText>
                  <FaQuestionCircle />
                </InputGroupText>
              </InputGroup>
            </CardBody>
          </Card>
          {filteredTopics.map((topic, index) => (
            <Card className="mb-3" key={index}>
              <CardBody className="d-flex align-items-center">
                <div className="me-3">{topic.icon}</div>
                <div>
                  <h5>{topic.title}</h5>
                  <p className="mb-0">{topic.description}</p>
                </div>
              </CardBody>
            </Card>
          ))}
        </Col>
      </Row>
    </Container>
  )
}

export default Help
