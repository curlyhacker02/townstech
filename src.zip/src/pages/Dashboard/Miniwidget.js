import React, { useState, useEffect } from "react"
import { Card, CardBody, Row , Col} from "reactstrap"
import { Link } from "react-router-dom"

const Miniwidget = () => {
  const [modules, setModules] = useState([])

  useEffect(() => {
    const savedModules = localStorage.getItem("dashboardModulesFull")
    if (savedModules) {
      // Filter modules where active is true
      const activeModules = JSON.parse(savedModules).filter(mod => mod.active === true)
      setModules(activeModules)
    }
  }, [])

  return (
    <React.Fragment>
      <Row>
        {modules.map(({ key, label, icon }, index) => (
          <Col xl={3} sm={6} key={index}>
            <Link to={`/${key}`} style={{ textDecoration: "none" }}>
              <Card className="mini-stat bg-primary">
                <CardBody className="card-body mini-stat-img">
                  <div className="mini-stat-icon">
                    <i className={"float-end mdi mdi-" + icon}></i>
                  </div>
                  <div className="text-white">
                    <h6 className="text-uppercase mb-3 font-size-16 text-white">{label}</h6>
                    {/* You can add dynamic data here if available */}
                    <h2 className="mb-4 text-white">-</h2>
                    <span className={"badge bg-success"}>Active</span> <span className="ms-2">Module</span>
                  </div>
                </CardBody>
              </Card>
            </Link>
          </Col>
        ))}
      </Row>
    </React.Fragment>
  )
}

export default Miniwidget
