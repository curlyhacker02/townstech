import React from "react"
import { Row, Col, Card, CardBody } from "reactstrap"

// Placeholder components for dashboard widgets
const SummaryCard = ({ title, value, icon, color }) => (
  <Card className={`text-white bg-${color} mb-3`}>
    <CardBody>
      <div className="d-flex justify-content-between align-items-center">
        <div>
          <h5>{title}</h5>
          <h3>{value}</h3>
        </div>
        <div>
          <i className={`mdi mdi-${icon} mdi-48px`}></i>
        </div>
      </div>
    </CardBody>
  </Card>
)

const ClientDefaultDashboard = () => {
  return (
    <>
      <Row>
        <Col md="3">
          <SummaryCard title="Projects" value="12" icon="folder" color="primary" />
        </Col>
        <Col md="3">
          <SummaryCard title="Tasks" value="34" icon="check-circle" color="success" />
        </Col>
        <Col md="3">
          <SummaryCard title="Messages" value="7" icon="email" color="info" />
        </Col>
        <Col md="3">
          <SummaryCard title="Notifications" value="5" icon="bell" color="warning" />
        </Col>
      </Row>

      <Row>
        <Col md="6">
          <Card>
            <CardBody>
              <h5>Recent Projects</h5>
              {/* Replace with actual project list or table */}
              <ul>
                <li>Project Alpha</li>
                <li>Project Beta</li>
                <li>Project Gamma</li>
              </ul>
            </CardBody>
          </Card>
        </Col>
        <Col md="6">
          <Card>
            <CardBody>
              <h5>Recent Tasks</h5>
              {/* Replace with actual task list or table */}
              <ul>
                <li>Task 1 - In Progress</li>
                <li>Task 2 - Completed</li>
                <li>Task 3 - Pending</li>
              </ul>
            </CardBody>
          </Card>
        </Col>
      </Row>
    </>
  )
}

export default ClientDefaultDashboard
