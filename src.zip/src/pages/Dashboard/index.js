/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState } from "react"
import { connect } from "react-redux"
import {
  Row,
  Col,
  Card,
  CardBody
} from "reactstrap"

// Pages Components
import Miniwidget from "./Miniwidget"
import MonthlyEarnings from "./montly-earnings"
import EmailSent from "./email-sent"
import MonthlyEarnings2 from "./montly-earnings2"
import Inbox from "./inbox"
import RecentActivity from "./recent-activity"
import WidgetUser from "./widget-user"
import YearlySales from "./yearly-sales"
import LatestTransactions from "./latest-transactions"
import LatestOrders from "./latest-orders"

// Actions
import { setBreadcrumbItems } from "../../store/actions"

const Dashboard = (props) => {
  document.title = "Dashboard | TownsTech Admin Dashboard"

  const breadcrumbItems = [
    { title: "TownsTech", link: "#" },
    { title: "Dashboard", link: "#" }
  ]

  useEffect(() => {
    props.setBreadcrumbItems("Dashboard", breadcrumbItems)
  }, [])

  const [customModules, setCustomModules] = useState([])

  useEffect(() => {
    const storedModules = JSON.parse(localStorage.getItem("dashboardModulesFull")) || []
    const activeModules = storedModules.filter((mod) => mod.active)
    setCustomModules(activeModules)
  }, [])

  const reports = [
    { title: "Orders", iconClass: "cube-outline", total: "1,587", average: "+11%", badgecolor: "info" },
    { title: "Revenue", iconClass: "buffer", total: "$46,782", average: "-29%", badgecolor: "danger" },
    { title: "Average Price", iconClass: "tag-text-outline", total: "$15.9", average: "0%", badgecolor: "warning" },
    { title: "Product Sold", iconClass: "briefcase-check", total: "1890", average: "+89%", badgecolor: "info" },
  ]

  return (
    <React.Fragment>
      <Miniwidget reports={reports} />

      <Row>
        <Col xl="3">
          <MonthlyEarnings />
        </Col>
        <Col xl="6">
          <EmailSent />
        </Col>
        <Col xl="3">
          <MonthlyEarnings2 />
        </Col>
      </Row>

      <Row>
        <Col xl="4" lg="6">
          <Inbox />
        </Col>
        <Col xl="4" lg="6">
          <RecentActivity />
        </Col>
        <Col xl="4">
          <WidgetUser />
          <YearlySales />
        </Col>
      </Row>

      <Row>
        <Col xl="6">
          <LatestTransactions />
        </Col>
        <Col xl="6">
          <LatestOrders />
        </Col>
      </Row>

      {customModules.length > 0 && (
        <Row className="mt-4">
          <Col>
            <h5 className="mb-3">Custom Modules</h5>
          </Col>
        </Row>
      )}
      <Row>
        {customModules.map((mod) => (
          <Col key={mod.key} md="4" className="mb-3">
            <Card>
              <CardBody className="text-center">
                <i className={`mdi mdi-${mod.icon}`} style={{ fontSize: 36, color: "#6c757d" }}></i>
                <h5 className="mt-3">{mod.label}</h5>
                <p className="text-muted">Custom module loaded from storage.</p>
              </CardBody>
            </Card>
          </Col>
        ))}
      </Row>
    </React.Fragment>
  )
}

export default connect(null, { setBreadcrumbItems })(Dashboard)
