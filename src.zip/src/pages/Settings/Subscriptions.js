import React from "react"
import { Card, CardBody } from "reactstrap"

const Subscriptions = () => {
  return (
    <Card>
      <CardBody>
        <h5>Subscriptions Settings</h5>
        <p>This is dummy content for subscriptions settings.</p>
        <ul>
          <li>Subscription Plan: Basic</li>
          <li>Renewal Date: 2024-12-31</li>
          <li>Status: Active</li>
        </ul>
      </CardBody>
    </Card>
  )
}

export default Subscriptions
