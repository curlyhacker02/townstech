import React, { useState } from "react"
import {
  Card,
  CardBody,
  Form,
  FormGroup,
  Label,
  Input,
  Button,
  Table,
} from "reactstrap"

const UserRoles = () => {
  const [userRoles, setUserRoles] = useState([
    { id: 1, username: "johndoe", role: "Admin" },
    { id: 2, username: "janedoe", role: "User" },
  ])
  const [newUsername, setNewUsername] = useState("")
  const [newUserRole, setNewUserRole] = useState("User")

  const handleAddUserRole = (e) => {
    e.preventDefault()
    if (newUsername.trim() === "") return
    const newUser = {
      id: userRoles.length + 1,
      username: newUsername,
      role: newUserRole,
    }
    setUserRoles([...userRoles, newUser])
    setNewUsername("")
    setNewUserRole("User")
  }

  return (
    <Card>
      <CardBody>
        <h5>User Roles Management</h5>
        <Form inline onSubmit={handleAddUserRole} className="mb-3">
          <FormGroup className="mr-2">
            <Label for="username" className="mr-2">Username</Label>
            <Input
              type="text"
              id="username"
              value={newUsername}
              onChange={(e) => setNewUsername(e.target.value)}
              placeholder="Enter username"
            />
          </FormGroup>
          <FormGroup className="mr-2">
            <Label for="role" className="mr-2">Role</Label>
            <Input
              type="select"
              id="role"
              value={newUserRole}
              onChange={(e) => setNewUserRole(e.target.value)}
            >
              <option>Admin</option>
              <option>User</option>
              <option>Guest</option>
            </Input>
          </FormGroup>
          <Button color="primary" type="submit">Add User Role</Button>
        </Form>
        <Table bordered hover responsive>
          <thead>
            <tr>
              <th>ID</th>
              <th>Username</th>
              <th>Role</th>
            </tr>
          </thead>
          <tbody>
            {userRoles.map((user) => (
              <tr key={user.id}>
                <td>{user.id}</td>
                <td>{user.username}</td>
                <td>{user.role}</td>
              </tr>
            ))}
          </tbody>
        </Table>
      </CardBody>
    </Card>
  )
}

export default UserRoles
