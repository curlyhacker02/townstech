import React from "react"
import { Card, CardBody } from "reactstrap"

const ItemCost = () => {
  return (
    <Card>
      <CardBody>
        <h5>Item Cost Settings</h5>
        <p>This is dummy content for item cost settings.</p>
        <ul>
          <li>Default Cost: $100</li>
          <li>Discount Rate: 10%</li>
          <li>Tax Included: Yes</li>
        </ul>
      </CardBody>
    </Card>
  )
}

export default ItemCost
