import React, { useState, useMemo } from "react"
import {
  Card,
  CardBody,
  Form,
  Input,
  Button,
  Table,
  Row,
  Col,
} from "reactstrap"

const ClientPermissions = () => {
  const [permissions, setPermissions] = useState([
    { id: 1, name: "View Dashboard", allowed: true },
    { id: 2, name: "View Projects", allowed: true },
    { id: 3, name: "Edit Profile", allowed: false },
    { id: 4, name: "Create Projects", allowed: false },
    { id: 5, name: "Delete Projects", allowed: false },
  ])

  const [searchTerm, setSearchTerm] = useState("")

  const filteredPermissions = useMemo(() => {
    return permissions.filter((perm) =>
      perm.name.toLowerCase().includes(searchTerm.toLowerCase())
    )
  }, [permissions, searchTerm])

  const togglePermission = (id) => {
    setPermissions((prev) =>
      prev.map((perm) =>
        perm.id === id ? { ...perm, allowed: !perm.allowed } : perm
      )
    )
  }

  const handleSavePermissions = (e) => {
    e.preventDefault()
    console.log("Client Permissions Saved:", permissions)
    alert("Client permissions saved successfully!")
  }

  return (
    <Card>
      <CardBody>
        <Row className="mb-3">
          <Col md="6">
            <h5>Client Permissions</h5>
          </Col>
          <Col md="6" className="text-right">
            <Input
              type="text"
              placeholder="Search permissions..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </Col>
        </Row>
        <Form onSubmit={handleSavePermissions}>
          <Table bordered hover responsive>
            <thead>
              <tr>
                <th>Permission</th>
                <th>Allowed</th>
              </tr>
            </thead>
            <tbody>
              {filteredPermissions.length > 0 ? (
                filteredPermissions.map((perm) => (
                  <tr key={perm.id}>
                    <td>{perm.name}</td>
                    <td className="text-center">
                      <Input
                        type="checkbox"
                        checked={perm.allowed}
                        onChange={() => togglePermission(perm.id)}
                      />
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="2" className="text-center">
                    No permissions found.
                  </td>
                </tr>
              )}
            </tbody>
          </Table>
          <div className="text-right">
            <Button color="primary" type="submit">
              Save Changes
            </Button>
          </div>
        </Form>
      </CardBody>
    </Card>
  )
}

export default ClientPermissions
