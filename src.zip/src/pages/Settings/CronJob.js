import React, { useState } from "react"
import {
  Card,
  CardBody,
  Form,
  FormGroup,
  Label,
  Input,
  Button,
} from "reactstrap"

const CronJob = () => {
  const [cronCommand, setCronCommand] = useState("")
  const [enabled, setEnabled] = useState(false)

  const handleSaveCronJob = (e) => {
    e.preventDefault()
    console.log("CRON Job Settings Saved:", {
      cronCommand,
      enabled,
    })
    alert("CRON Job settings saved successfully!")
  }

  return (
    <Card>
      <CardBody>
        <h5>CRON Job Settings</h5>
        <Form onSubmit={handleSaveCronJob}>
          <FormGroup>
            <Label for="cronCommand">CRON Command</Label>
            <Input
              type="text"
              id="cronCommand"
              value={cronCommand}
              onChange={(e) => setCronCommand(e.target.value)}
              placeholder="e.g. * * * * * /usr/bin/php /path/to/artisan schedule:run"
            />
          </FormGroup>
          <FormGroup check>
            <Label check>
              <Input
                type="checkbox"
                checked={enabled}
                onChange={() => setEnabled(!enabled)}
              />{" "}
              Enable CRON Job
            </Label>
          </FormGroup>
          <Button color="primary" type="submit" className="mt-3">
            Save Changes
          </Button>
        </Form>
      </CardBody>
    </Card>
  )
}

export default CronJob
