/* eslint-disable no-unused-vars */
import React, { useState, useCallback } from "react"
import {
  Card,
  CardBody,
  Form,
  FormGroup,
  Label,
  Input,
  Button,
  ListGroup,
  ListGroupItem,
  Row,
  Col,
} from "reactstrap"

const LeftMenu = () => {
  const [showLeftMenu, setShowLeftMenu] = useState(true)
  const [menuColor, setMenuColor] = useState("#343a40")
  const [menuWidth, setMenuWidth] = useState(250)
  const [menuItems, setMenuItems] = useState([
    { id: 1, name: "Dashboard", visible: true },
    { id: 2, name: "Projects", visible: true },
    { id: 3, name: "Tasks", visible: true },
    { id: 4, name: "Messages", visible: true },
  ])
  const [newMenuItemName, setNewMenuItemName] = useState("")

  const toggleVisibility = useCallback((id) => {
    setMenuItems((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, visible: !item.visible } : item
      )
    )
  }, [])

  const moveItemUp = useCallback((index) => {
    if (index === 0) return
    setMenuItems((prev) => {
      const newItems = [...prev]
      const temp = newItems[index - 1]
      newItems[index - 1] = newItems[index]
      newItems[index] = temp
      return newItems
    })
  }, [])

  const moveItemDown = useCallback((index) => {
    if (index === menuItems.length - 1) return
    setMenuItems((prev) => {
      const newItems = [...prev]
      const temp = newItems[index + 1]
      newItems[index + 1] = newItems[index]
      newItems[index] = temp
      return newItems
    })
  }, [menuItems.length])

  const addMenuItem = useCallback(() => {
    if (newMenuItemName.trim() === "") return
    setMenuItems((prev) => [
      ...prev,
      { id: prev.length + 1, name: newMenuItemName, visible: true },
    ])
    setNewMenuItemName("")
  }, [newMenuItemName])

  const removeMenuItem = useCallback((id) => {
    setMenuItems((prev) => prev.filter((item) => item.id !== id))
  }, [])

  const handleSaveLeftMenu = useCallback((e) => {
    e.preventDefault()
    console.log("Left Menu Settings Saved:", {
      showLeftMenu,
      menuColor,
      menuWidth,
      menuItems,
    })
    alert("Left Menu settings saved successfully!")
  }, [showLeftMenu, menuColor, menuWidth, menuItems])

  return (
    <Card>
      <CardBody>
        <h5>Left Menu Settings</h5>
        <Form onSubmit={handleSaveLeftMenu}>
          <FormGroup check>
            <Label check>
              <Input
                type="checkbox"
                checked={showLeftMenu}
                onChange={() => setShowLeftMenu(!showLeftMenu)}
              />{" "}
              Show Left Menu
            </Label>
          </FormGroup>
          <FormGroup>
            <Label for="menuColor">Menu Color</Label>
            <Input
              type="color"
              id="menuColor"
              value={menuColor}
              onChange={(e) => setMenuColor(e.target.value)}
            />
          </FormGroup>
          <FormGroup>
            <Label for="menuWidth">Menu Width (px)</Label>
            <Input
              type="number"
              id="menuWidth"
              value={menuWidth}
              onChange={(e) => setMenuWidth(e.target.value)}
              min={100}
              max={500}
            />
          </FormGroup>

          <FormGroup>
            <Label>Menu Items</Label>
            <ListGroup>
              {menuItems.map((item, index) => (
                <ListGroupItem key={item.id} className="d-flex align-items-center justify-content-between">
                  <div>
                    <Input
                      type="checkbox"
                      checked={item.visible}
                      onChange={() => toggleVisibility(item.id)}
                      className="mr-2"
                    />
                    {item.name}
                  </div>
                  <div>
                    <Button color="secondary" size="sm" onClick={() => moveItemUp(index)} className="mr-1" disabled={index === 0}>
                      ↑
                    </Button>
                    <Button color="secondary" size="sm" onClick={() => moveItemDown(index)} className="mr-1" disabled={index === menuItems.length - 1}>
                      ↓
                    </Button>
                    <Button color="danger" size="sm" onClick={() => removeMenuItem(item.id)}>
                      ✕
                    </Button>
                  </div>
                </ListGroupItem>
              ))}
            </ListGroup>
          </FormGroup>

          <FormGroup className="d-flex">
            <Input
              type="text"
              placeholder="New menu item name"
              value={newMenuItemName}
              onChange={(e) => setNewMenuItemName(e.target.value)}
              className="mr-2"
            />
            <Button color="primary" onClick={addMenuItem} type="button">
              Add Item
            </Button>
          </FormGroup>

          <Button color="primary" type="submit">
            Save Changes
          </Button>
        </Form>
      </CardBody>
    </Card>
  )
}

export default LeftMenu
