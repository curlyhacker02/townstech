import React from "react"
import { Card, CardBody } from "reactstrap"

const TaxesPayment = () => {
  return (
    <Card>
      <CardBody>
        <h5>Taxes Payment Settings</h5>
        <p>This is dummy content for taxes payment settings.</p>
        <ul>
          <li>Tax Rate: 15%</li>
          <li>Payment Terms: Net 30</li>
          <li>Late Fee: 5%</li>
        </ul>
      </CardBody>
    </Card>
  )
}

export default TaxesPayment
