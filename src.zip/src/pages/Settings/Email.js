import React, { useState } from "react"
import {
  Card,
  CardBody,
  Form,
  FormGroup,
  Label,
  Input,
  Button,
} from "reactstrap"

const Email = () => {
  const [mailDriver, setMailDriver] = useState("smtp")
  const [mailHost, setMailHost] = useState("")
  const [mailPort, setMailPort] = useState("")
  const [mailUsername, setMailUsername] = useState("")
  const [mailPassword, setMailPassword] = useState("")
  const [mailEncryption, setMailEncryption] = useState("tls")
  const [mailFromAddress, setMailFromAddress] = useState("")
  const [mailFromName, setMailFromName] = useState("")

  const handleSaveEmailSettings = (e) => {
    e.preventDefault()
    console.log("Email Settings Saved:", {
      mailDriver,
      mailHost,
      mailPort,
      mailUsername,
      mailPassword,
      mailEncryption,
      mailFromAddress,
      mailFromName,
    })
    alert("Email settings saved successfully!")
  }

  return (
    <Card>
      <CardBody>
        <h5>Email Settings</h5>
        <Form onSubmit={handleSaveEmailSettings}>
          <FormGroup>
            <Label for="mailDriver">Mail Driver</Label>
            <Input
              type="select"
              id="mailDriver"
              value={mailDriver}
              onChange={(e) => setMailDriver(e.target.value)}
            >
              <option value="smtp">SMTP</option>
              <option value="sendmail">Sendmail</option>
              <option value="mailgun">Mailgun</option>
              <option value="ses">SES</option>
              <option value="postmark">Postmark</option>
              <option value="log">Log</option>
            </Input>
          </FormGroup>
          <FormGroup>
            <Label for="mailHost">Mail Host</Label>
            <Input
              type="text"
              id="mailHost"
              value={mailHost}
              onChange={(e) => setMailHost(e.target.value)}
              placeholder="smtp.mailtrap.io"
            />
          </FormGroup>
          <FormGroup>
            <Label for="mailPort">Mail Port</Label>
            <Input
              type="number"
              id="mailPort"
              value={mailPort}
              onChange={(e) => setMailPort(e.target.value)}
              placeholder="2525"
            />
          </FormGroup>
          <FormGroup>
            <Label for="mailUsername">Mail Username</Label>
            <Input
              type="text"
              id="mailUsername"
              value={mailUsername}
              onChange={(e) => setMailUsername(e.target.value)}
            />
          </FormGroup>
          <FormGroup>
            <Label for="mailPassword">Mail Password</Label>
            <Input
              type="password"
              id="mailPassword"
              value={mailPassword}
              onChange={(e) => setMailPassword(e.target.value)}
            />
          </FormGroup>
          <FormGroup>
            <Label for="mailEncryption">Mail Encryption</Label>
            <Input
              type="select"
              id="mailEncryption"
              value={mailEncryption}
              onChange={(e) => setMailEncryption(e.target.value)}
            >
              <option value="tls">TLS</option>
              <option value="ssl">SSL</option>
              <option value="none">None</option>
            </Input>
          </FormGroup>
          <FormGroup>
            <Label for="mailFromAddress">Mail From Address</Label>
            <Input
              type="email"
              id="mailFromAddress"
              value={mailFromAddress}
              onChange={(e) => setMailFromAddress(e.target.value)}
              placeholder="noreply@example.com"
            />
          </FormGroup>
          <FormGroup>
            <Label for="mailFromName">Mail From Name</Label>
            <Input
              type="text"
              id="mailFromName"
              value={mailFromName}
              onChange={(e) => setMailFromName(e.target.value)}
              placeholder="Example App"
            />
          </FormGroup>
          <Button color="primary" type="submit">
            Save Changes
          </Button>
        </Form>
      </CardBody>
    </Card>
  )
}

export default Email
