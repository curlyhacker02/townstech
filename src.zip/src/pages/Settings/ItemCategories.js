import React, { useState } from "react"
import {
  Card,
  CardBody,
  Table,
  Button,
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
  Form,
  FormGroup,
  Label,
  Input,
} from "reactstrap"

const ItemCategories = () => {
  const [categories, setCategories] = useState([
    { id: 1, name: "Electronics", description: "Electronic items" },
    { id: 2, name: "Furniture", description: "Furniture items" },
    { id: 3, name: "Stationery", description: "Office stationery" },
  ])

  const [modalOpen, setModalOpen] = useState(false)
  const [currentCategory, setCurrentCategory] = useState({ id: null, name: "", description: "" })

  const toggleModal = () => setModalOpen(!modalOpen)

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setCurrentCategory((prev) => ({ ...prev, [name]: value }))
  }

  const handleEdit = (category) => {
    setCurrentCategory(category)
    setModalOpen(true)
  }

  const handleDelete = (id) => {
    if (window.confirm("Are you sure you want to delete this category?")) {
      setCategories((prev) => prev.filter((cat) => cat.id !== id))
    }
  }

  const handleSave = (e) => {
    e.preventDefault()
    if (currentCategory.id) {
      setCategories((prev) =>
        prev.map((cat) => (cat.id === currentCategory.id ? currentCategory : cat))
      )
    } else {
      setCategories((prev) => [
        ...prev,
        { ...currentCategory, id: prev.length ? prev[prev.length - 1].id + 1 : 1 },
      ])
    }
    setModalOpen(false)
    setCurrentCategory({ id: null, name: "", description: "" })
  }

  const handleAddNew = () => {
    setCurrentCategory({ id: null, name: "", description: "" })
    setModalOpen(true)
  }

  return (
    <Card>
      <CardBody>
        <h5>Item Categories</h5>
        <Button color="primary" className="mb-3" onClick={handleAddNew}>
          Add New Category
        </Button>
        <Table bordered hover responsive>
          <thead>
            <tr>
              <th>Name</th>
              <th>Description</th>
              <th style={{ width: "150px" }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {categories.map((category) => (
              <tr key={category.id}>
                <td>{category.name}</td>
                <td>{category.description}</td>
                <td>
                  <Button color="info" size="sm" className="mr-2" onClick={() => handleEdit(category)}>
                    Edit
                  </Button>
                  <Button color="danger" size="sm" onClick={() => handleDelete(category.id)}>
                    Delete
                  </Button>
                </td>
              </tr>
            ))}
            {categories.length === 0 && (
              <tr>
                <td colSpan="3" className="text-center">
                  No categories found.
                </td>
              </tr>
            )}
          </tbody>
        </Table>

        <Modal isOpen={modalOpen} toggle={toggleModal}>
          <ModalHeader toggle={toggleModal}>
            {currentCategory.id ? "Edit Category" : "Add New Category"}
          </ModalHeader>
          <Form onSubmit={handleSave}>
            <ModalBody>
              <FormGroup>
                <Label for="name">Category Name</Label>
                <Input
                  type="text"
                  id="name"
                  name="name"
                  value={currentCategory.name}
                  onChange={handleInputChange}
                  required
                />
              </FormGroup>
              <FormGroup>
                <Label for="description">Description</Label>
                <Input
                  type="textarea"
                  id="description"
                  name="description"
                  value={currentCategory.description}
                  onChange={handleInputChange}
                />
              </FormGroup>
            </ModalBody>
            <ModalFooter>
              <Button color="primary" type="submit">
                Save
              </Button>{" "}
              <Button color="secondary" onClick={toggleModal}>
                Cancel
              </Button>
            </ModalFooter>
          </Form>
        </Modal>
      </CardBody>
    </Card>
  )
}

export default ItemCategories
