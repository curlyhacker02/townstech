import React, { useState } from "react"
import {
  Card,
  CardBody,
  Form,
  FormGroup,
  Label,
  Input,
  Button,
  Table,
} from "reactstrap"

const Team = () => {
  const [teamMembers, setTeamMembers] = useState([
    { id: 1, name: "John Doe", role: "Developer" },
    { id: 2, name: "Jane Smith", role: "Designer" },
  ])
  const [newMemberName, setNewMemberName] = useState("")
  const [newMemberRole, setNewMemberRole] = useState("Developer")

  const handleAddTeamMember = (e) => {
    e.preventDefault()
    if (newMemberName.trim() === "") return
    const newMember = {
      id: teamMembers.length + 1,
      name: newMemberName,
      role: newMemberRole,
    }
    setTeamMembers([...teamMembers, newMember])
    setNewMemberName("")
    setNewMemberRole("Developer")
  }

  return (
    <Card>
      <CardBody>
        <h5>Team Management</h5>
        <Form inline onSubmit={handleAddTeamMember} className="mb-3">
          <FormGroup className="mr-2">
            <Label for="memberName" className="mr-2">Name</Label>
            <Input
              type="text"
              id="memberName"
              value={newMemberName}
              onChange={(e) => setNewMemberName(e.target.value)}
              placeholder="Enter member name"
            />
          </FormGroup>
          <FormGroup className="mr-2">
            <Label for="memberRole" className="mr-2">Role</Label>
            <Input
              type="select"
              id="memberRole"
              value={newMemberRole}
              onChange={(e) => setNewMemberRole(e.target.value)}
            >
              <option>Developer</option>
              <option>Designer</option>
              <option>Manager</option>
              <option>QA</option>
            </Input>
          </FormGroup>
          <Button color="primary" type="submit">Add Member</Button>
        </Form>
        <Table bordered hover responsive>
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Role</th>
            </tr>
          </thead>
          <tbody>
            {teamMembers.map((member) => (
              <tr key={member.id}>
                <td>{member.id}</td>
                <td>{member.name}</td>
                <td>{member.role}</td>
              </tr>
            ))}
          </tbody>
        </Table>
      </CardBody>
    </Card>
  )
}

export default Team
