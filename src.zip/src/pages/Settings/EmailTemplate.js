import React, { useState } from "react"
import {
  Card,
  CardBody,
  Form,
  FormGroup,
  Label,
  Input,
  Button,
} from "reactstrap"

const EmailTemplate = () => {
  const [templateName, setTemplateName] = useState("")
  const [subject, setSubject] = useState("")
  const [content, setContent] = useState("")

  const handleSaveEmailTemplate = (e) => {
    e.preventDefault()
    console.log("Email Template Saved:", {
      templateName,
      subject,
      content,
    })
    alert("Email template saved successfully!")
  }

  return (
    <Card>
      <CardBody>
        <h5>Email Template Settings</h5>
        <Form onSubmit={handleSaveEmailTemplate}>
          <FormGroup>
            <Label for="templateName">Template Name</Label>
            <Input
              type="text"
              id="templateName"
              value={templateName}
              onChange={(e) => setTemplateName(e.target.value)}
              placeholder="Enter template name"
            />
          </FormGroup>
          <FormGroup>
            <Label for="subject">Subject</Label>
            <Input
              type="text"
              id="subject"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              placeholder="Enter email subject"
            />
          </FormGroup>
          <FormGroup>
            <Label for="content">Content</Label>
            <Input
              type="textarea"
              id="content"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Enter email content"
              rows={6}
            />
          </FormGroup>
          <Button color="primary" type="submit">
            Save Changes
          </Button>
        </Form>
      </CardBody>
    </Card>
  )
}

export default EmailTemplate
