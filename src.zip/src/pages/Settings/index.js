/* eslint-disable no-unused-vars */
import { useState } from "react"
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  Collapse,
  ListGroup,
  ListGroupItem,
  Button,
} from "reactstrap"
import classnames from "classnames"
import General from "./General"
import Localization from "./Localization"
import Email from "./Email"
import EmailTemplate from "./EmailTemplate"
import Modules from "./Modules"
import LeftMenu from "./LeftMenu"
import Notifications from "./Notifications"
import Integration from "./Integration"
import CronJob from "./CronJob"
import Roles from "./Roles"
import UserRoles from "./UserRoles"
import Team from "./Team"
import IPRestriction from "./IPRestriction"
import ClientPermissions from "./ClientPermissions"
import ClientDashboard from "./ClientDashboard"
import Projects from "./Projects"
import Company from "./Company"
import ItemCost from "./ItemCost"
import TaxesPayment from "./TaxesPayment"
import Subscriptions from "./Subscriptions"
import ItemCategories from "./ItemCategories"

const Settings = () => {
  const [activeMainMenu, setActiveMainMenu] = useState("App Settings")
  const [activeSubMenu, setActiveSubMenu] = useState("General")
  const [openMenus, setOpenMenus] = useState({
    "App Settings": true,
    "Access Permissions": false,
    "Client Portal": false,
    "Sales and Prospects": false,
    "Set Up": false,
  })

  const toggleMenu = (menu) => {
    setOpenMenus((prev) => ({
      ...prev,
      [menu]: !prev[menu],
    }))
  }

  const handleMainMenuClick = (menu) => {
    setActiveMainMenu(menu)
    toggleMenu(menu)
    switch (menu) {
      case "App Settings":
        setActiveSubMenu("General")
        break
      case "Access Permissions":
        setActiveSubMenu("Roles")
        break
      case "Client Portal":
        setActiveSubMenu("Client Permissions")
        break
      case "Sales and Prospects":
        setActiveSubMenu("Company")
        break
      case "Set Up":
        setActiveSubMenu("Custom Fields")
        break
      default:
        setActiveSubMenu("")
    }
  }

  const handleSubMenuClick = (submenu) => {
    setActiveSubMenu(submenu)
  }

  const menuStructure = {
    "App Settings": [
      "General",
      "Localization",
      "Email",
      "Email Template",
      "Modules",
      "Left Menu",
      "Notifications",
      "Integration",
      "CRON Job",
      "Updates",
    ],
    "Access Permissions": ["Roles", "User Roles", "Team", "IP Restriction"],
    "Client Portal": ["Client Permissions", "Dashboard", "Left Menu", "Projects"],
    "Sales and Prospects": ["Company", "Item Cost", "Taxes Payment", "Subscriptions", "Item Categories"],
    "Set Up": [
      "Custom Fields",
      "Client Groups",
      "Tasks",
      "Projects",
      "Timesheets",
      "Leave Types",
      "Leads",
      "GDPR",
      "Pages",
    ],
  }

  const renderContent = () => {
    if (activeMainMenu === "App Settings" && activeSubMenu === "General") {
      return <General />
    }
    if (activeMainMenu === "App Settings" && activeSubMenu === "Localization") {
      return <Localization />
    }
    if (activeMainMenu === "App Settings" && activeSubMenu === "Email") {
      return <Email />
    }
    if (activeMainMenu === "App Settings" && activeSubMenu === "Email Template") {
      return <EmailTemplate />
    }
    if (activeMainMenu === "App Settings" && activeSubMenu === "Modules") {
      return <Modules />
    }
    if (activeMainMenu === "App Settings" && activeSubMenu === "Left Menu") {
      return <LeftMenu />
    }
    if (activeMainMenu === "App Settings" && activeSubMenu === "Notifications") {
      return <Notifications />
    }
    if (activeMainMenu === "App Settings" && activeSubMenu === "Integration") {
      return <Integration />
    }
    if (activeMainMenu === "App Settings" && activeSubMenu === "CRON Job") {
      return <CronJob />
    }
    if (activeMainMenu === "Access Permissions") {
      switch (activeSubMenu) {
        case "Roles":
          return <Roles />
        case "User Roles":
          return <UserRoles />
        case "Team":
          return <Team />
        case "IP Restriction":
          return <IPRestriction />
        default:
          return (
            <Card>
              <CardBody>
                <h5>{activeMainMenu} - {activeSubMenu}</h5>
                <p>This is the placeholder content for the {activeSubMenu} section under {activeMainMenu}.</p>
              </CardBody>
            </Card>
          )
      }
    }
    if (activeMainMenu === "Client Portal") {
      switch (activeSubMenu) {
        case "Client Permissions":
          return <ClientPermissions />
        case "Dashboard":
          return <ClientDashboard />
        case "Projects":
          return <Projects />
        default:
          return (
            <Card>
              <CardBody>
                <h5>{activeMainMenu} - {activeSubMenu}</h5>
                <p>This is the placeholder content for the {activeSubMenu} section under {activeMainMenu}.</p>
              </CardBody>
            </Card>
          )
      }
    }
    return (
      <Card>
        <CardBody>
          <h5>{activeMainMenu} - {activeSubMenu}</h5>
          <p>This is the placeholder content for the {activeSubMenu} section under {activeMainMenu}.</p>
        </CardBody>
      </Card>
    )
  }

  return (
    <Container fluid>
      <Row className="mb-4">
        <Col>
          <h4 className="page-title">Settings</h4>
        </Col>
      </Row>
      <Row>
        <Col md={3} className="border-right" style={{ minHeight: "80vh", backgroundColor: "#f8f9fa" }}>
          {Object.keys(menuStructure).map((mainMenu) => (
            <div key={mainMenu} className="mb-3">
              <Button
                color="link"
                className={classnames("w-100 text-left font-weight-bold", { active: activeMainMenu === mainMenu })}
                onClick={() => handleMainMenuClick(mainMenu)}
                aria-expanded={openMenus[mainMenu]}
                style={{ fontSize: "1.1rem", color: activeMainMenu === mainMenu ? "#007bff" : "#495057" }}
              >
                {mainMenu}
              </Button>
              <Collapse isOpen={openMenus[mainMenu]}>
                <ListGroup flush>
                  {menuStructure[mainMenu].map((submenu) => (
                    <ListGroupItem
                      key={submenu}
                      tag="button"
                      action
                      className={classnames({ active: activeSubMenu === submenu })}
                      onClick={() => handleSubMenuClick(submenu)}
                      style={{ fontSize: "0.95rem" }}
                    >
                      {submenu}
                    </ListGroupItem>
                  ))}
                </ListGroup>
              </Collapse>
            </div>
          ))}
        </Col>
        <Col md={9} style={{ minHeight: "80vh" }}>
          <div className="mt-3">{renderContent()}</div>
        </Col>
      </Row>
    </Container>
  )
}

export default Settings
