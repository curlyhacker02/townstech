import React, { useState } from "react"
import {
  Card,
  CardBody,
  Table,
  Button,
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
  Form,
  FormGroup,
  Label,
  Input,
} from "reactstrap"

const Projects = () => {
  const [projects, setProjects] = useState([
    { id: 1, name: "Project Alpha", description: "Description of Project Alpha" },
    { id: 2, name: "Project Beta", description: "Description of Project Beta" },
    { id: 3, name: "Project Gamma", description: "Description of Project Gamma" },
  ])

  const [modalOpen, setModalOpen] = useState(false)
  const [currentProject, setCurrentProject] = useState({ id: null, name: "", description: "" })

  const toggleModal = () => setModalOpen(!modalOpen)

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setCurrentProject((prev) => ({ ...prev, [name]: value }))
  }

  const handleEdit = (project) => {
    setCurrentProject(project)
    setModalOpen(true)
  }

  const handleDelete = (id) => {
    if (window.confirm("Are you sure you want to delete this project?")) {
      setProjects((prev) => prev.filter((proj) => proj.id !== id))
    }
  }

  const handleSave = (e) => {
    e.preventDefault()
    if (currentProject.id) {
      // Edit existing project
      setProjects((prev) =>
        prev.map((proj) => (proj.id === currentProject.id ? currentProject : proj))
      )
    } else {
      // Add new project
      setProjects((prev) => [
        ...prev,
        { ...currentProject, id: prev.length ? prev[prev.length - 1].id + 1 : 1 },
      ])
    }
    setModalOpen(false)
    setCurrentProject({ id: null, name: "", description: "" })
  }

  const handleAddNew = () => {
    setCurrentProject({ id: null, name: "", description: "" })
    setModalOpen(true)
  }

  return (
    <Card>
      <CardBody>
        <h5>Client Projects</h5>
        <Button color="primary" className="mb-3" onClick={handleAddNew}>
          Add New Project
        </Button>
        <Table bordered hover responsive>
          <thead>
            <tr>
              <th>Name</th>
              <th>Description</th>
              <th style={{ width: "150px" }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {projects.map((project) => (
              <tr key={project.id}>
                <td>{project.name}</td>
                <td>{project.description}</td>
                <td>
                  <Button color="info" size="sm" className="mr-2" onClick={() => handleEdit(project)}>
                    Edit
                  </Button>
                  <Button color="danger" size="sm" onClick={() => handleDelete(project.id)}>
                    Delete
                  </Button>
                </td>
              </tr>
            ))}
            {projects.length === 0 && (
              <tr>
                <td colSpan="3" className="text-center">
                  No projects found.
                </td>
              </tr>
            )}
          </tbody>
        </Table>

        <Modal isOpen={modalOpen} toggle={toggleModal}>
          <ModalHeader toggle={toggleModal}>
            {currentProject.id ? "Edit Project" : "Add New Project"}
          </ModalHeader>
          <Form onSubmit={handleSave}>
            <ModalBody>
              <FormGroup>
                <Label for="name">Project Name</Label>
                <Input
                  type="text"
                  id="name"
                  name="name"
                  value={currentProject.name}
                  onChange={handleInputChange}
                  required
                />
              </FormGroup>
              <FormGroup>
                <Label for="description">Description</Label>
                <Input
                  type="textarea"
                  id="description"
                  name="description"
                  value={currentProject.description}
                  onChange={handleInputChange}
                />
              </FormGroup>
            </ModalBody>
            <ModalFooter>
              <Button color="primary" type="submit">
                Save
              </Button>{" "}
              <Button color="secondary" onClick={toggleModal}>
                Cancel
              </Button>
            </ModalFooter>
          </Form>
        </Modal>
      </CardBody>
    </Card>
  )
}

export default Projects
