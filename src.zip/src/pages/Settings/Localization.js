import React, { useState } from "react"
import {
  Card,
  CardBody,
  Form,
  FormGroup,
  Label,
  Input,
  Button,
} from "reactstrap"

const Localization = () => {
  const [language, setLanguage] = useState("English")
  const [timezone, setTimezone] = useState("UTC")
  const [currency, setCurrency] = useState("USD")

  const handleSaveLocalization = (e) => {
    e.preventDefault()
    console.log("Localization Settings Saved:", {
      language,
      timezone,
      currency,
    })
    alert("Localization settings saved successfully!")
  }

  return (
    <Card>
      <CardBody>
        <Form onSubmit={handleSaveLocalization}>
          <FormGroup>
            <Label for="language">Language</Label>
            <Input
              type="select"
              id="language"
              value={language}
              onChange={(e) => setLanguage(e.target.value)}
            >
              <option>English</option>
              <option>Spanish</option>
              <option>French</option>
              <option>German</option>
              <option>Chinese</option>
            </Input>
          </FormGroup>
          <FormGroup>
            <Label for="timezone">Timezone</Label>
            <Input
              type="select"
              id="timezone"
              value={timezone}
              onChange={(e) => setTimezone(e.target.value)}
            >
              <option>UTC</option>
              <option>GMT</option>
              <option>EST</option>
              <option>PST</option>
              <option>CST</option>
            </Input>
          </FormGroup>
          <FormGroup>
            <Label for="currency">Currency</Label>
            <Input
              type="select"
              id="currency"
              value={currency}
              onChange={(e) => setCurrency(e.target.value)}
            >
              <option>USD</option>
              <option>EUR</option>
              <option>GBP</option>
              <option>JPY</option>
              <option>AUD</option>
            </Input>
          </FormGroup>
          <Button color="primary" type="submit">
            Save Changes
          </Button>
        </Form>
      </CardBody>
    </Card>
  )
}

export default Localization
