import React, { useEffect, useState } from "react"
import { Container, Row, Col, Card, CardBody, Button, Modal, ModalHeader, ModalBody, ModalFooter, Form, FormGroup, Label, Input } from "reactstrap"
import { FaEdit, FaToggleOn, FaToggleOff, FaTrash, FaPlus } from "react-icons/fa"

const ModulesNew = () => {
  const [modules, setModules] = useState([])
  const [modalOpen, setModalOpen] = useState(false)
  const [newModuleLabel, setNewModuleLabel] = useState("")
  const [newModuleKey, setNewModuleKey] = useState("")
  const [newModuleIcon, setNewModuleIcon] = useState("view-module")

  useEffect(() => {
    const storedModules = JSON.parse(localStorage.getItem("dashboardModulesFull")) || []
    setModules(storedModules)
  }, [])

  const updateModuleStatus = (key, isActive) => {
    const updatedModules = modules.map((mod) => {
      if (mod.key === key) {
        return { ...mod, active: isActive }
      }
      return mod
    })
    setModules(updatedModules)
    localStorage.setItem("dashboardModulesFull", JSON.stringify(updatedModules))
  }

  const deleteModule = (key) => {
    if (window.confirm("Are you sure you want to delete this module?")) {
      const updatedModules = modules.filter((mod) => mod.key !== key)
      setModules(updatedModules)
      localStorage.setItem("dashboardModulesFull", JSON.stringify(updatedModules))
    }
  }

  const handleEdit = (key) => {
    alert(`Edit functionality for module: \${key} is not implemented yet.`)
  }

  const toggleModal = () => {
    setModalOpen(!modalOpen)
    setNewModuleLabel("")
    setNewModuleKey("")
    setNewModuleIcon("view-module")
  }

  const handleAddModule = () => {
    if (!newModuleLabel.trim() || !newModuleKey.trim()) {
      alert("Please enter both module label and key.")
      return
    }
    if (modules.find((mod) => mod.key === newModuleKey.trim())) {
      alert("Module key must be unique.")
      return
    }
    const newModule = {
      key: newModuleKey.trim(),
      label: newModuleLabel.trim(),
      icon: newModuleIcon.trim(),
      active: true,
      jsContent: ""
    }
    const updatedModules = [...modules, newModule]
    setModules(updatedModules)
    localStorage.setItem("dashboardModulesFull", JSON.stringify(updatedModules))
    toggleModal()
  }

  return (
    <Container fluid>
      <Row className="mb-4">
        <Col className="d-flex justify-content-between align-items-center">
          <h4 className="page-title">Modules</h4>
          <Button color="success" onClick={toggleModal} title="Add New Module">
            <FaPlus /> Add New Module
          </Button>
        </Col>
      </Row>
      <Row>
        {modules.length === 0 ? (
          <Col>
            <Card>
              <CardBody>No modules found.</CardBody>
            </Card>
          </Col>
        ) : (
          modules.map((mod) => (
            <Col key={mod.key} md={4} className="mb-3">
              <Card>
                <CardBody>
                  <div className="d-flex justify-content-between align-items-center mb-2">
                    <div className="d-flex align-items-center">
                      {mod.icon ? (
                        <i className={`mdi mdi-${mod.icon}`} style={{ fontSize: 32, marginRight: 12 }}></i>
                      ) : (
                        <i className="mdi mdi-view-module" style={{ fontSize: 32, marginRight: 12 }}></i>
                      )}
                      <strong>{mod.label}</strong>
                    </div>
                    <div>
                      <Button color="primary" size="sm" className="mr-2" onClick={() => handleEdit(mod.key)} title="Edit">
                        <FaEdit />
                      </Button>
                      {mod.active ? (
                        <Button
                          color="danger"
                          size="sm"
                          className="mr-2"
                          onClick={() => updateModuleStatus(mod.key, false)}
                          title="Deactivate"
                        >
                          <FaToggleOn />
                        </Button>
                      ) : (
                        <Button
                          color="success"
                          size="sm"
                          className="mr-2"
                          onClick={() => updateModuleStatus(mod.key, true)}
                          title="Activate"
                        >
                          <FaToggleOff />
                        </Button>
                      )}
                      <Button color="danger" size="sm" onClick={() => deleteModule(mod.key)} title="Delete">
                        <FaTrash />
                      </Button>
                    </div>
                  </div>
                </CardBody>
              </Card>
            </Col>
          ))
        )}
      </Row>

      <Modal isOpen={modalOpen} toggle={toggleModal}>
        <ModalHeader toggle={toggleModal}>Add New Module</ModalHeader>
        <ModalBody>
          <Form>
            <FormGroup>
              <Label for="moduleLabel">Module Label</Label>
              <Input
                type="text"
                id="moduleLabel"
                value={newModuleLabel}
                onChange={(e) => setNewModuleLabel(e.target.value)}
                placeholder="Enter module label"
              />
            </FormGroup>
            <FormGroup>
              <Label for="moduleKey">Module Key</Label>
              <Input
                type="text"
                id="moduleKey"
                value={newModuleKey}
                onChange={(e) => setNewModuleKey(e.target.value)}
                placeholder="Enter unique module key"
              />
            </FormGroup>
            <FormGroup>
              <Label for="moduleIcon">Module Icon (mdi icon name)</Label>
              <Input
                type="text"
                id="moduleIcon"
                value={newModuleIcon}
                onChange={(e) => setNewModuleIcon(e.target.value)}
                placeholder="Enter mdi icon name, e.g. view-module"
              />
            </FormGroup>
          </Form>
        </ModalBody>
        <ModalFooter>
          <Button color="primary" onClick={handleAddModule}>
            Add Module
          </Button>{" "}
          <Button color="secondary" onClick={toggleModal}>
            Cancel
          </Button>
        </ModalFooter>
      </Modal>
    </Container>
  )
}

export default ModulesNew
