import React, { useState } from "react"
import {
  Card,
  CardBody,
  Form,
  FormGroup,
  Label,
  Input,
  Button,
  Table,
} from "reactstrap"

const IPRestriction = () => {
  const [ipAddresses, setIpAddresses] = useState([
    "192.168.1.1",
    "10.0.0.1",
  ])
  const [newIp, setNewIp] = useState("")

  const handleAddIp = (e) => {
    e.preventDefault()
    if (newIp.trim() === "") return
    setIpAddresses([...ipAddresses, newIp])
    setNewIp("")
  }

  const handleRemoveIp = (ipToRemove) => {
    setIpAddresses(ipAddresses.filter((ip) => ip !== ipToRemove))
  }

  return (
    <Card>
      <CardBody>
        <h5>IP Restriction Management</h5>
        <Form inline onSubmit={handleAddIp} className="mb-3">
          <FormGroup className="mr-2">
            <Label for="ipAddress" className="mr-2">IP Address</Label>
            <Input
              type="text"
              id="ipAddress"
              value={newIp}
              onChange={(e) => setNewIp(e.target.value)}
              placeholder="Enter IP address"
            />
          </FormGroup>
          <Button color="primary" type="submit">Add IP</Button>
        </Form>
        <Table bordered hover responsive>
          <thead>
            <tr>
              <th>IP Address</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {ipAddresses.map((ip) => (
              <tr key={ip}>
                <td>{ip}</td>
                <td>
                  <Button color="danger" size="sm" onClick={() => handleRemoveIp(ip)}>
                    Remove
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
      </CardBody>
    </Card>
  )
}

export default IPRestriction
