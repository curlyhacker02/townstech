import React, { useState } from "react"
import {
  Card,
  CardBody,
  Form,
  FormGroup,
  Label,
  Input,
  Button,
  Table,
} from "reactstrap"

const Roles = () => {
  const [roles, setRoles] = useState([
    { id: 1, name: "Admin", description: "Full access to all features" },
    { id: 2, name: "User", description: "Limited access" },
  ])
  const [newRoleName, setNewRoleName] = useState("")
  const [newRoleDescription, setNewRoleDescription] = useState("")

  const handleAddRole = (e) => {
    e.preventDefault()
    if (newRoleName.trim() === "") return
    const newRole = {
      id: roles.length + 1,
      name: newRoleName,
      description: newRoleDescription,
    }
    setRoles([...roles, newRole])
    setNewRoleName("")
    setNewRoleDescription("")
  }

  return (
    <Card>
      <CardBody>
        <h5>Roles Management</h5>
        <Form inline onSubmit={handleAddRole} className="mb-3">
          <FormGroup className="mr-2">
            <Label for="roleName" className="mr-2">Role Name</Label>
            <Input
              type="text"
              id="roleName"
              value={newRoleName}
              onChange={(e) => setNewRoleName(e.target.value)}
              placeholder="Enter role name"
            />
          </FormGroup>
          <FormGroup className="mr-2">
            <Label for="roleDescription" className="mr-2">Description</Label>
            <Input
              type="text"
              id="roleDescription"
              value={newRoleDescription}
              onChange={(e) => setNewRoleDescription(e.target.value)}
              placeholder="Enter description"
            />
          </FormGroup>
          <Button color="primary" type="submit">Add Role</Button>
        </Form>
        <Table bordered hover responsive>
          <thead>
            <tr>
              <th>ID</th>
              <th>Role Name</th>
              <th>Description</th>
            </tr>
          </thead>
          <tbody>
            {roles.map((role) => (
              <tr key={role.id}>
                <td>{role.id}</td>
                <td>{role.name}</td>
                <td>{role.description}</td>
              </tr>
            ))}
          </tbody>
        </Table>
      </CardBody>
    </Card>
  )
}

export default Roles
