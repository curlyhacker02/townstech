import React, { useState } from "react"
import {
  Card,
  CardBody,
  Form,
  FormGroup,
  Label,
  Input,
  Button,
} from "reactstrap"

const Integration = () => {
  const [apiKey, setApiKey] = useState("")
  const [apiSecret, setApiSecret] = useState("")
  const [enabled, setEnabled] = useState(false)

  const handleSaveIntegration = (e) => {
    e.preventDefault()
    console.log("Integration Settings Saved:", {
      apiKey,
      apiSecret,
      enabled,
    })
    alert("Integration settings saved successfully!")
  }

  return (
    <Card>
      <CardBody>
        <h5>Integration Settings</h5>
        <Form onSubmit={handleSaveIntegration}>
          <FormGroup>
            <Label for="apiKey">API Key</Label>
            <Input
              type="text"
              id="apiKey"
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
            />
          </FormGroup>
          <FormGroup>
            <Label for="apiSecret">API Secret</Label>
            <Input
              type="password"
              id="apiSecret"
              value={apiSecret}
              onChange={(e) => setApiSecret(e.target.value)}
            />
          </FormGroup>
          <FormGroup check>
            <Label check>
              <Input
                type="checkbox"
                checked={enabled}
                onChange={() => setEnabled(!enabled)}
              />{" "}
              Enable Integration
            </Label>
          </FormGroup>
          <Button color="primary" type="submit" className="mt-3">
            Save Changes
          </Button>
        </Form>
      </CardBody>
    </Card>
  )
}

export default Integration
