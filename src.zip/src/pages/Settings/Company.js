import React, { useState } from "react"
import {
  Card,
  CardBody,
  Form,
  FormGroup,
  Label,
  Input,
  Button,
} from "reactstrap"

const Company = () => {
  const [companyName, setCompanyName] = useState("Example Corp")
  const [address, setAddress] = useState("123 Main St, City, Country")
  const [phone, setPhone] = useState("+123 456 7890")
  const [email, setEmail] = useState("info@example.com")

  const handleSave = (e) => {
    e.preventDefault()
    // Here you can add save logic, e.g., API call
    alert("Company information saved successfully!")
  }

  return (
    <Card>
      <CardBody>
        <h5>Company Information</h5>
        <Form onSubmit={handleSave}>
          <FormGroup>
            <Label for="companyName">Company Name</Label>
            <Input
              type="text"
              id="companyName"
              value={companyName}
              onChange={(e) => setCompanyName(e.target.value)}
              required
            />
          </FormGroup>
          <FormGroup>
            <Label for="address">Address</Label>
            <Input
              type="textarea"
              id="address"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              required
            />
          </FormGroup>
          <FormGroup>
            <Label for="phone">Phone</Label>
            <Input
              type="text"
              id="phone"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              required
            />
          </FormGroup>
          <FormGroup>
            <Label for="email">Email</Label>
            <Input
              type="email"
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </FormGroup>
          <Button color="primary" type="submit">
            Save
          </Button>
        </Form>
      </CardBody>
    </Card>
  )
}

export default Company
