import React, { useState } from "react"
import {
  Card,
  CardBody,
  Form,
  FormGroup,
  Label,
  Input,
  Button,
} from "reactstrap"

const Notifications = () => {
  const [emailNotifications, setEmailNotifications] = useState(true)
  const [smsNotifications, setSmsNotifications] = useState(false)
  const [pushNotifications, setPushNotifications] = useState(true)

  const handleSaveNotifications = (e) => {
    e.preventDefault()
    console.log("Notifications Settings Saved:", {
      emailNotifications,
      smsNotifications,
      pushNotifications,
    })
    alert("Notifications settings saved successfully!")
  }

  return (
    <Card>
      <CardBody>
        <h5>Notifications Settings</h5>
        <Form onSubmit={handleSaveNotifications}>
          <FormGroup check>
            <Label check>
              <Input
                type="checkbox"
                checked={emailNotifications}
                onChange={() => setEmailNotifications(!emailNotifications)}
              />{" "}
              Email Notifications
            </Label>
          </FormGroup>
          <FormGroup check>
            <Label check>
              <Input
                type="checkbox"
                checked={smsNotifications}
                onChange={() => setSmsNotifications(!smsNotifications)}
              />{" "}
              SMS Notifications
            </Label>
          </FormGroup>
          <FormGroup check>
            <Label check>
              <Input
                type="checkbox"
                checked={pushNotifications}
                onChange={() => setPushNotifications(!pushNotifications)}
              />{" "}
              Push Notifications
            </Label>
          </FormGroup>
          <Button color="primary" type="submit" className="mt-3">
            Save Changes
          </Button>
        </Form>
      </CardBody>
    </Card>
  )
}

export default Notifications
