import React, { useState } from "react"
import {
  Card,
  CardBody,
  Form,
  FormGroup,
  Label,
  Input,
  Button,
} from "reactstrap"

const General = () => {
  const [siteLogo, setSiteLogo] = useState(null)
  const [siteLogoPreview, setSiteLogoPreview] = useState(null)
  const [favicon, setFavicon] = useState(null)
  const [faviconPreview, setFaviconPreview] = useState(null)
  const [showLogoSignin, setShowLogoSignin] = useState("Yes")
  const [showBgSignin, setShowBgSignin] = useState("Yes")
  const [signinBg, setSigninBg] = useState(null)
  const [signinBgPreview, setSigninBgPreview] = useState(null)
  const [appTitle, setAppTitle] = useState("TownsTech Projects")
  const [acceptedFileFormat, setAcceptedFileFormat] = useState("jpg,jpeg,png,doc,xlsx,txt,pdf,zip,webm")
  const [landingPage, setLandingPage] = useState("Landing page")
  const [rowsPerPage, setRowsPerPage] = useState("10")

  const handleSiteLogoChange = (e) => {
    const file = e.target.files[0]
    setSiteLogo(file)
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setSiteLogoPreview(reader.result)
      }
      reader.readAsDataURL(file)
    } else {
      setSiteLogoPreview(null)
    }
  }

  const handleFaviconChange = (e) => {
    const file = e.target.files[0]
    setFavicon(file)
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setFaviconPreview(reader.result)
      }
      reader.readAsDataURL(file)
    } else {
      setFaviconPreview(null)
    }
  }

  const handleSigninBgChange = (e) => {
    const file = e.target.files[0]
    setSigninBg(file)
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setSigninBgPreview(reader.result)
      }
      reader.readAsDataURL(file)
    } else {
      setSigninBgPreview(null)
    }
  }

  const handleSaveGeneral = (e) => {
    e.preventDefault()
    console.log("General Settings Saved:", {
      siteLogo,
      favicon,
      showLogoSignin,
      showBgSignin,
      signinBg,
      appTitle,
      acceptedFileFormat,
      landingPage,
      rowsPerPage,
    })
    alert("General settings saved successfully!")
  }

  return (
    <Card>
      <CardBody>
        <Form onSubmit={handleSaveGeneral}>
          <FormGroup>
            <Label>Site Logo (175x40)</Label>
            <div className="d-flex align-items-center">
              {siteLogoPreview ? (
                <img src={siteLogoPreview} alt="Site Logo Preview" style={{ height: 40, marginRight: 10 }} />
              ) : (
                <div style={{ width: 175, height: 40, backgroundColor: "#eee", marginRight: 10 }} />
              )}
              <Input type="file" accept="image/*" onChange={handleSiteLogoChange} />
            </div>
          </FormGroup>
          <FormGroup>
            <Label>Favicon (32x32)</Label>
            <div className="d-flex align-items-center">
              {faviconPreview ? (
                <img src={faviconPreview} alt="Favicon Preview" style={{ height: 32, marginRight: 10 }} />
              ) : (
                <div style={{ width: 32, height: 32, backgroundColor: "#eee", marginRight: 10 }} />
              )}
              <Input type="file" accept="image/*" onChange={handleFaviconChange} />
            </div>
          </FormGroup>
          <FormGroup>
            <Label for="showLogoSignin">Show logo in signin page</Label>
            <Input
              type="select"
              id="showLogoSignin"
              value={showLogoSignin}
              onChange={(e) => setShowLogoSignin(e.target.value)}
            >
              <option>Yes</option>
              <option>No</option>
            </Input>
          </FormGroup>
          <FormGroup>
            <Label for="showBgSignin">Show background image in signin page</Label>
            <Input
              type="select"
              id="showBgSignin"
              value={showBgSignin}
              onChange={(e) => setShowBgSignin(e.target.value)}
            >
              <option>Yes</option>
              <option>No</option>
            </Input>
          </FormGroup>
          <FormGroup>
            <Label>Signin page background</Label>
            <div className="d-flex align-items-center">
              {signinBgPreview ? (
                <img src={signinBgPreview} alt="Signin Background Preview" style={{ height: 40, marginRight: 10 }} />
              ) : (
                <div style={{ width: 175, height: 40, backgroundColor: "#eee", marginRight: 10 }} />
              )}
              <Input type="file" accept="image/*" onChange={handleSigninBgChange} />
            </div>
          </FormGroup>
          <FormGroup>
            <Label for="appTitle">App Title</Label>
            <Input
              type="text"
              id="appTitle"
              value={appTitle}
              onChange={(e) => setAppTitle(e.target.value)}
            />
          </FormGroup>
          <FormGroup>
            <Label for="acceptedFileFormat">Accepted file format</Label>
            <Input
              type="text"
              id="acceptedFileFormat"
              value={acceptedFileFormat}
              onChange={(e) => setAcceptedFileFormat(e.target.value)}
            />
          </FormGroup>
          <FormGroup>
            <Label for="landingPage">Landing page</Label>
            <Input
              type="select"
              id="landingPage"
              value={landingPage}
              onChange={(e) => setLandingPage(e.target.value)}
            >
              <option>Landing page</option>
              <option>Dashboard</option>
              <option>Profile</option>
            </Input>
          </FormGroup>
          <FormGroup>
            <Label for="rowsPerPage">Rows per page</Label>
            <Input
              type="select"
              id="rowsPerPage"
              value={rowsPerPage}
              onChange={(e) => setRowsPerPage(e.target.value)}
            >
              <option>10</option>
              <option>20</option>
              <option>50</option>
              <option>100</option>
            </Input>
          </FormGroup>
          <Button color="primary" className="mt-3" type="submit">
            Save Changes
          </Button>
        </Form>
      </CardBody>
    </Card>
  )
}

export default General
