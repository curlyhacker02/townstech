/* eslint-disable no-unused-vars */
import React, { useState } from "react"
import {
  Card,
  CardBody,
  CardHeader,
  Col,
  Container,
  Row,
  Table,
  Button,
  Badge,
} from "reactstrap"

const dummyClients = [
  { id: 1, name: "Acme Corp", email: "contact@acme.com", phone: "123-456-7890", status: "Active" },
  { id: 2, name: "Globex Inc", email: "info@globex.com", phone: "987-654-3210", status: "Inactive" },
  { id: 3, name: "Soylent Corp", email: "hello@soylent.com", phone: "555-555-5555", status: "Active" },
  { id: 4, name: "Initech", email: "support@initech.com", phone: "444-444-4444", status: "Active" },
  { id: 5, name: "Umbrella Corp", email: "contact@umbrella.com", phone: "333-333-3333", status: "Inactive" },
]

const Clients = () => {
  const [clients, setClients] = useState(dummyClients)

  return (
    <Container fluid>
      <Row className="mb-4">
        <Col>
          <h4 className="page-title">Clients</h4>
        </Col>
      </Row>
      <Row>
        <Col>
          <Card>
            <CardHeader>
              <Button color="primary" className="float-end">
                Add Client
              </Button>
              <h5 className="card-title mb-0">Client List</h5>
            </CardHeader>
            <CardBody>
              <Table responsive hover>
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Client Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Status</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {clients.map(client => (
                    <tr key={client.id}>
                      <th scope="row">{client.id}</th>
                      <td>{client.name}</td>
                      <td>{client.email}</td>
                      <td>{client.phone}</td>
                      <td>
                        <Badge color={client.status === "Active" ? "success" : "secondary"}>
                          {client.status}
                        </Badge>
                      </td>
                      <td>
                        <Button color="info" size="sm" className="me-2">
                          Edit
                        </Button>
                        <Button color="danger" size="sm">
                          Delete
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            </CardBody>
          </Card>
        </Col>
      </Row>
    </Container>
  )
}

export default Clients
