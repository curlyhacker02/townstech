/* eslint-disable no-unused-vars */
import React, { useState } from "react"
import {
  Card,
  CardBody,
  CardHeader,
  Col,
  Container,
  Row,
  Table,
  Button,
  Badge,
} from "reactstrap"

const dummySubscriptions = [
  { id: 1, name: "Basic Plan", client: "Acme Corp", status: "Active", startDate: "2023-01-01", endDate: "2023-12-31" },
  { id: 2, name: "Pro Plan", client: "Globex Inc", status: "Expired", startDate: "2022-01-01", endDate: "2022-12-31" },
  { id: 3, name: "Enterprise Plan", client: "Soylent Corp", status: "Active", startDate: "2023-03-01", endDate: "2024-02-28" },
  { id: 4, name: "Basic Plan", client: "Initech", status: "Cancelled", startDate: "2022-06-01", endDate: "2023-05-31" },
  { id: 5, name: "Pro Plan", client: "Umbrella Corp", status: "Active", startDate: "2023-04-01", endDate: "2024-03-31" },
]

const Subscriptions = () => {
  const [subscriptions, setSubscriptions] = useState(dummySubscriptions)

  const getStatusColor = (status) => {
    switch (status) {
      case "Active":
        return "success"
      case "Expired":
        return "danger"
      case "Cancelled":
        return "secondary"
      default:
        return "primary"
    }
  }

  return (
    <Container fluid>
      <Row className="mb-4">
        <Col>
          <h4 className="page-title">Subscriptions</h4>
        </Col>
      </Row>
      <Row>
        <Col>
          <Card>
            <CardHeader>
              <Button color="primary" className="float-end">
                Add Subscription
              </Button>
              <h5 className="card-title mb-0">Subscription List</h5>
            </CardHeader>
            <CardBody>
              <Table responsive hover>
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Subscription Name</th>
                    <th>Client</th>
                    <th>Status</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {subscriptions.map(subscription => (
                    <tr key={subscription.id}>
                      <th scope="row">{subscription.id}</th>
                      <td>{subscription.name}</td>
                      <td>{subscription.client}</td>
                      <td>
                        <Badge color={getStatusColor(subscription.status)}>
                          {subscription.status}
                        </Badge>
                      </td>
                      <td>{subscription.startDate}</td>
                      <td>{subscription.endDate}</td>
                      <td>
                        <Button color="info" size="sm" className="me-2">
                          Edit
                        </Button>
                        <Button color="danger" size="sm">
                          Delete
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            </CardBody>
          </Card>
        </Col>
      </Row>
    </Container>
  )
}

export default Subscriptions
