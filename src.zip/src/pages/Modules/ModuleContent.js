import React, { useEffect, useState } from "react"
import { useParams } from "react-router-dom"

const ModuleContent = () => {
  const { key } = useParams()
  const [moduleContent, setModuleContent] = useState("")

  useEffect(() => {
    const modules = JSON.parse(localStorage.getItem("dashboardModulesFull")) || []
    const module = modules.find(mod => mod.key === key)
    if (module && module.jsContent) {
      setModuleContent(module.jsContent)
    } else {
      setModuleContent("<p>No content available for this module.</p>")
    }
  }, [key])

  return (
    <div style={{ padding: "1rem" }}>
      <h2>Module: {key}</h2>
      <div
        style={{ whiteSpace: "pre-wrap", backgroundColor: "#f5f5f5", padding: "1rem", borderRadius: "4px" }}
        dangerouslySetInnerHTML={{ __html: moduleContent }}
      />
    </div>
  )
}

export default ModuleContent
