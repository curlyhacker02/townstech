/* eslint-disable no-unused-vars */
import React, { useState } from "react"
import {
  Card,
  CardBody,
  CardHeader,
  Col,
  Container,
  Row,
  Table,
  Button,
  Badge,
} from "reactstrap"

const dummyFiles = [
  { id: 1, name: "ProjectPlan.docx", type: "Document", size: "1.2 MB", modified: "2023-06-30" },
  { id: 2, name: "Budget.xlsx", type: "Spreadsheet", size: "800 KB", modified: "2023-06-28" },
  { id: 3, name: "Presentation.pptx", type: "Presentation", size: "2.5 MB", modified: "2023-06-27" },
  { id: 4, name: "Logo.png", type: "Image", size: "500 KB", modified: "2023-06-25" },
  { id: 5, name: "Contract.pdf", type: "PDF", size: "1.8 MB", modified: "2023-06-24" },
]

const Files = () => {
  const [files, setFiles] = useState(dummyFiles)

  const getTypeColor = (type) => {
    switch (type) {
      case "Document":
        return "primary"
      case "Spreadsheet":
        return "success"
      case "Presentation":
        return "info"
      case "Image":
        return "warning"
      case "PDF":
        return "danger"
      default:
        return "secondary"
    }
  }

  return (
    <Container fluid>
      <Row className="mb-4">
        <Col>
          <h4 className="page-title">Files</h4>
        </Col>
      </Row>
      <Row>
        <Col>
          <Card>
            <CardHeader>
              <Button color="primary" className="float-end">
                Upload File
              </Button>
              <h5 className="card-title mb-0">File List</h5>
            </CardHeader>
            <CardBody>
              <Table responsive hover>
                <thead>
                  <tr>
                    <th>#</th>
                    <th>File Name</th>
                    <th>Type</th>
                    <th>Size</th>
                    <th>Date Modified</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {files.map(file => (
                    <tr key={file.id}>
                      <th scope="row">{file.id}</th>
                      <td>{file.name}</td>
                      <td>
                        <Badge color={getTypeColor(file.type)}>
                          {file.type}
                        </Badge>
                      </td>
                      <td>{file.size}</td>
                      <td>{file.modified}</td>
                      <td>
                        <Button color="info" size="sm" className="me-2">
                          View
                        </Button>
                        <Button color="danger" size="sm">
                          Delete
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            </CardBody>
          </Card>
        </Col>
      </Row>
    </Container>
  )
}

export default Files
