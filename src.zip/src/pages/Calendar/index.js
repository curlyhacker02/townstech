/* eslint-disable no-unused-vars */
import React, { useEffect, useState, useRef } from "react"
import PropTypes from "prop-types"
import { connect } from "react-redux"
import { isEmpty } from "lodash"
import { setBreadcrumbItems } from '../../store/actions';
import { Link } from "react-router-dom";

import {
  Button,
  Card,
  CardBody,
  Col,
  Modal,
  ModalBody,
  ModalHeader,
  Row,
  FormGroup,
  Label,
  Input,
} from "reactstrap"

import FullCalendar from "@fullcalendar/react"
import dayGridPlugin from "@fullcalendar/daygrid"
import interactionPlugin, { Draggable } from "@fullcalendar/interaction"
import BootstrapTheme from "@fullcalendar/bootstrap"
import listPlugin from '@fullcalendar/list';

import {
  addNewEvent,
  deleteEvent,
  getCategories,
  getEvents,
  updateEvent,
} from "../../store/actions"
import DeleteModal from "./DeleteModal"

const Calendar = props => {
  document.title = "Events | TownsTech Admin Dashboard";

  const { events, categories, onGetCategories, onGetEvents } = props
  const [calendarView, setCalendarView] = useState("dayGridMonth")
  const [modal, setModal] = useState(false)
  const [deleteModal, setDeleteModal] = useState(false)
  const [event, setEvent] = useState({
    title: '',
    description: '',
    startDate: '',
    startTime: '',
    endDate: '',
    endTime: '',
    location: '',
    labels: '',
    client: '',
    shareWith: 'onlyMe',
    repeat: false
  })
  const [selectedDay, setSelectedDay] = useState(null)
  const [isEdit, setIsEdit] = useState(false)

  const calendarRef = useRef();
  
  const getApi = () => {
    const { current: calendarDom } = calendarRef;
    return calendarDom ? calendarDom.getApi() : null;
  }

  const changeView = (view, API) => {
    API && API.changeView(view);
  };

  useEffect(() => {
    onGetCategories()
    onGetEvents()
    new Draggable(document.getElementById("external-events"), {
      itemSelector: ".external-event",
    })

    getInitialView()
    const api = getApi();
    changeView(calendarView, api);
  }, [onGetCategories, onGetEvents, calendarView])

  useEffect(() => {
    if (!modal && !isEmpty(event) && !!isEdit) {
      setTimeout(() => {
        setEvent({})
        setIsEdit(false)
      }, 500)
    }
  }, [modal, event, isEdit])

  const toggle = () => {
    setModal(!modal)
  }

  const handleDateClick = arg => {
    const dateStr = arg.dateStr;
    setEvent(prev => ({
      ...prev,
      startDate: dateStr,
      endDate: dateStr
    }));
    setSelectedDay(arg)
    toggle()
  }

  const handleEventClick = arg => {
    const calendarEvent = arg.event
    setEvent({
      id: calendarEvent.id,
      title: calendarEvent.title,
      description: calendarEvent.extendedProps?.description || '',
      startDate: calendarEvent.startStr.split('T')[0],
      startTime: calendarEvent.startStr.split('T')[1]?.substring(0, 5) || '',
      endDate: calendarEvent.endStr ? calendarEvent.endStr.split('T')[0] : calendarEvent.startStr.split('T')[0],
      endTime: calendarEvent.endStr ? calendarEvent.endStr.split('T')[1]?.substring(0, 5) : '',
      location: calendarEvent.extendedProps?.location || '',
      labels: calendarEvent.extendedProps?.labels || '',
      client: calendarEvent.extendedProps?.client || '',
      className: calendarEvent.classNames,
      category: calendarEvent.classNames[0],
    })
    setIsEdit(true)
    toggle()
  }

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setEvent(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  }

  const handleSubmit = (e) => {
    e.preventDefault();
    const { onAddNewEvent, onUpdateEvent } = props;
    
    const eventData = {
      id: isEdit ? event.id : Math.floor(Math.random() * 100),
      title: event.title,
      start: `${event.startDate}T${event.startTime}:00`,
      end: `${event.endDate}T${event.endTime}:00`,
      className: event.category || "bg-primary",
      extendedProps: {
        description: event.description,
        location: event.location,
        labels: event.labels,
        client: event.client,
        shareWith: event.shareWith,
        repeat: event.repeat
      }
    };

    if (isEdit) {
      onUpdateEvent(eventData);
    } else {
      onAddNewEvent(eventData);
    }
    
    toggle();
  }

  const handleDeleteEvent = () => {
    const { onDeleteEvent } = props;
    onDeleteEvent(event);
    setDeleteModal(false);
    toggle();
  }

  const onDrag = (event) => {
    event.preventDefault();
  }

  const onDrop = event => {
    const { onAddNewEvent } = props;
    const draggedEl = event.draggedEl;
    const newEvent = {
      id: Math.floor(Math.random() * 100),
      title: draggedEl.innerText,
      start: event.date,
      className: draggedEl.className,
    }
    onAddNewEvent(newEvent);
  }

  const getInitialView = () => {
    if (window.innerWidth >= 768 && window.innerWidth < 1200) {
      setCalendarView('dayGridWeek');
    } else if (window.innerWidth <= 768) {
      setCalendarView('listWeek');
    } else {
      setCalendarView('dayGridMonth');
    }
  }

  const breadcrumbItems = [
    { title: "Townstech", link: "#" },
    { title: "Calendar", link: "#" },
  ]

  useEffect(() => {
    props.onSetBreadCrumbs('Calendar', breadcrumbItems);
  });

  return (
    <React.Fragment>
      <DeleteModal
        show={deleteModal}
        onDeleteClick={handleDeleteEvent}
        onCloseClick={() => setDeleteModal(false)}
      />

      <Row className="mb-4">
        <Col xl={3}>
          <Card>
            <CardBody className="d-grid">
              <div className="d-grid">
                <Button
                  color="primary"
                  className="btn-block"
                  onClick={toggle}
                >
                  <i className="mdi mdi-plus-circle-outline" />
                  {" "}Create New Event
                </Button>
              </div>
              <div id="external-events">
                <br />
                <p className="text-muted">
                  Drag and drop your event or click in the calendar
                </p>
                {categories &&
                  categories.map((category, i) => (
                    <div
                      className={`external-event fc-event ${category.type} text-white`}
                      key={"cat-" + category.id}
                      draggable
                      onDrag={event => onDrag(event, category)}
                    >
                      <i className="mdi mdi-checkbox-blank-circle font-size-11 me-2" />
                      {category.title}
                    </div>
                  ))}
              </div>

              <div className="mt-5">
                <h5 className="font-size-14 mb-4">Recent activity :</h5>
                <ul className="list-unstyled activity-feed ms-1">
                  <li className="feed-item">
                    <div className="feed-item-list">
                      <div>
                        <div className="date">15 Jul</div>
                        <p className="activity-text mb-0">Responded to need "Volunteer Activities"</p>
                      </div>
                    </div>
                  </li>
                  <li className="feed-item">
                    <div className="feed-item-list">
                      <div>
                        <div className="date">14 Jul</div>
                        <p className="activity-text mb-0">neque porro quisquam est <Link to="" className="text-success">@Christi</Link> dolorem ipsum quia dolor sit amet</p>
                      </div>
                    </div>
                  </li>
                </ul>
              </div>
            </CardBody>
          </Card>
        </Col>
        <Col className="col-xl-9">
          <div className="card mt-4 mt-xl-0 mb-0">
            <div className="card-body">
              <FullCalendar
                plugins={[
                  BootstrapTheme,
                  dayGridPlugin,
                  interactionPlugin,
                  listPlugin
                ]}
                slotDuration={"00:15:00"}
                handleWindowResize={true}
                themeSystem="bootstrap"
                headerToolbar={{
                  left: "prev,next today",
                  center: "title",
                  right: "dayGridMonth,dayGridWeek,dayGridDay,listWeek",
                }}
                events={events}
                editable={true}
                droppable={true}
                selectable={true}
                dateClick={handleDateClick}
                eventClick={handleEventClick}
                drop={onDrop}
                ref={calendarRef}
                initialView={calendarView}
                windowResize={getInitialView}
              />

              {/* Event Modal */}
              <Modal isOpen={modal} toggle={toggle} size="lg">
                <ModalHeader toggle={toggle}>
                  {isEdit ? "Edit Event" : "Add Event"}
                </ModalHeader>
                <ModalBody>
                  <form onSubmit={handleSubmit}>
                    <Row>
                      <Col md={6}>
                        <FormGroup>
                          <Label>Title</Label>
                          <Input
                            type="text"
                            name="title"
                            value={event.title}
                            onChange={handleInputChange}
                            placeholder="Title"
                            required
                          />
                        </FormGroup>
                      </Col>
                      <Col md={6}>
                        <FormGroup>
                          <Label>Description</Label>
                          <Input
                            type="text"
                            name="description"
                            value={event.description}
                            onChange={handleInputChange}
                            placeholder="Description"
                          />
                        </FormGroup>
                      </Col>
                    </Row>

                    <Row>
                      <Col md={6}>
                        <FormGroup>
                          <Label>Start Date</Label>
                          <Input
                            type="date"
                            name="startDate"
                            value={event.startDate}
                            onChange={handleInputChange}
                            required
                          />
                        </FormGroup>
                      </Col>
                      <Col md={6}>
                        <FormGroup>
                          <Label>Start Time</Label>
                          <Input
                            type="time"
                            name="startTime"
                            value={event.startTime}
                            onChange={handleInputChange}
                          />
                        </FormGroup>
                      </Col>
                    </Row>

                    <Row>
                      <Col md={6}>
                        <FormGroup>
                          <Label>End Date</Label>
                          <Input
                            type="date"
                            name="endDate"
                            value={event.endDate}
                            onChange={handleInputChange}
                          />
                        </FormGroup>
                      </Col>
                      <Col md={6}>
                        <FormGroup>
                          <Label>End Time</Label>
                          <Input
                            type="time"
                            name="endTime"
                            value={event.endTime}
                            onChange={handleInputChange}
                          />
                        </FormGroup>
                      </Col>
                    </Row>

                    <Row>
                      <Col md={6}>
                        <FormGroup>
                          <Label>Location</Label>
                          <Input
                            type="text"
                            name="location"
                            value={event.location}
                            onChange={handleInputChange}
                            placeholder="Location"
                          />
                        </FormGroup>
                      </Col>
                      <Col md={6}>
                        <FormGroup>
                          <Label>Labels</Label>
                          <Input
                            type="text"
                            name="labels"
                            value={event.labels}
                            onChange={handleInputChange}
                            placeholder="Labels"
                          />
                        </FormGroup>
                      </Col>
                    </Row>

                    <Row>
                      <Col md={6}>
                        <FormGroup>
                          <Label>Client</Label>
                          <Input
                            type="select"
                            name="client"
                            value={event.client}
                            onChange={handleInputChange}
                          >
                            <option value="">-</option>
                            <option value="client1">Client 1</option>
                            <option value="client2">Client 2</option>
                          </Input>
                        </FormGroup>
                      </Col>
                    </Row>

                    <Row className="mt-3">
                      <Col>
                        <FormGroup>
                          <Label>Share with</Label>
                          <div>
                            <Input
                              type="radio"
                              id="onlyMe"
                              name="shareWith"
                              label="Only me"
                              value="onlyMe"
                              checked={event.shareWith === 'onlyMe'}
                              onChange={handleInputChange}
                              inline
                            />
                            <Input
                              type="radio"
                              id="allTeam"
                              name="shareWith"
                              label="All team members"
                              value="allTeam"
                              checked={event.shareWith === 'allTeam'}
                              onChange={handleInputChange}
                              inline
                            />
                            <Input
                              type="radio"
                              id="specific"
                              name="shareWith"
                              label="Specific members and teams"
                              value="specific"
                              checked={event.shareWith === 'specific'}
                              onChange={handleInputChange}
                              inline
                            />
                          </div>
                        </FormGroup>
                      </Col>
                    </Row>

                    <Row>
                      <Col>
                        <FormGroup check>
                          <Label check>
                            <Input
                              type="checkbox"
                              name="repeat"
                              checked={event.repeat}
                              onChange={handleInputChange}
                            />{' '}
                            Repeat
                          </Label>
                        </FormGroup>
                      </Col>
                    </Row>

                    <Row className="mt-4">
                      <Col className="text-end">
                        <Button color="light" className="me-2" onClick={toggle}>
                          Close
                        </Button>
                        {isEdit && (
                          <Button color="danger" className="me-2" onClick={() => setDeleteModal(true)}>
                            Delete
                          </Button>
                        )}
                        <Button color="primary" type="submit">
                          Save Event
                        </Button>
                      </Col>
                    </Row>
                  </form>
                </ModalBody>
              </Modal>
            </div>
          </div>
        </Col>
      </Row>
    </React.Fragment>
  )
}

Calendar.propTypes = {
  events: PropTypes.array,
  categories: PropTypes.array,
  className: PropTypes.string,
  onGetEvents: PropTypes.func,
  onAddNewEvent: PropTypes.func,
  onUpdateEvent: PropTypes.func,
  onDeleteEvent: PropTypes.func,
  onGetCategories: PropTypes.func,
  onSetBreadCrumbs: PropTypes.func,
}

const mapStateToProps = ({ calendar }) => ({
  events: calendar.events,
  categories: calendar.categories,
})

const mapDispatchToProps = dispatch => ({
  onGetEvents: () => dispatch(getEvents()),
  onGetCategories: () => dispatch(getCategories()),
  onAddNewEvent: event => dispatch(addNewEvent(event)),
  onUpdateEvent: event => dispatch(updateEvent(event)),
  onDeleteEvent: event => dispatch(deleteEvent(event)),
  onSetBreadCrumbs: (title, breadcrumbItems) => dispatch(setBreadcrumbItems(title, breadcrumbItems)),
})

export default connect(mapStateToProps, mapDispatchToProps)(Calendar)