import React, { useState } from "react"
import {
  Container,
  Row,
  Col,
  Nav,
  NavItem,
  NavLink,
  TabContent,
  TabPane,
  Table,
  Badge,
  Button,
} from "reactstrap"
import classnames from "classnames"

const dummyMessages = {
  inbox: [
    { id: 1, sender: "alice@example.com", subject: "Meeting Reminder", date: "2023-07-01", read: false },
    { id: 2, sender: "bob@example.com", subject: "Project Update", date: "2023-06-30", read: true },
  ],
  outbox: [
    { id: 3, recipient: "charlie@example.com", subject: "Invoice", date: "2023-06-29", sent: true },
  ],
  drafts: [
    { id: 4, recipient: "dave@example.com", subject: "Draft Proposal", date: "2023-06-28" },
  ],
  spam: [
    { id: 5, sender: "spam@example.com", subject: "You won a prize!", date: "2023-06-27" },
  ],
  trash: [
    { id: 6, sender: "eve@example.com", subject: "Old Message", date: "2023-06-26" },
  ],
}

const Messages = () => {
  const [activeTab, setActiveTab] = useState("inbox")

  const toggle = (tab) => {
    if (activeTab !== tab) setActiveTab(tab)
  }

  return (
    <Container fluid>
      <Row className="mb-4">
        <Col>
          <h4 className="page-title">Messages</h4>
        </Col>
      </Row>
      <Row>
        <Col md="3">
          <Nav vertical pills>
            <NavItem>
              <NavLink
                className={classnames({ active: activeTab === "inbox" })}
                onClick={() => { toggle("inbox") }}
                href="#"
              >
                Inbox <Badge color="primary">{dummyMessages.inbox.length}</Badge>
              </NavLink>
            </NavItem>
            <NavItem>
              <NavLink
                className={classnames({ active: activeTab === "outbox" })}
                onClick={() => { toggle("outbox") }}
                href="#"
              >
                Outbox <Badge color="secondary">{dummyMessages.outbox.length}</Badge>
              </NavLink>
            </NavItem>
            <NavItem>
              <NavLink
                className={classnames({ active: activeTab === "drafts" })}
                onClick={() => { toggle("drafts") }}
                href="#"
              >
                Drafts <Badge color="warning">{dummyMessages.drafts.length}</Badge>
              </NavLink>
            </NavItem>
            <NavItem>
              <NavLink
                className={classnames({ active: activeTab === "spam" })}
                onClick={() => { toggle("spam") }}
                href="#"
              >
                Spam <Badge color="danger">{dummyMessages.spam.length}</Badge>
              </NavLink>
            </NavItem>
            <NavItem>
              <NavLink
                className={classnames({ active: activeTab === "trash" })}
                onClick={() => { toggle("trash") }}
                href="#"
              >
                Trash <Badge color="dark">{dummyMessages.trash.length}</Badge>
              </NavLink>
            </NavItem>
          </Nav>
        </Col>
        <Col md="9">
          <TabContent activeTab={activeTab}>
            <TabPane tabId="inbox">
              <Table hover responsive>
                <thead>
                  <tr>
                    <th>Sender</th>
                    <th>Subject</th>
                    <th>Date</th>
                    <th>Read</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {dummyMessages.inbox.map(msg => (
                    <tr key={msg.id} className={msg.read ? "" : "font-weight-bold"}>
                      <td>{msg.sender}</td>
                      <td>{msg.subject}</td>
                      <td>{msg.date}</td>
                      <td>{msg.read ? "Yes" : "No"}</td>
                      <td>
                        <Button size="sm" color="info" className="me-2">View</Button>
                        <Button size="sm" color="danger">Delete</Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            </TabPane>
            <TabPane tabId="outbox">
              <Table hover responsive>
                <thead>
                  <tr>
                    <th>Recipient</th>
                    <th>Subject</th>
                    <th>Date</th>
                    <th>Sent</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {dummyMessages.outbox.map(msg => (
                    <tr key={msg.id}>
                      <td>{msg.recipient}</td>
                      <td>{msg.subject}</td>
                      <td>{msg.date}</td>
                      <td>{msg.sent ? "Yes" : "No"}</td>
                      <td>
                        <Button size="sm" color="info" className="me-2">View</Button>
                        <Button size="sm" color="danger">Delete</Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            </TabPane>
            <TabPane tabId="drafts">
              <Table hover responsive>
                <thead>
                  <tr>
                    <th>Recipient</th>
                    <th>Subject</th>
                    <th>Date</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {dummyMessages.drafts.map(msg => (
                    <tr key={msg.id}>
                      <td>{msg.recipient}</td>
                      <td>{msg.subject}</td>
                      <td>{msg.date}</td>
                      <td>
                        <Button size="sm" color="info" className="me-2">Edit</Button>
                        <Button size="sm" color="danger">Delete</Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            </TabPane>
            <TabPane tabId="spam">
              <Table hover responsive>
                <thead>
                  <tr>
                    <th>Sender</th>
                    <th>Subject</th>
                    <th>Date</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {dummyMessages.spam.map(msg => (
                    <tr key={msg.id}>
                      <td>{msg.sender}</td>
                      <td>{msg.subject}</td>
                      <td>{msg.date}</td>
                      <td>
                        <Button size="sm" color="info" className="me-2">View</Button>
                        <Button size="sm" color="danger">Delete</Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            </TabPane>
            <TabPane tabId="trash">
              <Table hover responsive>
                <thead>
                  <tr>
                    <th>Sender</th>
                    <th>Subject</th>
                    <th>Date</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {dummyMessages.trash.map(msg => (
                    <tr key={msg.id}>
                      <td>{msg.sender}</td>
                      <td>{msg.subject}</td>
                      <td>{msg.date}</td>
                      <td>
                        <Button size="sm" color="info" className="me-2">Restore</Button>
                        <Button size="sm" color="danger">Delete</Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            </TabPane>
          </TabContent>
        </Col>
      </Row>
    </Container>
  )
}

export default Messages
