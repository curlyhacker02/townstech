/* eslint-disable no-unused-vars */
import React, { useState } from "react"
import {
  Card,
  CardBody,
  CardHeader,
  Col,
  Container,
  Row,
  Table,
  Button,
  Badge,
} from "reactstrap"

const dummyLeads = [
  { id: 1, name: "John Doe", email: "john@example.com", phone: "123-456-7890", status: "New", source: "Website" },
  { id: 2, name: "Jane Smith", email: "jane@example.com", phone: "987-654-3210", status: "Contacted", source: "Referral" },
  { id: 3, name: "Alice Johnson", email: "alice@example.com", phone: "555-555-5555", status: "Qualified", source: "Email Campaign" },
  { id: 4, name: "Bob Brown", email: "bob@example.com", phone: "444-444-4444", status: "Lost", source: "Cold Call" },
  { id: 5, name: "Charlie Davis", email: "charlie@example.com", phone: "333-333-3333", status: "New", source: "Trade Show" },
]

const Leads = () => {
  const [leads, setLeads] = useState(dummyLeads)

  const getStatusColor = (status) => {
    switch (status) {
      case "New":
        return "primary"
      case "Contacted":
        return "info"
      case "Qualified":
        return "success"
      case "Lost":
        return "danger"
      default:
        return "secondary"
    }
  }

  return (
    <Container fluid>
      <Row className="mb-4">
        <Col>
          <h4 className="page-title">Leads</h4>
        </Col>
      </Row>
      <Row>
        <Col>
          <Card>
            <CardHeader>
              <Button color="primary" className="float-end">
                Add Lead
              </Button>
              <h5 className="card-title mb-0">Lead List</h5>
            </CardHeader>
            <CardBody>
              <Table responsive hover>
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Lead Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Status</th>
                    <th>Source</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {leads.map(lead => (
                    <tr key={lead.id}>
                      <th scope="row">{lead.id}</th>
                      <td>{lead.name}</td>
                      <td>{lead.email}</td>
                      <td>{lead.phone}</td>
                      <td>
                        <Badge color={getStatusColor(lead.status)}>
                          {lead.status}
                        </Badge>
                      </td>
                      <td>{lead.source}</td>
                      <td>
                        <Button color="info" size="sm" className="me-2">
                          Edit
                        </Button>
                        <Button color="danger" size="sm">
                          Delete
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            </CardBody>
          </Card>
        </Col>
      </Row>
    </Container>
  )
}

export default Leads
