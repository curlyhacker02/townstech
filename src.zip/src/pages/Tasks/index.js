/* eslint-disable no-unused-vars */
import React, { useState } from "react"
import {
  Card,
  CardBody,
  CardHeader,
  Col,
  Container,
  Row,
  Table,
  Button,
  Badge,
} from "reactstrap"

const dummyTasks = [
  { id: 1, title: "Design Homepage", assignedTo: "John Doe", status: "In Progress", dueDate: "2023-07-15", priority: "High" },
  { id: 2, title: "Develop API", assignedTo: "Jane Smith", status: "Completed", dueDate: "2023-06-30", priority: "Low" },
  { id: 3, title: "Test Login Flow", assignedTo: "Alice Johnson", status: "Pending", dueDate: "2023-07-20", priority: "Medium" },
  { id: 4, title: "Fix Bugs", assignedTo: "Bob Brown", status: "In Progress", dueDate: "2023-07-18", priority: "High" },
  { id: 5, title: "Deploy to Production", assignedTo: "Charlie Davis", status: "Pending", dueDate: "2023-07-25", priority: "Low" },
]

const Tasks = () => {
  const [tasks, setTasks] = useState(dummyTasks)

  const getStatusColor = (status) => {
    switch (status) {
      case "Completed":
        return "success"
      case "In Progress":
        return "primary"
      case "Pending":
        return "warning"
      default:
        return "secondary"
    }
  }

  const getPriorityIcon = (priority) => {
    switch (priority) {
      case "High":
        return <i className="mdi mdi-alert-circle text-danger" title="High Priority" />
      case "Medium":
        return <i className="mdi mdi-alert-circle-outline text-warning" title="Medium Priority" />
      case "Low":
        return <i className="mdi mdi-alert-circle-outline text-secondary" title="Low Priority" />
      default:
        return null
    }
  }

  return (
    <Container fluid>
      <Row className="mb-4">
        <Col>
          <h4 className="page-title">Tasks</h4>
        </Col>
      </Row>
      <Row>
        <Col>
          <Card>
            <CardHeader>
              <Button color="primary" className="float-end">
                Add Task
              </Button>
              <h5 className="card-title mb-0">Task List</h5>
            </CardHeader>
            <CardBody>
              <Table responsive hover>
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Task Title</th>
                    <th>Assigned To</th>
                    <th>Status</th>
                    <th>Due Date</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {tasks.map(task => (
              <tr key={task.id}>
                <th scope="row">{task.id}</th>
                <td>{task.title}</td>
                <td>{task.assignedTo}</td>
                <td>
                  <Badge color={getStatusColor(task.status)}>
                    {task.status}
                  </Badge>
                </td>
                <td>{task.dueDate}</td>
                <td>{getPriorityIcon(task.priority)}</td>
                <td>
                  <Button color="info" size="sm" className="me-2">
                    Edit
                  </Button>
                  <Button color="danger" size="sm">
                    Delete
                  </Button>
                </td>
              </tr>
                  ))}
                </tbody>
              </Table>
            </CardBody>
          </Card>
        </Col>
      </Row>
    </Container>
  )
}

export default Tasks
