/* eslint-disable no-unused-vars */
import React, { useState } from "react"
import {
  Card,
  CardBody,
  CardHeader,
  Col,
  Container,
  Row,
  Table,
  Button,
  Badge,
} from "reactstrap"

const dummyReports = [
  { id: 1, name: "Timesheet Report", date: "2023-07-01", status: "Completed" },
  { id: 2, name: "Project Status", date: "2023-06-30", status: "In Progress" },
  { id: 3, name: "Resource Allocation", date: "2023-06-29", status: "Completed" },
  { id: 4, name: "Expense Report", date: "2023-06-28", status: "Pending" },
  { id: 5, name: "Client Feedback", date: "2023-06-27", status: "Completed" },
]

const Reports = () => {
  const [reports, setReports] = useState(dummyReports)

  const getStatusColor = (status) => {
    switch (status) {
      case "Completed":
        return "success"
      case "In Progress":
        return "primary"
      case "Pending":
        return "warning"
      default:
        return "secondary"
    }
  }

  return (
    <Container fluid>
      <Row className="mb-4">
        <Col>
          <h4 className="page-title">Reports</h4>
        </Col>
      </Row>
      <Row>
        <Col>
          <Card>
            <CardHeader>
              <Button color="primary" className="float-end">
                Add Report
              </Button>
              <h5 className="card-title mb-0">Report List</h5>
            </CardHeader>
            <CardBody>
              <Table responsive hover>
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Report Name</th>
                    <th>Date</th>
                    <th>Status</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {reports.map(report => (
                    <tr key={report.id}>
                      <th scope="row">{report.id}</th>
                      <td>{report.name}</td>
                      <td>{report.date}</td>
                      <td>
                        <Badge color={getStatusColor(report.status)}>
                          {report.status}
                        </Badge>
                      </td>
                      <td>
                        <Button color="info" size="sm" className="me-2">
                          View
                        </Button>
                        <Button color="danger" size="sm">
                          Delete
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            </CardBody>
          </Card>
        </Col>
      </Row>
    </Container>
  )
}

export default Reports
