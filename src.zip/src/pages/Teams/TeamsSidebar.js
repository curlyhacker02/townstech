import React from "react"
import { ListGroup, ListGroupItem } from "reactstrap"
import { Link } from "react-router-dom"

const TeamsSidebar = ({ categories, selectedCategory, onSelectCategory }) => {
  return (
    <>
      <ListGroup>
        {categories.map((category) => (
          <ListGroupItem
            key={category.id}
            tag="button"
            action
            active={selectedCategory === category.id}
            onClick={() => onSelectCategory(category.id)}
          >
            {category.name}
          </ListGroupItem>
        ))}
      </ListGroup>
      <div className="mt-4">
        <h6>Team Links</h6>
        <ListGroup>
          <ListGroupItem tag={Link} to="/announcements" action>
            Announcements
          </ListGroupItem>
          <ListGroupItem tag={Link} to="/leave" action>
            Leave
          </ListGroupItem>
          <ListGroupItem tag={Link} to="/team-members" action>
            Team Members
          </ListGroupItem>
          <ListGroupItem tag={Link} to="/time-card" action>
            Time Card
          </ListGroupItem>
        </ListGroup>
      </div>
    </>
  )
}

export default TeamsSidebar
