/* eslint-disable no-unused-vars */
import React from "react"

const dummyLeaves = [
  { id: 1, member: "John Doe", type: "Vacation", startDate: "2023-07-10", endDate: "2023-07-15", status: "Approved" },
  { id: 2, member: "Jane Smith", type: "Sick Leave", startDate: "2023-07-05", endDate: "2023-07-07", status: "Pending" },
  { id: 3, member: "Alice Johnson", type: "Maternity", startDate: "2023-06-01", endDate: "2023-09-01", status: "Approved" },
  { id: 4, member: "Bob Brown", type: "Personal", startDate: "2023-07-20", endDate: "2023-07-22", status: "Rejected" },
  { id: 5, member: "Charlie Davis", type: "Vacation", startDate: "2023-08-01", endDate: "2023-08-10", status: "Approved" },
]

const getStatusColor = (status) => {
  switch (status) {
    case "Approved":
      return "success"
    case "Pending":
      return "warning"
    case "Rejected":
      return "danger"
    default:
      return "secondary"
  }
}

const Leave = () => {
  return (
    <div>
      <div className="mb-4">
        <h4 className="page-title">Leave</h4>
      </div>
      <div>
        <div className="card">
          <div className="card-header">
            <button className="btn btn-primary float-end">Add Leave</button>
            <h5 className="card-title mb-0">Leave List</h5>
          </div>
          <div className="card-body">
            <table className="table table-responsive table-hover">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Member</th>
                  <th>Type</th>
                  <th>Start Date</th>
                  <th>End Date</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {dummyLeaves.map((leave) => (
                  <tr key={leave.id}>
                    <th scope="row">{leave.id}</th>
                    <td>{leave.member}</td>
                    <td>{leave.type}</td>
                    <td>{leave.startDate}</td>
                    <td>{leave.endDate}</td>
                    <td>
                      <span className={"badge bg-" + getStatusColor(leave.status)}>
                        {leave.status}
                      </span>
                    </td>
                    <td>
                      <button className="btn btn-info btn-sm me-2">Edit</button>
                      <button className="btn btn-danger btn-sm">Delete</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Leave
