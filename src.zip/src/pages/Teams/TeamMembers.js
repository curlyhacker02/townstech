/* eslint-disable no-unused-vars */
import React, { useState } from "react"

const TeamMembers = () => {
  const dummyTeamMembers = [
    { id: 1, name: "John Doe", role: "Project Manager", email: "john@example.com", status: "Active" },
    { id: 2, name: "Jane Smith", role: "Developer", email: "jane@example.com", status: "Active" },
    { id: 3, name: "Alice Johnson", role: "Designer", email: "alice@example.com", status: "Inactive" },
    { id: 4, name: "Bob Brown", role: "QA Engineer", email: "bob@example.com", status: "Active" },
    { id: 5, name: "Charlie Davis", role: "DevOps", email: "charlie@example.com", status: "Active" },
  ]

  const getStatusColor = (status) => {
    switch (status) {
      case "Active":
        return "success"
      case "Inactive":
        return "secondary"
      default:
        return "primary"
    }
  }

  return (
    <div>
      <div className="mb-4">
        <h4 className="page-title">Team Members</h4>
      </div>
      <div>
        <div className="card">
          <div className="card-header">
            <button className="btn btn-primary float-end">Add Member</button>
            <h5 className="card-title mb-0">Team Member List</h5>
          </div>
          <div className="card-body">
            <table className="table table-responsive table-hover">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Name</th>
                  <th>Role</th>
                  <th>Email</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {dummyTeamMembers.map((member) => (
                  <tr key={member.id}>
                    <th scope="row">{member.id}</th>
                    <td>{member.name}</td>
                    <td>{member.role}</td>
                    <td>{member.email}</td>
                    <td>
                      <span className={"badge bg-" + getStatusColor(member.status)}>
                        {member.status}
                      </span>
                    </td>
                    <td>
                      <button className="btn btn-info btn-sm me-2">Edit</button>
                      <button className="btn btn-danger btn-sm">Delete</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  )
}

export default TeamMembers
