import React from "react"

const dummyTimelineEvents = [
  { id: 1, date: "2023-07-01", event: "Project Kickoff" },
  { id: 2, date: "2023-07-05", event: "Design Phase Completed" },
  { id: 3, date: "2023-07-10", event: "Development Started" },
  { id: 4, date: "2023-07-20", event: "Testing Phase" },
  { id: 5, date: "2023-07-30", event: "Project Launch" },
]

const Timeline = () => {
  return (
    <div>
      <div className="mb-4">
        <h4 className="page-title">Timeline</h4>
      </div>
      <div>
        <div className="card">
          <div className="card-header">
            <h5 className="card-title mb-0">Project Timeline</h5>
          </div>
          <div className="card-body">
            <ul className="timeline">
              {dummyTimelineEvents.map((event) => (
                <li key={event.id}>
                  <strong>{event.date}:</strong> {event.event}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Timeline
