/* eslint-disable no-unused-vars */
import React from "react"

const dummyTimeCards = [
  { id: 1, member: "John Doe", date: "2023-07-01", hours: 8, status: "Approved" },
  { id: 2, member: "Jane Smith", date: "2023-07-01", hours: 7.5, status: "Pending" },
  { id: 3, member: "Alice Johnson", date: "2023-07-01", hours: 8, status: "Approved" },
  { id: 4, member: "Bob Brown", date: "2023-07-01", hours: 6, status: "Rejected" },
  { id: 5, member: "Charlie Davis", date: "2023-07-01", hours: 8, status: "Approved" },
]

const getStatusColor = (status) => {
  switch (status) {
    case "Approved":
      return "success"
    case "Pending":
      return "warning"
    case "Rejected":
      return "danger"
    default:
      return "secondary"
  }
}

const TimeCard = () => {
  return (
    <div>
      <div className="mb-4">
        <h4 className="page-title">Time Card</h4>
      </div>
      <div>
        <div className="card">
          <div className="card-header">
            <button className="btn btn-primary float-end">Add Time Card</button>
            <h5 className="card-title mb-0">Time Card List</h5>
          </div>
          <div className="card-body">
            <table className="table table-responsive table-hover">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Member</th>
                  <th>Date</th>
                  <th>Hours</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {dummyTimeCards.map((card) => (
                  <tr key={card.id}>
                    <th scope="row">{card.id}</th>
                    <td>{card.member}</td>
                    <td>{card.date}</td>
                    <td>{card.hours}</td>
                    <td>
                      <span className={"badge bg-" + getStatusColor(card.status)}>
                        {card.status}
                      </span>
                    </td>
                    <td>
                      <button className="btn btn-info btn-sm me-2">Edit</button>
                      <button className="btn btn-danger btn-sm">Delete</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  )
}

export default TimeCard
