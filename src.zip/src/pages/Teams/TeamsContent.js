import React from "react"
import { Card, CardBody, CardTitle, CardText, Row, Col } from "reactstrap"
import TeamsSidebar from "./TeamsSidebar"

const TeamsContent = ({ articles }) => {
  return (
    <Row>
      <Col md={3}>
        <TeamsSidebar />
      </Col>
      <Col md={9}>
        {articles.length === 0 ? (
          <p>No team articles found.</p>
   ) : (
          articles.map((article) => (
            <Card className="mb-3" key={article.id}>
              <CardBody>
                <CardTitle tag="h5">{article.title}</CardTitle>
                <CardText>{article.content}</CardText>
              </CardBody>
            </Card>
          ))
        )}
      </Col>
    </Row>
  )
}

export default TeamsContent
