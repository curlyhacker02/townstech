/* eslint-disable no-unused-vars */
import React, { useState } from "react"
import TeamsLayout from "./TeamsLayout"
import {
  ListGroup,
  ListGroupItem,
  Button,
} from "reactstrap"

const dummyAnnouncements = [
  { id: 1, title: "Office Closed on July 4th", date: "2023-06-25" },
  { id: 2, title: "New Project Launch", date: "2023-06-20" },
  { id: 3, title: "Holiday Schedule Updated", date: "2023-06-15" },
  { id: 4, title: "Team Meeting on Friday", date: "2023-06-10" },
  { id: 5, title: "New HR Policies", date: "2023-06-05" },
]

const AnnouncementsContent = () => {
  const [announcements, setAnnouncements] = useState(dummyAnnouncements)

  return (
    <>
      <div className="mb-4">
        <h4 className="page-title">Announcements</h4>
      </div>
      <div>
        <div className="card">
          <div className="card-header">
            <Button color="primary" className="float-end">
              Add Announcement
            </Button>
            <h5 className="card-title mb-0">Announcements List</h5>
          </div>
          <div className="card-body">
            <ListGroup>
              {announcements.map((announcement) => (
                <ListGroupItem key={announcement.id}>
                  <strong>{announcement.title}</strong> - <em>{announcement.date}</em>
                </ListGroupItem>
              ))}
            </ListGroup>
          </div>
        </div>
      </div>
    </>
  )
}

const Announcements = () => {
  return (
    <TeamsLayout>
      <AnnouncementsContent />
    </TeamsLayout>
  )
}

export default Announcements
