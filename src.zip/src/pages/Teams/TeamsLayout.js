import React, { useState } from "react"
import { Container, Row, Col } from "reactstrap"
import TeamsSidebar from "./TeamsSidebar"

const sidebarItems = [
  { id: "team-members", name: "Team Members", path: "/team-members" },
  { id: "time-card", name: "Time Card", path: "/time-card" },
  { id: "leave", name: "Leave", path: "/leave" },
  { id: "timeline", name: "Timeline", path: "/timeline" },
  { id: "announcements", name: "Announcements", path: "/announcements" },
]

const TeamsLayout = ({ children }) => {
  const [selectedCategory, setSelectedCategory] = useState("team-members")

  const onSelectCategory = (id) => {
    setSelectedCategory(id)
  }

  return (
    <Container fluid>
      <Row className="mb-4">
        <Col>
          <h4 className="page-title">Team Dashboard</h4>
        </Col>
      </Row>
      <Row>
        <Col md={3}>
          <TeamsSidebar
            categories={sidebarItems}
            selectedCategory={selectedCategory}
            onSelectCategory={onSelectCategory}
          />
        </Col>
        <Col md={9}>{children}</Col>
      </Row>
    </Container>
  )
}

export default TeamsLayout
