import React, { useState } from "react"
import { Container, Row, Col, ListGroup, ListGroupItem, Table } from "reactstrap"
import { Link, Outlet } from "react-router-dom"

const teamMenuItems = [
  { id: "team-members", label: "Team Members", path: "/team-members" },
  { id: "time-card", label: "Time Card", path: "/time-card" },
  { id: "leave", label: "Leave", path: "/leave" },
  { id: "timeline", label: "Timeline", path: "/timeline" },
  { id: "announcements", label: "Announcements", path: "/announcements" },
]

const dummyTeamMembers = [
  { id: 1, name: "John Doe", role: "Developer", email: "john@example.com" },
  { id: 2, name: "Jane Smith", role: "Designer", email: "jane@example.com" },
  { id: 3, name: "Bob Johnson", role: "Project Manager", email: "bob@example.com" },
]

const Teams = () => {
  const [activeItem, setActiveItem] = useState(teamMenuItems[0].id)

  return (
    <Container fluid>
      <Row className="mb-4">
        <Col>
          <h4 className="page-title">Team Dashboard</h4>
        </Col>
      </Row>
      <Row>
        <Col md={3}>
          <ListGroup>
            {teamMenuItems.map((item) => (
              <ListGroupItem
                key={item.id}
                tag={Link}
                to={item.path}
                action
                active={activeItem === item.id}
                onClick={() => setActiveItem(item.id)}
              >
                {item.label}
              </ListGroupItem>
            ))}
          </ListGroup>
        </Col>
        <Col md={9}>
          {activeItem === "team-members" ? (
            <>
              <h4>Team Members</h4>
              <Table striped>
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Role</th>
                    <th>Email</th>
                  </tr>
                </thead>
                <tbody>
                  {dummyTeamMembers.map((member) => (
                    <tr key={member.id}>
                      <td>{member.name}</td>
                      <td>{member.role}</td>
                      <td>{member.email}</td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            </>
          ) : (
            <Outlet />
          )}
        </Col>
      </Row>
    </Container>
  )
}

export default Teams

