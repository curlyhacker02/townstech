/* eslint-disable no-unused-vars */
import React, { useState } from "react"
import {
  Card,
  CardBody,
  CardHeader,
  Col,
  Container,
  Row,
  Table,
  Button,
  Badge,
} from "reactstrap"

const dummyProjects = [
  { id: 1, name: "Project Alpha", client: "Acme Corp", status: "In Progress", startDate: "2023-01-01", endDate: "2023-06-30" },
  { id: 2, name: "Project Beta", client: "Globex Inc", status: "Completed", startDate: "2022-05-15", endDate: "2022-12-31" },
  { id: 3, name: "Project Gamma", client: "Soylent Corp", status: "On Hold", startDate: "2023-03-01", endDate: "2023-09-30" },
  { id: 4, name: "Project Delta", client: "Initech", status: "In Progress", startDate: "2023-02-15", endDate: "2023-08-15" },
  { id: 5, name: "Project Epsilon", client: "Umbrella Corp", status: "Cancelled", startDate: "2022-11-01", endDate: "2023-01-31" },
]

const Projects = () => {
  const [projects, setProjects] = useState(dummyProjects)

  const getStatusColor = (status) => {
    switch (status) {
      case "Completed":
        return "success"
      case "In Progress":
        return "primary"
      case "On Hold":
        return "warning"
      case "Cancelled":
        return "danger"
      default:
        return "secondary"
    }
  }

  return (
    <Container fluid>
      <Row className="mb-4">
        <Col>
          <h4 className="page-title">Projects</h4>
        </Col>
      </Row>
      <Row>
        <Col>
          <Card>
            <CardHeader>
              <Button color="primary" className="float-end">
                Add Project
              </Button>
              <h5 className="card-title mb-0">Project List</h5>
            </CardHeader>
            <CardBody>
              <Table responsive hover>
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Project Name</th>
                    <th>Client</th>
                    <th>Status</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {projects.map(project => (
                    <tr key={project.id}>
                      <th scope="row">{project.id}</th>
                      <td>{project.name}</td>
                      <td>{project.client}</td>
                      <td>
                        <Badge color={getStatusColor(project.status)}>
                          {project.status}
                        </Badge>
                      </td>
                      <td>{project.startDate}</td>
                      <td>{project.endDate}</td>
                      <td>
                        <Button color="info" size="sm" className="me-2">
                          Edit
                        </Button>
                        <Button color="danger" size="sm">
                          Delete
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            </CardBody>
          </Card>
        </Col>
      </Row>
    </Container>
  )
}

export default Projects
