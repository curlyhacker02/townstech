<div class="step" data-step="6" style="display: none;">
  <div class="card mb-3">
    <div class="card-header bg-csw-primary text-white">
      <strong><i class="bi bi-person-badge me-2"></i>Step 6: Character Reference</strong>
    </div>
    <div class="card-body">
      <p>
        CSW needs to be satisfied that a Social Worker is of good character before putting his/her name on the Register.
        A character reference must be provided by a person of good standing in the community who is not a relative or friend.
        A person of good standing might be a teacher, a lawyer, a priest, a registered social worker.
      </p>

      <!-- Applicant Details -->
      <h6 class="fw-bold mt-4">Applicant Details</h6>
      <div class="row">
        <div class="col-md-6 mb-3">
          <label class="form-label fw-bold">1. Applicant Name</label>
          <input type="text" name="applicant_name" class="form-control" required
                 value="<?= htmlspecialchars($step6Data['applicant_name'] ?? '') ?>">
        </div>
        <div class="col-md-6 mb-3">
          <label class="form-label fw-bold">2. Applicant Address</label>
          <input type="text" name="applicant_address" class="form-control" required
                 value="<?= htmlspecialchars($step6Data['applicant_address'] ?? '') ?>">
        </div>
      </div>

      <!-- Referee Details -->
      <h6 class="fw-bold mt-4">Referee Details</h6>
      <div class="row">
        <div class="col-md-6 mb-3">
          <label class="form-label fw-bold">3. Referee Name</label>
          <input type="text" name="referee_name" class="form-control" required
                 value="<?= htmlspecialchars($step6Data['referee_name'] ?? '') ?>">
        </div>

        <div class="col-md-6 mb-3">
          <label class="form-label fw-bold">4. Referee Occupation</label>
          <input type="text" name="referee_occupation" class="form-control" required
                 value="<?= htmlspecialchars($step6Data['referee_occupation'] ?? '') ?>">
        </div>

        <div class="col-md-12 mb-3">
          <label class="form-label fw-bold">5. Referee Business Address</label>
          <input type="text" name="referee_business_address" class="form-control" required
                 value="<?= htmlspecialchars($step6Data['referee_business_address'] ?? '') ?>">
        </div>

        <div class="col-md-6 mb-3">
          <label class="form-label fw-bold">6. Referee Contact Number</label>
          <input type="text" name="referee_contact_number" class="form-control" required
                 value="<?= htmlspecialchars($step6Data['referee_contact_number'] ?? '') ?>">
        </div>

        <div class="col-md-6 mb-3">
          <label class="form-label fw-bold">7. Referee Email</label>
          <input type="email" name="referee_email" class="form-control" required
                 value="<?= htmlspecialchars($step6Data['referee_email'] ?? '') ?>">
        </div>

        <div class="col-md-6 mb-3">
          <label class="form-label fw-bold">8. Relationship to Applicant</label>
          <input type="text" name="referee_relationship" class="form-control" required
                 value="<?= htmlspecialchars($step6Data['referee_relationship'] ?? '') ?>">
        </div>
      </div>

      <!-- Character Statement -->
      <h6 class="fw-bold mt-4">Reference Statement</h6>
      <div class="row">
        <div class="col-md-12 mb-3">
          <label class="form-label">I confirm I have known the applicant for</label>
          <input type="text" name="known_duration" class="form-control" placeholder="e.g. 5 years" required
                 value="<?= htmlspecialchars($step6Data['known_duration'] ?? '') ?>">
        </div>

        <div class="col-md-12 mb-3">
          <label class="form-label">As a</label>
          <input type="text" name="known_as" class="form-control" placeholder="e.g. colleague, supervisor, etc." required
                 value="<?= htmlspecialchars($step6Data['known_as'] ?? '') ?>">
        </div>

        <div class="col-md-4 mb-3">
          <label class="form-label fw-bold">Date</label>
          <input type="date" name="date" class="form-control" required
                 value="<?= htmlspecialchars($step6Data['date'] ?? '') ?>">
        </div>

        <div class="col-md-8 mb-3">
          <label class="form-label fw-bold">Signature</label>
          <input type="text" name="signature" class="form-control" required
                 value="<?= htmlspecialchars($step6Data['signature'] ?? '') ?>">
        </div>
      </div>

    </div>
  </div>
</div>
