<div class="step" data-step="1">
  <div class="card mb-3">
    <div class="card-header bg-csw-primary text-white">
      <strong><i class="bi bi-person-badge me-2"></i>Step 1: Personal Information</strong>
    </div>
    <div class="card-body row">
      <?php
        $personalInfo = [
          'Full Name' => $profile['first_name'] . ' ' . $profile['surname'],
          'Previous Name' => $profile['previous_name'],
          'Date of Birth' => $profile['dob'],
          'Gender' => $profile['gender'],
          'Nationality' => $profile['nationality'],
          'National ID' => $profile['national_id'],
        ];
        foreach ($personalInfo as $label => $value): ?>
          <div class="col-md-6 mb-2">
            <strong><?= esc($label) ?>:</strong> <?= esc($value) ?>
          </div>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Edit Profile Button -->
  <div class="text-end">
    <a href="<?= site_url('profile/edit') ?>" class="btn btn-csw-secondary">
      <i class="bi bi-pencil-square me-1"></i> Edit Profile
    </a>
  </div>
</div>
