<div class="step" data-step="2" style="display: none;">
  <div class="card mb-3">
    <div class="card-header bg-csw-primary text-white">
      <strong><i class="bi bi-shield-check me-2"></i>Step 2: Character and Health Self Declarations</strong>
    </div>
    <div class="card-body">
      <p class="text-muted">
        The CSW has to check the health and character of Social Workers who apply for registration.
        This is to ensure you are able to practice safely and service users are not exposed to risk.
      </p>

      <!-- Question 1 -->
      <div class="row mb-3">
        <label class="form-label fw-bold">1. Have you ever been convicted of a criminal offence, received a police caution or a conditional discharge?</label>
        <div class="col-md-6">
          <div class="form-check form-check-inline">
            <input class="form-check-input toggle-details" type="radio" name="convicted_offence" value="Yes" data-target="#convicted_offence_details" required
              <?= (isset($step2Data['convicted_offence']) && $step2Data['convicted_offence'] === 'Yes') ? 'checked' : '' ?>>
            <label class="form-check-label">Yes</label>
          </div>
          <div class="form-check form-check-inline">
            <input class="form-check-input toggle-details" type="radio" name="convicted_offence" value="No" data-target="#convicted_offence_details" required
              <?= (isset($step2Data['convicted_offence']) && $step2Data['convicted_offence'] === 'No') ? 'checked' : '' ?>>
            <label class="form-check-label">No</label>
          </div>
        </div>
        <div class="col-md-12 mt-2" id="convicted_offence_details" style="display: <?= (isset($step2Data['convicted_offence']) && $step2Data['convicted_offence'] === 'Yes') ? 'block' : 'none' ?>;">
          <textarea class="form-control" name="convicted_offence_details" rows="2" placeholder="If yes, provide details..."><?= htmlspecialchars($step2Data['convicted_offence_details'] ?? '') ?></textarea>
        </div>
      </div>

      <!-- Question 2 -->
      <div class="row mb-3">
        <label class="form-label fw-bold">2. Have you been disciplined by a professional/regulatory body or your employer?</label>
        <div class="col-md-6">
          <div class="form-check form-check-inline">
            <input class="form-check-input toggle-details" type="radio" name="disciplined_professional_body" value="Yes" data-target="#disciplined_professional_body_details" required
              <?= (isset($step2Data['disciplined_professional_body']) && $step2Data['disciplined_professional_body'] === 'Yes') ? 'checked' : '' ?>>
            <label class="form-check-label">Yes</label>
          </div>
          <div class="form-check form-check-inline">
            <input class="form-check-input toggle-details" type="radio" name="disciplined_professional_body" value="No" data-target="#disciplined_professional_body_details" required
              <?= (isset($step2Data['disciplined_professional_body']) && $step2Data['disciplined_professional_body'] === 'No') ? 'checked' : '' ?>>
            <label class="form-check-label">No</label>
          </div>
        </div>
        <div class="col-md-12 mt-2" id="disciplined_professional_body_details" style="display: <?= (isset($step2Data['disciplined_professional_body']) && $step2Data['disciplined_professional_body'] === 'Yes') ? 'block' : 'none' ?>;">
          <textarea class="form-control" name="disciplined_professional_body_details" rows="2" placeholder="If yes, provide details..."><?= htmlspecialchars($step2Data['disciplined_professional_body_details'] ?? '') ?></textarea>
        </div>
      </div>

      <!-- Question 3 -->
      <div class="row mb-3">
        <label class="form-label fw-bold">3. Have you had civil proceedings (other than divorce) brought against you?</label>
        <div class="col-md-6">
          <div class="form-check form-check-inline">
            <input class="form-check-input toggle-details" type="radio" name="civil_proceedings" value="Yes" data-target="#civil_proceedings_details" required
              <?= (isset($step2Data['civil_proceedings']) && $step2Data['civil_proceedings'] === 'Yes') ? 'checked' : '' ?>>
            <label class="form-check-label">Yes</label>
          </div>
          <div class="form-check form-check-inline">
            <input class="form-check-input toggle-details" type="radio" name="civil_proceedings" value="No" data-target="#civil_proceedings_details" required
              <?= (isset($step2Data['civil_proceedings']) && $step2Data['civil_proceedings'] === 'No') ? 'checked' : '' ?>>
            <label class="form-check-label">No</label>
          </div>
        </div>
        <div class="col-md-12 mt-2" id="civil_proceedings_details" style="display: <?= (isset($step2Data['civil_proceedings']) && $step2Data['civil_proceedings'] === 'Yes') ? 'block' : 'none' ?>;">
          <textarea class="form-control" name="civil_proceedings_details" rows="2" placeholder="If yes, provide details..."><?= htmlspecialchars($step2Data['civil_proceedings_details'] ?? '') ?></textarea>
        </div>
      </div>

      <!-- Question 4 -->
      <div class="row mb-3">
        <label class="form-label fw-bold">4. Do you have any physical or mental health condition that would affect your fitness to practise?</label>
        <div class="col-md-6">
          <div class="form-check form-check-inline">
            <input class="form-check-input toggle-details" type="radio" name="health_condition_affect_fitness" value="Yes" data-target="#health_condition_details" required
              <?= (isset($step2Data['health_condition_affect_fitness']) && $step2Data['health_condition_affect_fitness'] === 'Yes') ? 'checked' : '' ?>>
            <label class="form-check-label">Yes</label>
          </div>
          <div class="form-check form-check-inline">
            <input class="form-check-input toggle-details" type="radio" name="health_condition_affect_fitness" value="No" data-target="#health_condition_details" required
              <?= (isset($step2Data['health_condition_affect_fitness']) && $step2Data['health_condition_affect_fitness'] === 'No') ? 'checked' : '' ?>>
            <label class="form-check-label">No</label>
          </div>
        </div>
        <div class="col-md-12 mt-2" id="health_condition_details" style="display: <?= (isset($step2Data['health_condition_affect_fitness']) && $step2Data['health_condition_affect_fitness'] === 'Yes') ? 'block' : 'none' ?>;">
          <textarea class="form-control" name="health_condition_details" rows="2" placeholder="If yes, provide details..."><?= htmlspecialchars($step2Data['health_condition_details'] ?? '') ?></textarea>
        </div>
      </div>

      <!-- Question 5 -->
      <div class="row mb-3">
        <label class="form-label fw-bold">5. More Details</label>
        <div class="col-md-12">
          <textarea class="form-control" name="more_details" rows="4" placeholder="Provide any additional relevant information..."><?= htmlspecialchars($step2Data['more_details'] ?? '') ?></textarea>
        </div>
      </div>
    </div>
  </div>
</div>
