<div class="step" data-step="9" style="display: none;">
  <div class="card mb-3">
    <div class="card-header bg-csw-primary text-white">
      <strong><i class="bi bi-upload me-2"></i>Step 9: Upload Documents</strong>
    </div>
    <div class="card-body">
      <p>Please upload clear and legible copies of the following required documents. All documents must be in PDF, JPG or PNG format.</p>

      <form id="documentUploadForm" enctype="multipart/form-data">

        <input type="hidden" name="application_id" id="application_id" value="<?= esc($application_id) ?>">

        <?php 
        $categories = [
          'identity_document' => 'National ID or Passport',
          'academic_certificates' => 'Academic Certificates',
          'professional_qualifications' => 'Professional Qualifications',
          'character_references' => 'Character References',
          'employer_endorsements' => 'Employer Endorsement',
          'private_practice_docs' => 'Private Practice Evidence (if applicable)',
        ];

        foreach ($categories as $key => $label):
          $existingFile = $uploadedDocuments[$key] ?? null;
        ?>
          <div class="mb-3">
            <label class="form-label fw-bold"><?= esc($label) ?></label>

            <?php if ($existingFile): ?>
              <div class="mb-2">
                <a href="<?= base_url('uploads/documents/' . $application_id . '/' . $existingFile['file_name']) ?>" target="_blank" rel="noopener noreferrer">
                  📄 <?= esc($existingFile['file_name']) ?>
                </a>
                <button type="button" class="btn btn-sm btn-danger ms-2 remove-existing-file" data-category="<?= esc($key) ?>">Remove</button>
              </div>
              <input type="file" name="<?= esc($key) ?>" class="form-control" style="display:none;">
            <?php else: ?>
              <input type="file" name="<?= esc($key) ?>" class="form-control" accept=".pdf,.jpg,.jpeg,.png">
            <?php endif; ?>

            <div class="invalid-feedback file-error" style="display:none;"></div>
          </div>
        <?php endforeach; ?>

        <div class="alert alert-info mt-3">
          Please upload one document per section.
        </div>
      </form>
    </div>
  </div>
</div>
