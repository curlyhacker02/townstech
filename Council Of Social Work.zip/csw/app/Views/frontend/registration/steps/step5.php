<div class="step" data-step="5" style="display: none;">
  <div class="card mb-3">
    <div class="card-header bg-csw-primary text-white">
      <strong><i class="bi bi-person-check me-2"></i>Step 5: Employer Endorsement</strong>
    </div>
    <div class="card-body">
      <p>This section is to be completed by your current employer, preferably in the Human Resources Department. Please date stamp the endorsement.</p>

      <div class="row">
        <div class="col-md-6 mb-3">
          <label class="form-label fw-bold">1. Name of Endorser</label>
          <input type="text" name="endorser_name" class="form-control" required
                 value="<?= htmlspecialchars($step5Data['endorser_name'] ?? '') ?>">
        </div>

        <div class="col-md-6 mb-3">
          <label class="form-label fw-bold">2. Organization</label>
          <input type="text" name="organization" class="form-control" required
                 value="<?= htmlspecialchars($step5Data['organization'] ?? '') ?>">
        </div>

        <div class="col-md-12 mb-3">
          <label class="form-label fw-bold">3. Address</label>
          <textarea name="address" class="form-control" rows="2" required><?= htmlspecialchars($step5Data['address'] ?? '') ?></textarea>
        </div>

        <div class="col-md-6 mb-3">
          <label class="form-label fw-bold">4. Contact Number</label>
          <input type="text" name="contact_number" class="form-control" required
                 value="<?= htmlspecialchars($step5Data['contact_number'] ?? '') ?>">
        </div>

        <div class="col-md-6 mb-3">
          <label class="form-label fw-bold">5. Email Address</label>
          <input type="email" name="email" class="form-control" required
                 value="<?= htmlspecialchars($step5Data['email'] ?? '') ?>">
        </div>

        <div class="col-md-6 mb-3">
          <label class="form-label fw-bold">6. Name of Employee</label>
          <input type="text" name="employee_name" class="form-control" required
                 value="<?= htmlspecialchars($step5Data['employee_name'] ?? '') ?>">
        </div>

        <div class="col-md-3 mb-3">
          <label class="form-label fw-bold">7. Years Employed</label>
          <input type="number" name="years_employed" class="form-control" min="0" required
                 value="<?= htmlspecialchars($step5Data['years_employed'] ?? '') ?>">
        </div>

        <div class="col-md-3 mb-3">
          <label class="form-label fw-bold">8. Role</label>
          <input type="text" name="role" class="form-control" required
                 value="<?= htmlspecialchars($step5Data['role'] ?? '') ?>">
        </div>

        <div class="col-md-4 mb-3">
          <label class="form-label fw-bold">9. Date</label>
          <input type="date" name="endorsement_date" class="form-control" required
                 value="<?= htmlspecialchars($step5Data['endorsement_date'] ?? '') ?>">
        </div>

        <div class="col-md-12 mb-3">
          <label class="form-label fw-bold">10. Any Comments about the employee</label>
          <textarea name="comments" class="form-control" rows="4"><?= htmlspecialchars($step5Data['comments'] ?? '') ?></textarea>
        </div>
      </div>
    </div>
  </div>
</div>
