<div class="step" data-step="8" style="display: none;">
  <div class="card mb-3">
    <div class="card-header bg-csw-primary text-white">
      <strong><i class="bi bi-briefcase-fill me-2"></i>Step 8: Private Practice</strong>
    </div>
    <div class="card-body">
      <p>Do/Have you ever practiced as a Registered Social Worker/Private Agency in the past three years?</p>
      <p class="fst-italic">(By private practice we mean providing Social Work Services to individuals or agencies as a Private Social Worker with own registered service.)</p>

      <!-- Practiced -->
      <div class="mb-3">
        <label class="form-label fw-bold">Have you practiced in the past 3 years?</label>
        <div class="form-check">
          <input class="form-check-input" type="radio" name="practiced" value="yes" id="practicedYes"
            <?= (isset($step8Data['practiced']) && $step8Data['practiced'] === 'yes') ? 'checked' : '' ?>>
          <label class="form-check-label" for="practicedYes">Yes</label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="radio" name="practiced" value="no" id="practicedNo"
            <?= (!isset($step8Data['practiced']) || $step8Data['practiced'] === 'no') ? 'checked' : '' ?>>
          <label class="form-check-label" for="practicedNo">No</label>
        </div>
      </div>

      <!-- If practiced == yes -->
      <div id="privatePracticeDetails" style="display: <?= (isset($step8Data['practiced']) && $step8Data['practiced'] === 'yes') ? 'block' : 'none' ?>;">
        <div class="row">
          <div class="col-md-6 mb-3">
            <label class="form-label fw-bold">1. Jurisdiction</label>
            <input type="text" name="jurisdiction" class="form-control"
              value="<?= htmlspecialchars($step8Data['jurisdiction'] ?? '') ?>">
          </div>

          <div class="col-md-6 mb-3">
            <label class="form-label fw-bold">2. Area of Practice <span class="text-muted">(e.g. counselling)</span></label>
            <input type="text" name="area_of_practice" class="form-control"
              value="<?= htmlspecialchars($step8Data['area_of_practice'] ?? '') ?>">
          </div>

          <div class="col-md-6 mb-3">
            <label class="form-label fw-bold">3. Name of Practice</label>
            <input type="text" name="practice_name" class="form-control"
              value="<?= htmlspecialchars($step8Data['practice_name'] ?? '') ?>">
          </div>

          <div class="col-md-6 mb-3">
            <label class="form-label fw-bold">4. Address</label>
            <input type="text" name="address" class="form-control"
              value="<?= htmlspecialchars($step8Data['address'] ?? '') ?>">
          </div>

          <div class="col-md-6 mb-3">
            <label class="form-label fw-bold">5. Contact Number</label>
            <input type="text" name="contact_number" class="form-control"
              value="<?= htmlspecialchars($step8Data['contact_number'] ?? '') ?>">
          </div>

          <div class="col-md-6 mb-3">
            <label class="form-label fw-bold">6. Email Address</label>
            <input type="email" name="email" class="form-control"
              value="<?= htmlspecialchars($step8Data['email'] ?? '') ?>">
          </div>
        </div>

        <!-- Disciplinary Section -->
        <h6 class="fw-bold mt-4">Disciplinary Record</h6>
        <div class="mb-3">
          <label class="form-label">Have you faced any disciplinary action by a professional or regulatory body in your private practice?</label>
          <div class="form-check">
            <input class="form-check-input" type="radio" name="faced_disciplinary_action" value="yes" id="ppDisciplinaryYes"
              <?= (isset($step8Data['faced_disciplinary_action']) && $step8Data['faced_disciplinary_action'] === 'yes') ? 'checked' : '' ?>>
            <label class="form-check-label" for="ppDisciplinaryYes">Yes</label>
          </div>
          <div class="form-check">
            <input class="form-check-input" type="radio" name="faced_disciplinary_action" value="no" id="ppDisciplinaryNo"
              <?= (!isset($step8Data['faced_disciplinary_action']) || $step8Data['faced_disciplinary_action'] === 'no') ? 'checked' : '' ?>>
            <label class="form-check-label" for="ppDisciplinaryNo">No</label>
          </div>
        </div>

        <div class="mb-3" id="ppDisciplinaryDetailsWrapper" style="display: <?= (isset($step8Data['faced_disciplinary_action']) && $step8Data['faced_disciplinary_action'] === 'yes') ? 'block' : 'none' ?>;">
          <label class="form-label">If yes, provide details:</label>
          <textarea name="disciplinary_details" class="form-control" rows="3"><?= htmlspecialchars($step8Data['disciplinary_details'] ?? '') ?></textarea>
        </div>

        <!-- Certification -->
        <h6 class="fw-bold mt-4">Certification</h6>
        <p>I certify that the facts set out above are to the best of my knowledge and belief true and correct.</p>

        <div class="row">
          <div class="col-md-4 mb-3">
            <label class="form-label fw-bold">Date</label>
            <input type="date" name="certification_date" class="form-control"
              value="<?= htmlspecialchars($step8Data['certification_date'] ?? '') ?>">
          </div>

          <div class="col-md-8 mb-3">
            <label class="form-label fw-bold">Signature</label>
            <input type="text" name="certification_signature" class="form-control"
              value="<?= htmlspecialchars($step8Data['certification_signature'] ?? '') ?>">
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
