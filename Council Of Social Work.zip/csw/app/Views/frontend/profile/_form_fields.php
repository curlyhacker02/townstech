<!-- This file assumes $profile is an array (may be empty for creation) -->
<div class="card mb-4">
  <div class="card-header bg-csw-primary text-white">
    <strong>Personal Information</strong>
  </div>
  <div class="card-body row g-3">
    <?php
      $fields = [
        ['Title', 'title'],
        ['First Name', 'first_name'],
        ['Surname', 'surname'],
        ['Previous Name', 'previous_name'],
        ['Date of Birth', 'dob', 'date'],
        ['Gender', 'gender', 'select', ['Male', 'Female', 'Other']],
        ['Nationality', 'nationality'],
        ['National ID', 'national_id'],
        ['Country of Birth', 'country_of_birth'],
        ['City of Birth', 'city_of_birth']
      ];
      foreach ($fields as $field) {
        [$label, $name, $type, $options] = array_pad($field, 4, null);
        $value = $profile[$name] ?? '';
        echo '<div class="col-md-6">';
        echo "<label for='$name' class='form-label'>$label</label>";
        if ($type === 'select') {
          echo "<select name='$name' id='$name' class='form-select'>";
          foreach ($options as $opt) {
            $selected = ($value === $opt) ? 'selected' : '';
            echo "<option value='$opt' $selected>$opt</option>";
          }
          echo '</select>';
        } else {
          $inputType = $type ?? 'text';
          echo "<input type='$inputType' class='form-control' name='$name' id='$name' value='" . esc($value) . "'>";
        }
        echo '</div>';
      }
    ?>
  </div>
</div>

<!-- You can add Home Contact, Work Contact, Current Employment cards here like in the edit form -->
