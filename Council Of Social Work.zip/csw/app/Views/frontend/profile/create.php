<section class="py-5 bg-csw-dark text-white text-center">
  <div class="container">
    <h1 class="display-5 fw-bold"><?= esc($title) ?></h1>
    <p class="lead">Fill in your details to create a profile.</p>
  </div>
</section>

<div class="container py-5">
  <form method="post" action="<?= site_url('/profile/create') ?>">
    <?= csrf_field() ?>

    <!-- Include same fields as in edit form -->
    <?php $profile = []; ?>
    <?php include(APPPATH . 'Views/frontend/profile/_form_fields.php'); ?>

    <div class="text-end mt-4">
      <button type="submit" class="btn btn-csw-primary btn-lg">
        <i class="bi bi-save"></i> Create Profile
      </button>
    </div>
  </form>
</div>
