<?php
// Only use the $slug passed from the controller, do not try to parse from URI segments

// Fetch article by slug from the database
$slug = $slug ?? null;
$newsModel = new \App\Modules\Frontend\Models\News_m();
$article = $newsModel->getNewsBySlug($slug);
if (!$article) {
    throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound('Article not found');
}

// Fetch comments, tags, categories, recent posts from the database
$comments = $newsModel->getComments($article['id']);
$tagsModel = new \App\Modules\Frontend\Models\NewsTags_m();
$tags = $tagsModel->getTags($article['id']);
$categories = $newsModel->getCategoriesWithCount();
$recentPostsWidget = $newsModel->getRecentPosts(5);

// Author info (if available)
$author = [
    'name' => $article['author_name'] ?? '',
    'photo' => $article['author_image'] ?? 'assets/img/blog/blog-author.jpg',
    'bio' => $article['author_bio'] ?? '',
    'twitter' => $article['author_twitter'] ?? '#',
    'facebook' => $article['author_facebook'] ?? '#',
    'instagram' => $article['author_instagram'] ?? '#',
];
?>
<!-- Hero Section -->
<section class="py-5 bg-csw-dark text-white text-center">
</br>
  <div class="container">
    <h1 class="display-5 fw-bold"><?= esc($article['title']) ?></h1>
    <p class="lead">Full Article Details</p>
  </div>
</section>
<section id="blog-details" class="blog-details section">
  <div class="container">
    <article class="article">
      <div class="post-img">
        <?php if (!empty($article['image'])): ?>
          <img src="<?= base_url('uploads/news/' . esc($article['image'])) ?>" alt="" class="img-fluid">
        <?php endif; ?>
      </div>
      <h2 class="title"><?= esc($article['title']) ?></h2>
      <div class="meta-top">
        <ul>
          <li class="d-flex align-items-center"><i class="bi bi-person"></i> <span><?= esc($article['author_name'] ?? $article['author']) ?></span></li>
          <li class="d-flex align-items-center"><i class="bi bi-clock"></i> <span><time datetime="<?= esc($article['created_at'] ?? $article['date']) ?>"><?= date('M j, Y', strtotime($article['created_at'] ?? $article['date'])) ?></time></span></li>
        </ul>
      </div>
      <div class="content">
        <?= $article['content'] ?>
      </div>
      <div class="meta-bottom">
        <i class="bi bi-folder"></i>
        <ul class="cats">
          <li><a href="#"><?= esc($article['category_name'] ?? $article['category']) ?></a></li>
        </ul>
        <i class="bi bi-tags"></i>
        <ul class="tags">
          <?php foreach ($tags as $tag): ?>
            <li><a href="<?= site_url('news/tag/' . esc($tag['id'] ?? $tag['slug'])) ?>"><?= esc($tag['name'] ?? $tag) ?></a></li>
          <?php endforeach; ?>
        </ul>
      </div>
    </article>
  </div>
</section><!-- /Blog Details Section -->

          <!-- Blog Author Section -->
          <section id="blog-author" class="blog-author section">
            <div class="container">
              <div class="author-container d-flex align-items-center">
                <img src="<?= esc($author['photo']) ?>" class="rounded-circle flex-shrink-0" alt="">
                <div>
                  <h4><?= esc($author['name']) ?></h4>
                  <div class="social-links">
                    <a href="<?= esc($author['twitter']) ?>"><i class="bi bi-twitter-x"></i></a>
                    <a href="<?= esc($author['facebook']) ?>"><i class="bi bi-facebook"></i></a>
                    <a href="<?= esc($author['instagram']) ?>"><i class="bi bi-instagram"></i></a>
                  </div>
                  <p>
                    <?= esc($author['bio']) ?>
                  </p>
                </div>
              </div>
            </div>
          </section><!-- /Blog Author Section -->

          <!-- Blog Comments Section -->
          <section id="blog-comments" class="blog-comments section">
  <div class="container">
    <h4 class="comments-count"><?= count($comments) ?> Comments</h4>
    <?php foreach ($comments as $i => $comment): ?>
      <div id="comment-<?= $i+1 ?>" class="comment mb-4">
        <div class="d-flex">
          <div class="comment-img"><img src="<?= esc($comment['photo'] ?? 'assets/img/blog/comments-1.jpg') ?>" alt=""></div>
          <div>
            <h5><a href=""><?= esc($comment['name']) ?></a></h5>
            <time datetime="<?= esc($comment['created_at'] ?? $comment['date']) ?>"><?= date('d M, Y', strtotime($comment['created_at'] ?? $comment['date'])) ?></time>
            <p><?= esc($comment['comment']) ?></p>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</section><!-- /Blog Comments Section -->

          <!-- Comment Form Section -->
          <section id="comment-form" class="comment-form section">
  <div class="container">
    <form action="<?= site_url('comments/add/' . $articleId) ?>" method="post">
      <h4>Post Comment</h4>
      <p>Your email address will not be published. Required fields are marked * </p>
      <div class="row">
        <div class="col-md-6 form-group">
          <input name="name" type="text" class="form-control" placeholder="Your Name*" required>
        </div>
        <div class="col-md-6 form-group">
          <input name="email" type="email" class="form-control" placeholder="Your Email*" required>
        </div>
      </div>
      <div class="row">
        <div class="col form-group">
          <textarea name="comment" class="form-control" placeholder="Your Comment*" required></textarea>
        </div>
      </div>
      <div class="text-center">
        <button type="submit" class="btn btn-primary">Post Comment</button>
      </div>
    </form>
  </div>
</section><!-- /Comment Form Section -->

        </div>

        <div class="col-lg-4 sidebar">

          <div class="widgets-container">

            <!-- Search Widget -->
            <div class="search-widget widget-item">
              <h3 class="widget-title">Search</h3>
              <form action="<?= site_url('updates/search') ?>" method="get">
                <input type="text" name="q" placeholder="Search articles...">
                <button type="submit" title="Search"><i class="bi bi-search"></i></button>
              </form>
            </div>
            <!--/Search Widget -->

            <!-- Categories Widget -->
            <div class="categories-widget widget-item">
              <h3 class="widget-title">Categories</h3>
              <ul class="mt-3">
                <?php foreach ($categories as $cat): ?>
                  <li><a href="<?= site_url('news/category/' . esc($cat['id'] ?? $cat['slug'])) ?>"> <?= esc($cat['name']) ?> <span>(<?= esc($cat['news_count'] ?? $cat['count']) ?>)</span></a></li>
                <?php endforeach; ?>
              </ul>
            </div>
            <!--/Categories Widget -->

            <!-- Recent Posts Widget -->
            <div class="recent-posts-widget widget-item">
              <h3 class="widget-title">Recent Posts</h3>
              <?php foreach ($recentPostsWidget as $post): ?>
                <div class="post-item">
                  <?php if (!empty($post['image'])): ?>
                    <img src="<?= base_url('uploads/news/' . esc($post['image'])) ?>" alt="" class="flex-shrink-0">
                  <?php endif; ?>
                  <div>
                    <h4><a href="<?= site_url('news/' . esc($post['slug'])) ?>"><?= esc($post['title']) ?></a></h4>
                    <time datetime="<?= esc($post['created_at']) ?>"><?= date('M j, Y', strtotime($post['created_at'])) ?></time>
                  </div>
                </div>
              <?php endforeach; ?>
            </div>
            <!--/Recent Posts Widget -->

            <!-- Tags Widget -->
            <div class="tags-widget widget-item">
              <h3 class="widget-title">Tags</h3>
              <ul>
                <?php foreach ($tags as $tag): ?>
                  <li><a href="<?= site_url('news/tag/' . esc($tag['id'] ?? $tag['slug'])) ?>"><?= esc($tag['name'] ?? $tag) ?></a></li>
                <?php endforeach; ?>
              </ul>
            </div>
            <!--/Tags Widget -->

          </div>

        </div>

      </div>
    </div>