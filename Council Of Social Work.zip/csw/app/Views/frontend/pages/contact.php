<section class="py-5 bg-csw-dark text-white text-center">
</br>
  <div class="container">
    <h1 class="display-5 fw-bold">Contact</h1>
    <p class="lead">Contact Us</p>
  </div>
</section>

<!-- Contact Section -->
<section id="contact" class="contact section">
  <div class="container position-relative" data-aos="fade-up" data-aos-delay="100">
    <div class="row gy-4 justify-content-center">
      <div class="col-lg-5">
        <?php // Contact info is now provided by the controller as $contact ?>
        <div class="info-item d-flex" data-aos="fade-up" data-aos-delay="200">
          <i class="bi bi-geo-alt flex-shrink-0"></i>
          <div>
            <h3>Address</h3>
            <p><?= esc($contact['address'] ?? '') ?></p>
          </div>
        </div><!-- End Info Item -->
        <div class="info-item d-flex" data-aos="fade-up" data-aos-delay="300">
          <i class="bi bi-telephone flex-shrink-0"></i>
          <div class="ps-2">
            <h3>Call Us</h3>
            <?php 
              $phones = [];
              if (!empty($contact['phone'])) {
                if (is_array($contact['phone'])) {
                  $phones = $contact['phone'];
                } else {
                  $phones = array_map('trim', explode(',', $contact['phone']));
                }
              }
            ?>
            <?php foreach ($phones as $idx => $phone): ?>
              <span class="d-inline-block" style="margin-right:8px; margin-bottom:2px;"> <?= esc($phone) ?> </span>
            <?php endforeach; ?>
          </div>
        </div><!-- End Info Item -->
        <div class="info-item d-flex" data-aos="fade-up" data-aos-delay="400">
          <i class="bi bi-envelope flex-shrink-0"></i>
          <div>
            <h3>Email Us</h3>
            <p><?= esc($contact['email'] ?? '') ?></p>
          </div>
        </div><!-- End Info Item -->
      </div>
      <div class="col-lg-7">
        <div class="card shadow-sm">
          <div class="card-body">
            <h5 class="mb-3">Send Us a Message</h5>
            <?php if (session()->getFlashdata('success')): ?>
            <div class="alert alert-success">
                <?= session()->getFlashdata('success') ?>
            </div>
            <?php endif; ?>
            <?php if (session()->getFlashdata('error')): ?>
            <div class="alert alert-danger">
                <?= session()->getFlashdata('error') ?>
            </div>
            <?php endif; ?>

            <form method="post" action="<?= base_url('contact') ?>">
                <div class="form-group">
                    <label>Your Name</label>
                    <input name="name" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Your Email</label>
                    <input name="email" class="form-control" type="email" required>
                </div>
                <div class="form-group">
                    <label>Subject</label>
                    <input name="subject" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Message</label>
                    <textarea name="message" class="form-control" required></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Send Message</button>
            </form>
          </div>
        </div>
      </div><!-- End Contact Form -->

    </div>

  </div>

</section><!-- /Contact Section -->
