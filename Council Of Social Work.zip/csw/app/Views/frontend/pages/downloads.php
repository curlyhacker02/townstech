<?php
// $downloads: array of all downloads from the database
// $categories: array of all categories from the database
$search = isset($_GET['q']) ? trim($_GET['q']) : '';
$filteredDownloads = $downloads;
if ($search !== '') {
    $filteredDownloads = array_filter($downloads, function($doc) use ($search) {
        return stripos($doc['title'], $search) !== false
            || stripos($doc['description'] ?? '', $search) !== false
            || stripos($doc['category'], $search) !== false;
    });
}
// Group filtered downloads by category name
$groupedDownloads = [];
if (!empty($filteredDownloads)) {
    foreach ($filteredDownloads as $doc) {
        $cat = $doc['category'] ?? 'Other';
        $groupedDownloads[$cat][] = $doc;
    }
}
?>
<!-- Downloads Section -->
<section class="py-5 bg-csw-dark text-white text-center">
</br>
  <div class="container">
    <h1 class="display-5 fw-bold">Downloads</h1>
    <p class="lead">Access important documents and resources related to the Zimbabwe Council of Social Workers.</p>
    <form method="get" class="my-4">
      <div class="input-group input-group-lg justify-content-center">
        <input type="text" name="q" class="form-control w-50" placeholder="Search for a document..." value="<?= esc($search) ?>">
        <button class="btn btn-primary" type="submit"><i class="bi bi-search"></i> Search</button>
      </div>
    </form>
  </div>
</section>

<section class="section downloads-section">
  <div class="container">
    <div class="row">
      <?php if (!empty($categories)): ?>
        <?php foreach ($categories as $cat): ?>
          <?php $docs = $groupedDownloads[$cat['name']] ?? []; ?>
          <div class="col-lg-6 mb-5" id="<?= strtolower(htmlspecialchars($cat['name'])) ?>">
            <h2 class="section-title"><?= htmlspecialchars($cat['name']) ?></h2>
            <ul class="list-group">
              <?php if (!empty($docs)): ?>
                <?php foreach ($docs as $doc): ?>
                  <li class="list-group-item d-flex justify-content-between align-items-center">
                    <div>
                      <strong><?= htmlspecialchars($doc['title']) ?></strong>
                      <?php if (!empty($doc['description'])): ?>
                        <br><small class="text-muted"><?= htmlspecialchars($doc['description']) ?></small>
                      <?php endif; ?>
                    </div>
                    <a href="<?= htmlspecialchars($doc['url']) ?>" class="btn btn-csw-primary btn-sm" download>
                      <i class="bi bi-download"></i> Download
                    </a>
                  </li>
                <?php endforeach; ?>
              <?php else: ?>
                <li class="list-group-item text-center text-muted">No downloads available at this time.</li>
              <?php endif; ?>
            </ul>
          </div>
        <?php endforeach; ?>
      <?php else: ?>
        <div class="col-12">
          <div class="alert alert-info text-center">
            No download categories available.
          </div>
        </div>
      <?php endif; ?>
    </div>
  </div>
</section>