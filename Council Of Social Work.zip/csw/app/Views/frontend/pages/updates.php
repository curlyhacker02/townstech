<section class="py-5 bg-csw-dark text-white text-center position-relative">
  <div class="container position-relative z-2">
    <h1 class="display-4 fw-bold mb-2">Updates</h1>
    <p class="lead mb-0">Latest News & Articles</p>
  </div>
  <div class="bg-overlay position-absolute top-0 start-0 w-100 h-100" style="background: linear-gradient(90deg, #1a2233 60%, rgba(26,34,51,0.7) 100%); opacity: 0.7;"></div>
</section>
<div class="container py-5">
  <div class="row">
    <div class="col-lg-8">
      <!-- Blog Posts Section -->
      <section id="blog-posts" class="blog-posts section">
        <div class="row gy-4">
          <?php
          // Auto-capitalize each article's title
          foreach ($articles as &$article) {
              if (isset($article['title'])) {
                  $article['title'] = ucwords(strtolower($article['title']));
              }
          }
          unset($article);

          if (!empty($articles)) {
              foreach ($articles as $article) { ?>
                <div class="col-12">
                  <div class="card mb-4 shadow border-0 rounded-4 overflow-hidden h-100 bg-white">
                    <?php if (!empty($article['image'])): ?>
                      <img src="<?= base_url('uploads/news/' . esc($article['image'])) ?>" class="card-img-top object-fit-cover" style="height: 260px;" alt="<?= esc(ucwords(strtolower($article['title']))) ?>">
                    <?php endif; ?>
                    <div class="card-body p-4">
                      <h5 class="card-title mb-2 fw-bold text-csw-primary fs-4">
                        <a href="<?= site_url('news/' . esc($article['slug'])) ?>" class="text-decoration-none text-csw-primary"> <?= esc(ucwords(strtolower($article['title']))) ?> </a>
                      </h5>
                      <div class="mb-2 small text-muted">
                        <i class="bi bi-calendar-event"></i> <?= date('M d, Y', strtotime($article['created_at'])) ?>
                        <?php if (!empty($article['category_name'])): ?>
                          | <span class="badge bg-csw-primary text-white"> <?= esc($article['category_name']) ?> </span>
                        <?php endif; ?>
                      </div>
                      <p class="card-text fs-6 text-muted"> <?= esc(substr(strip_tags($article['content']), 0, 180)) . '...'; ?> </p>
                      <a href="<?= site_url('news/' . esc($article['slug'])) ?>" class="btn btn-csw-primary btn-sm rounded-pill px-4 mt-2">Read More <i class="bi bi-arrow-right"></i></a>
                    </div>
                  </div>
                </div>
          <?php }
          } else { ?>
          <div class="col-12 text-center text-muted py-5">
            <p>No articles are available at this time.</p>
          </div>
          <?php } ?>
        </div>
      </section>
      <!-- Blog Pagination Section -->
      <section id="blog-pagination" class="blog-pagination section mt-4">
        <div class="d-flex justify-content-center">
          <?= isset($pager) ? $pager->links('group1', 'default_full') : '' ?>
        </div>
      </section>
    </div>
    <div class="col-lg-4 sidebar">
      <div class="widgets-container ps-lg-4">
        <!-- Search Widget -->
        <div class="search-widget widget-item mb-4 p-4 bg-white rounded-4 shadow-sm">
          <h3 class="widget-title mb-3 text-csw-primary">Search</h3>
          <form action="<?= site_url('updates') ?>" method="get" class="d-flex gap-2">
            <input type="text" name="q" value="<?= esc($_GET['q'] ?? '') ?>" class="form-control rounded-pill" placeholder="Search articles...">
            <button type="submit" class="btn btn-csw-primary rounded-pill" title="Search"><i class="bi bi-search"></i></button>
          </form>
        </div>
        <!-- Categories Widget -->
        <div class="categories-widget widget-item mb-4 p-4 bg-white rounded-4 shadow-sm">
          <h3 class="widget-title mb-3 text-csw-primary">Categories</h3>
          <ul class="mt-3 text-muted list-unstyled">
            <?php if (!empty($categories)) {
                foreach ($categories as &$category) {
                    if (isset($category['name'])) {
                        $category['name'] = ucwords(strtolower($category['name']));
                    }
                }
                unset($category);
                foreach ($categories as $category) {
                    echo '<li class="mb-2"><i class="bi bi-folder2-open text-csw-primary me-2"></i>' . esc($category['name']) . ' <span class="badge bg-light text-csw-primary ms-1">' . esc($category['news_count']) . '</span></li>';
                }
            } else {
                echo '<li>No categories available</li>';
            } ?>
          </ul>
        </div>
        <!-- Recent Posts Widget -->
        <div class="recent-posts-widget widget-item mb-4 p-4 bg-white rounded-4 shadow-sm">
          <h3 class="widget-title mb-3 text-csw-primary">Recent Posts</h3>
          <?php if (!empty($recentPosts)) {
              foreach ($recentPosts as &$post) {
                  if (isset($post['title'])) {
                      $post['title'] = ucwords(strtolower($post['title']));
                  }
              }
              unset($post);
              echo '<ul class="list-unstyled">';
              foreach ($recentPosts as $post) {
                  echo '<li class="mb-3">'
                      . '<a href="' . site_url('news/' . esc($post['slug'])) . '" class="fw-semibold text-csw-primary text-decoration-none">' . esc($post['title']) . '</a>'
                      . '<br><small class="text-muted">' . date('M d, Y', strtotime($post['created_at'])) . '</small>'
                      . '</li>';
              }
              echo '</ul>';
          } else {
              echo '<div class="text-muted">No recent posts available</div>';
          } ?>
        </div>
        <!-- Tags Widget -->
        <div class="tags-widget widget-item p-4 bg-white rounded-4 shadow-sm">
          <h3 class="widget-title mb-3 text-csw-primary">Tags</h3>
          <ul class="text-muted list-inline mb-0">
            <?php if (!empty($tags)) {
                foreach ($tags as $tag) {
                    echo '<li class="list-inline-item mb-2"><a href="' . site_url('news/tag/' . esc($tag['id'])) . '" class="badge bg-csw-primary text-white px-3 py-2 rounded-pill">' . esc($tag['name']) . '</a></li>';
                }
            } else {
                echo '<li>No tags available</li>';
            } ?>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>