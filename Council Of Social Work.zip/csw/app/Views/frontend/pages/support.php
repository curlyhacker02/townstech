<!-- Hero Section -->
<section class="py-5 bg-csw-dark text-white text-center">
</br>
  <div class="container">
    <h1 class="display-5 fw-bold">Help & Support</h1>
    <p class="lead">Find answers to common questions or contact us for assistance.</p>
  </div>
</section>

<!-- Main Content -->
<main class="py-5">
  <div class="container">
    <div class="row g-5">
      
      <!-- FAQ Section -->
      <div class="col-lg-8">
        <h2 class="mb-4">Frequently Asked Questions</h2>
        <div class="accordion" id="faqAccordion">
          <?php if (!empty($faqs)): ?>
            <?php foreach ($faqs as $index => $faq): ?>
              <div class="accordion-item">
                <h2 class="accordion-header" id="faq<?= $index ?>">
                  <button class="accordion-button <?= $index !== 0 ? 'collapsed' : '' ?>" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?= $index ?>">
                    <?= esc($faq['question']) ?>
                  </button>
                </h2>
                <div id="collapse<?= $index ?>" class="accordion-collapse collapse <?= $index === 0 ? 'show' : '' ?>" data-bs-parent="#faqAccordion">
                  <div class="accordion-body">
                    <?= esc($faq['answer']) ?>
                  </div>
                </div>
              </div>
            <?php endforeach; ?>
          <?php else: ?>
            <div class="alert alert-info">No FAQs available at this time.</div>
          <?php endif; ?>
        </div>
      </div>

      <!-- Sidebar with Quick Links -->
      <div class="col-lg-4">
        <div class="card shadow-sm">
          <div class="card-body">
            <h5 class="card-title">Need More Help?</h5>
            <ul class="list-unstyled">
              <li><i class="bi bi-envelope-fill text-csw-primary me-2"></i> Email: support@zcsw.org.zw</li>
              <li><i class="bi bi-phone-fill text-csw-primary me-2"></i> Call: +263 712 345 678</li>
              <li><i class="bi bi-clock-fill text-csw-primary me-2"></i> Mon–Fri: 8:00am – 4:30pm</li>
            </ul>
          </div>
        </div>

        <div class="card mt-4 shadow-sm">
          <div class="card-body">
            <h5 class="card-title">Quick Links</h5>
            <ul class="list-group list-group-flush">
              <li class="list-group-item"><a href="<?= site_url('login'); ?>">Login</a></li>
              <li class="list-group-item"><a href="<?= site_url('register'); ?>">Register</a></li>
             </ul>
          </div>
        </div>
      </div>
    </div>

</main>
