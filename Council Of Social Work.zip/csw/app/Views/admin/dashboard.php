<div class="row">
  <div class="col-12">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Welcome, Admin!</h5>
        <p class="card-text">You are now in the AdminLTE-powered dashboard.</p>
      </div>
    </div>
  </div>
</div>


