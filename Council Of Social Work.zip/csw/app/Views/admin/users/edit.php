<h1 class="mb-4"><?= esc($title) ?></h1>

<?= view('admin/partials/flash') ?>

<form action="<?= site_url('admin/users/update/' . $user->id) ?>" method="post">
  <?= csrf_field() ?>
  <?= view('admin/users/form', ['user' => $user, 'roles' => $roles, 'userRoles' => $userRoles]) ?>

  <button type="submit" class="btn btn-primary">Update</button>
  <a href="<?= site_url('admin/users') ?>" class="btn btn-secondary">Cancel</a>
</form>
