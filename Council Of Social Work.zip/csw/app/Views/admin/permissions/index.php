<h1><?= esc($title) ?></h1>
<?= view('admin/partials/flash') ?>
<a href="<?= site_url('/admin/permissions/create') ?>" class="btn btn-primary mb-3">Create Permission</a>

<table class="table table-bordered">
    <thead>
        <tr>
            <th>Name</th>
            <th>Description</th>
            <th>Created</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($permissions as $permission): ?>
            <tr>
                <td><?= esc($permission->name) ?></td>
                <td><?= esc($permission->description) ?></td>
                <td><?= esc($permission->created_at) ?></td>
                <td>
                    <a href="<?= site_url("/admin/permissions/edit/{$permission->id}") ?>" class="btn btn-sm btn-warning">Edit</a>
                    <form action="<?= site_url("/admin/permissions/delete/{$permission->id}") ?>" method="post" style="display:inline;" onsubmit="return confirm('Delete this permission?');">
                        <?= csrf_field() ?>
                        <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach ?>
    </tbody>
</table>