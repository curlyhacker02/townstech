<h1><?= esc($title) ?></h1>
<?= view('admin/partials/flash') ?>

<form action="<?= site_url('admin/profiles/store') ?>" method="post">
    <?= csrf_field() ?>

    <div class="mb-3">
        <label for="user_id" class="form-label">User</label>
        <select name="user_id" id="user_id" class="form-select" required>
            <option value="">-- Select User --</option>
            <?php foreach ($users as $user): ?>
                <option value="<?= esc($user->id) ?>"><?= esc($user->username) ?> (<?= esc($user->email) ?>)</option>
            <?php endforeach ?>
        </select>
    </div>

    <div class="mb-3">
        <label for="first_name" class="form-label">First Name</label>
        <input type="text" name="first_name" id="first_name" class="form-control" required>
    </div>

    <div class="mb-3">
        <label for="surname" class="form-label">Surname</label>
        <input type="text" name="surname" id="surname" class="form-control" required>
    </div>

    <div class="mb-3">
        <label for="dob" class="form-label">Date of Birth</label>
        <input type="date" name="dob" id="dob" class="form-control" required>
    </div>

    <div class="mb-3">
        <label for="gender" class="form-label">Gender</label>
        <select name="gender" id="gender" class="form-select" required>
            <option value="">-- Select --</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
        </select>
    </div>

    <div class="mb-3">
        <label for="nationality" class="form-label">Nationality</label>
        <input type="text" name="nationality" id="nationality" class="form-control">
    </div>

    <!-- Add more fields as needed -->

    <button class="btn btn-success">Save Profile</button>
</form>
