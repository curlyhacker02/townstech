<!-- Page Heading -->
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold">
        Reviewing Application: <?= esc($application['full_name']) ?>
    </h2>
    <span class="badge bg-<?= $application['status'] === 'approved' ? 'success' : ($application['status'] === 'rejected' ? 'danger' : 'info') ?>">
        <?= esc(ucfirst($application['status'])) ?>
    </span>
</div>

<?php if (session()->getFlashdata('message')): ?>
    <div class="alert alert-success">
        <?= esc(session()->getFlashdata('message')) ?>
    </div>
<?php endif; ?>

<!-- Application Sections -->
<div class="card mb-4">
    <div class="card-header fw-bold">Character Health Declaration</div>
    <div class="card-body">
        <p><strong>Health Condition:</strong> <?= esc($characterHealth['health_condition'] ?? 'Not specified') ?></p>
        <p><strong>Details:</strong> <?= esc($characterHealth['details'] ?? '-') ?></p>
    </div>
</div>

<div class="card mb-4">
    <div class="card-header fw-bold">Education and Training</div>
    <div class="card-body">
        <?php foreach ($educationTraining as $edu): ?>
            <div class="mb-3 border-bottom pb-2">
                <p><strong>Institution:</strong> <?= esc($edu['provider_name']) ?></p>
                <p><strong>Qualification:</strong> <?= esc($edu['training_title']) ?></p>
                <p><strong>Year Completed:</strong> <?= esc($edu['end_date']) ?></p>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<div class="card mb-4">
    <div class="card-header fw-bold">Work Details</div>
    <div class="card-body">
        <?php foreach ($workDetails as $work): ?>
            <div class="mb-3 border-bottom pb-2">
                <p><strong>Employer:</strong> <?= esc($work['organization']) ?></p>
                <p><strong>Position:</strong> <?= esc($work['post']) ?></p>
                <p><strong>Start Date:</strong> <?= esc($work['start_date']) ?></p>
                <p><strong>End Date:</strong> <?= esc($work['end_date'] ?? 'Present') ?></p>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<div class="card mb-4">
    <div class="card-header fw-bold">Employer Endorsement</div>
    <div class="card-body">
        <p><strong>Endorser Name:</strong> <?= esc($employerEndorsement['endorser_name'] ?? '-') ?></p>
        <p><strong>Position:</strong> <?= esc($employerEndorsement['endorser_position'] ?? '-') ?></p>
        <p><strong>Date:</strong> <?= esc($employerEndorsement['date'] ?? '-') ?></p>
    </div>
</div>

<div class="card mb-4">
    <div class="card-header fw-bold">Character Reference</div>
    <div class="card-body">
        <p><strong>Referee Name:</strong> <?= esc($characterReference['referee_name'] ?? '-') ?></p>
        <p><strong>Contact:</strong> <?= esc($characterReference['referee_contact'] ?? '-') ?></p>
    </div>
</div>

<!-- Moderation Panel -->
<div class="card mb-5">
    <div class="card-header fw-bold">Moderation Decision</div>
    <div class="card-body">
        <form action="<?= site_url('admin/applications/moderate/' . $application['id']) ?>" method="post">
            <?= csrf_field() ?>
            <div class="mb-3">
                <label for="status" class="form-label">Moderation Status</label>
                <select name="status" id="status" class="form-select" required>
                    <option value="">-- Select --</option>
                    <option value="approved" <?= $application['status'] === 'approved' ? 'selected' : '' ?>>Approve</option>
                    <option value="rejected" <?= $application['status'] === 'rejected' ? 'selected' : '' ?>>Reject</option>
                    <option value="under_review" <?= $application['status'] === 'under_review' ? 'selected' : '' ?>>Under Review</option>
                </select>
            </div>

            <div class="mb-3">
                <label for="moderation_notes" class="form-label">Moderation Notes <span class="text-muted">(optional)</span></label>
                <textarea name="moderation_notes" id="moderation_notes" class="form-control" rows="4"><?= esc($application['moderation_notes'] ?? '') ?></textarea>
            </div>

            <div class="d-flex justify-content-between">
                <a href="<?= site_url('admin/applications') ?>" class="btn btn-outline-secondary">← Back</a>
                <button type="submit" class="btn btn-primary">Submit Decision</button>
            </div>
        </form>
    </div>
</div>
