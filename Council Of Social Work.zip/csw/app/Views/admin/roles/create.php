<h1><?= esc($title) ?></h1>

<form action="<?= site_url('admin/roles/store') ?>" method="post">
    <?= csrf_field() ?>

    <div class="mb-3">
        <label for="name" class="form-label">Role Name</label>
        <input type="text" name="name" class="form-control" value="<?= old('name') ?>" required>
    </div>

    <div class="mb-3">
        <label for="description" class="form-label">Description</label>
        <textarea name="description" class="form-control"><?= old('description') ?></textarea>
    </div>

    <div class="mb-3">
        <label class="form-label">Permissions</label>

        <?php
        // Group permissions by prefix
        $groupedPermissions = [];
        foreach ($permissions as $permission) {
            $parts = explode('.', $permission->name);
            $group = ucfirst($parts[0]); // e.g., 'user' → 'User'
            $groupedPermissions[$group][] = $permission;
        }
        ?>

        <?php foreach ($groupedPermissions as $groupName => $perms): ?>
            <div class="mb-2">
                <strong><?= esc($groupName) ?> Permissions</strong>
                <?php foreach ($perms as $permission): ?>
                    <div class="form-check">
                        <input
                            type="checkbox"
                            name="permissions[]"
                            value="<?= esc($permission->id) ?>"
                            class="form-check-input"
                            id="perm_<?= esc($permission->id) ?>"
                        >
                        <label class="form-check-label" for="perm_<?= esc($permission->id) ?>">
                            <?= esc($permission->name) ?> - <?= esc($permission->description) ?>
                        </label>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endforeach; ?>
    </div>

    <button type="submit" class="btn btn-success">Create Role</button>
</form>
