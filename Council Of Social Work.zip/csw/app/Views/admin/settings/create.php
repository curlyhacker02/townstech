<h1>Create New Setting</h1>

<?php if(session()->getFlashdata('errors')): ?>
    <div class="alert alert-danger">
        <ul>
            <?php foreach(session()->getFlashdata('errors') as $error): ?>
                <li><?= esc($error) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<form action="<?= site_url('admin/settings/store') ?>" method="post">
    <?= csrf_field() ?>

    <div class="form-group mb-3">
        <label for="key">Key</label>
        <input type="text" name="key" id="key" class="form-control" value="<?= set_value('key') ?>" required>
    </div>

    <div class="form-group mb-3">
        <label for="value">Value</label>
        <textarea name="value" id="value" class="form-control" rows="2" required><?= set_value('value') ?></textarea>
    </div>

    <div class="form-group mb-3">
        <label for="description">Description (optional)</label>
        <textarea name="description" id="description" class="form-control" rows="4"><?= set_value('description') ?></textarea>
    </div>

    <button type="submit" class="btn btn-primary">Create Setting</button>
    <a href="<?= site_url('admin/settings') ?>" class="btn btn-secondary">Cancel</a>
</form>

