<h1><?= esc($title) ?></h1>

<form action="<?= site_url('admin/settings/update/' . $setting['id']) ?>" method="post">
    <?= csrf_field() ?>

    <div class="mb-3">
        <label for="key" class="form-label">Key</label>
        <input type="text" readonly class="form-control" id="key" name="key" value="<?= esc($setting['key']) ?>">
    </div>

    <div class="mb-3">
        <label for="value" class="form-label">Value</label>
        <textarea class="form-control" id="value" name="value" rows="2"><?= esc($setting['value']) ?></textarea>
    </div>

    <div class="mb-3">
        <label for="description" class="form-label">Description</label>
        <textarea class="form-control" id="description" name="description" rows="4"><?= esc($setting['description']) ?></textarea>
    </div>

    <?php if(session()->getFlashdata('errors')): ?>
        <div class="alert alert-danger">
            <?php foreach(session()->getFlashdata('errors') as $error): ?>
                <p><?= esc($error) ?></p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <button type="submit" class="btn btn-primary">Update Setting</button>
    <a href="<?= site_url('admin/settings') ?>" class="btn btn-secondary">Cancel</a>
</form>