<?php

use CodeIgniter\Router\RouteCollection;

$routes->get('/', 'Frontend\Home::index');
    $routes->get('support', 'Frontend\Home::support');
    $routes->get('downloads', 'Frontend\Home::downloads');
    $routes->get('about', 'Frontend\Home::about');
    $routes->get('contact', 'Frontend\Home::contact');
    $routes->post('contact', 'Frontend\Home::contact');
    $routes->get('updates', 'Frontend\Home::updates');
    $routes->get('updateDetails', 'Frontend\Home::updatesDetails');
    $routes->post('testimonials/submit', 'Home_c::submitTestimonial');
    $routes->get('news/(:segment)', 'Frontend\Home::updatesDetails/$1');

/**
 * @var RouteCollection $routes
 */

// Autoload module routes
$modulesPath = ROOTPATH . 'app/Modules/';
$modules = scandir($modulesPath);

foreach ($modules as $module) {
    if ($module === '.' || $module === '..') continue;

    $routePath = $modulesPath . $module . '/Config/Routes.php';
    if (file_exists($routePath)) {
        require $routePath;
    }
}

// At the bottom of Routes.php
if (file_exists(APPPATH . 'Modules/Registration/Config/Routes.php')) {
    require APPPATH . 'Modules/Registration/Config/Routes.php';
}

