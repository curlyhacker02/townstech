<?php namespace App\Modules\Contact\Controllers;
use App\Controllers\BaseController;
use App\Modules\Contact\Models\Contact_m;

class Contact_c extends BaseController
{
    protected $contactModel;

    public function __construct()
    {
        $this->contactModel = new Contact_m();
    }

    // View and edit contact info
    public function edit()
    {
        $data['info'] = $this->contactModel->getInfo();

        if ($this->request->getMethod() === 'post') {
            $updateData = $this->request->getPost(['address', 'phone', 'email']);
            $this->contactModel->updateInfo('contact', $updateData);
            return redirect()->to('admin/contact/edit')->with('success', 'Contact info updated.');
        }

        return view('App\Modules\Contact\Views\edit', $data);
    }

    // View messages
    public function index()
    {
        $data['messages'] = $this->contactModel->getMessages();
        return view('App\Modules\Contact\Views\index', $data);
    }

    // View single message
    public function view($id)
    {
        $data['msg'] = $this->contactModel->getMessage($id);
        if (!$data['msg']) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('Message not found');
        }
        return view('App\Modules\Contact\Views\view', $data);
    }

    // Delete message
    public function delete($id)
    {
        $this->contactModel->delete($id);
        return redirect()->to('admin/contact')->with('success', 'Message deleted.');
    }
}
