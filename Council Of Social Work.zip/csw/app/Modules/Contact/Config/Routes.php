<?php

$routes->group('admin/contact', ['namespace' => 'App\Modules\Contact\Controllers'], function($routes) {
    $routes->get('/', 'Contact_c::index');
    $routes->get('edit', 'Contact_c::edit');
    $routes->post('edit', 'Contact_c::edit');
    $routes->get('view/(:num)', 'Contact_c::view/$1');
    $routes->get('delete/(:num)', 'Contact_c::delete/$1');
});
