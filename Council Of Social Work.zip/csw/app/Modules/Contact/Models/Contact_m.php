<?php
namespace App\Modules\Contact\Models;

use CodeIgniter\Model;

class Contact_m extends Model
{
    protected $table = 'contact_messages';
    protected $allowedFields = ['name', 'email', 'subject', 'message', 'created_at'];
    protected $useTimestamps = false;

    // Get static contact info
    public function getInfo($slug = 'contact')
    {
        return $this->db->table('contact_info')
            ->where('slug', $slug)
            ->get()
            ->getRowArray();
    }

    // Update static contact info
    public function updateInfo($slug, $data)
    {
        return $this->db->table('contact_info')
            ->where('slug', $slug)
            ->update($data);
    }

    // Get all messages
    public function getMessages()
    {
        return $this->orderBy('created_at', 'DESC')->findAll();
    }

    // Get one message
    public function getMessage($id)
    {
        return $this->find($id);
    }
}
