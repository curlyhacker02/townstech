<?= view('layout/dashheader') ?>
<?= view('layout/dashmenu') ?>

<div class="container">
    <h2>Message from <?= esc($msg['name']) ?></h2>
<p><strong>Email:</strong> <?= esc($msg['email']) ?></p>
<p><strong>Subject:</strong> <?= esc($msg['subject']) ?></p>
<p><strong>Message:</strong></p>
<p><?= esc($msg['message']) ?></p>


<?= view('layout/dashfooter') ?>
