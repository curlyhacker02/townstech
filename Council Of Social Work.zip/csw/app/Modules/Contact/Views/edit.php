<?= view('layout/dashheader') ?>
<?= view('layout/dashmenu') ?>

<div class="container">
    <h2>Edit Contact Info</h2>
<form method="post">
    <div class="form-group">
        <label>Address</label>
        <textarea name="address" class="form-control"><?= esc($info['address']) ?></textarea>
    </div>
    <div class="form-group">
        <label>Phone</label>
        <input name="phone" value="<?= esc($info['phone']) ?>" class="form-control" />
    </div>
    <div class="form-group">
        <label>Email</label>
        <input name="email" value="<?= esc($info['email']) ?>" class="form-control" />
    </div>
    <button type="submit" class="btn btn-primary">Save</button>
</form>


<?= view('layout/dashfooter') ?>
