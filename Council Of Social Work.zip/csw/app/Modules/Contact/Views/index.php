<?= view('layout/dashheader') ?>
<?= view('layout/dashmenu') ?>

<div class="container">
    <h2>Contact Messages</h2>
<table class="table table-bordered">
    <thead>
        <tr><th>Name</th><th>Email</th><th>Subject</th><th>Actions</th></tr>
    </thead>
    <tbody>
        <?php foreach ($messages as $msg): ?>
            <tr>
                <td><?= esc($msg['name']) ?></td>
                <td><?= esc($msg['email']) ?></td>
                <td><?= esc($msg['subject']) ?></td>
                <td>
                    <a href="<?= base_url('admin/contact/view/' . $msg['id']) ?>" class="btn btn-sm btn-info">View</a>
                    <a href="<?= base_url('admin/contact/delete/' . $msg['id']) ?>" onclick="return confirm('Delete?')" class="btn btn-sm btn-danger">Delete</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>


<?= view('layout/dashfooter') ?>
