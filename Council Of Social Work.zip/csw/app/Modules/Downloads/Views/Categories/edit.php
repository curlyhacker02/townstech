<?= view('Layout\\dashheader') ?>
<?= view('Layout\\dashmenu') ?>

<div class="container">
    <h2>Edit Download Category</h2>
    <form action="<?= base_url('admin/downloads/categories/update/' . $category['id']) ?>" method="post">
        <div class="mb-3">
            <label>Category Name</label>
            <input type="text" name="name" class="form-control" value="<?= esc($category['name']) ?>" required>
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
    </form>
</div>

<?= view('Layout\\dashfooter') ?>
