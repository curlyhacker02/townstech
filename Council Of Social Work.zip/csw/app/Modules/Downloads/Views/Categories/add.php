<?= view('Layout\\dashheader') ?>
<?= view('Layout\\dashmenu') ?>

<div class="container">
    <h2>Add Download Category</h2>
    <form action="<?= base_url('admin/downloads/categories/store') ?>" method="post">
        <div class="mb-3">
            <label>Category Name</label>
            <input type="text" name="name" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-success">Save</button>
    </form>
</div>

<?= view('Layout\\dashfooter') ?>
