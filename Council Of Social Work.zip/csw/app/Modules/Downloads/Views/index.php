<?= view('layout/dashheader') ?>
<?= view('layout/dashmenu') ?>

<div class="container">
    <h2>Downloads</h2>

    <div class="mb-3 d-flex gap-2">
        <a href="<?= base_url('admin/downloads/add') ?>" class="btn btn-primary">Add Download</a>
        <a href="<?= base_url('admin/downloads/categories') ?>" class="btn btn-secondary">
            <i class="bi bi-tags"></i> Manage Categories
        </a>
    </div>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Title</th>
                <th>Description</th>
                <th>Category</th>
                <th>File Path</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($downloads as $download): ?>
                <tr>
                    <td><?= esc($download['title']) ?></td>
                    <td><?= esc($download['description']) ?></td>
                    <td><?= esc($download['category_name']) ?></td>
                    <td><?= esc($download['file_path']) ?></td>
                    <td>
                        <a href="<?= base_url('admin/downloads/view/' . $download['id']) ?>" class="btn btn-info btn-sm">View</a>
                        <a href="<?= base_url('admin/downloads/edit/' . $download['id']) ?>" class="btn btn-warning btn-sm">Edit</a>
                        <a href="<?= base_url('admin/downloads/delete/' . $download['id']) ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this download?')">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?= view('layout/dashfooter') ?>
