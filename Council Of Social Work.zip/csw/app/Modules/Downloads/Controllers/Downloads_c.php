<?php

namespace App\Modules\Downloads\Controllers;

use App\Controllers\BaseController;
use App\Modules\Downloads\Models\Downloads_m;
use App\Modules\Downloads\Models\DownloadCategory_m;

class Downloads_c extends BaseController
{
    protected $downloadsModel;
    protected $categoryModel;

    public function __construct()
    {
        $this->downloadsModel = new Downloads_m();
        $this->categoryModel = new DownloadCategory_m();
    }

    public function index()
    {
        $data['downloads'] = $this->downloadsModel
            ->select('downloads.*, download_categories.name AS category_name')
            ->join('download_categories', 'download_categories.id = downloads.download_category_id')
            ->findAll();

        return view('App\\Modules\\Downloads\\Views\\index', $data);
    }

    public function add()
    {
        $data['categories'] = $this->categoryModel->findAll();
        return view('App\\Modules\\Downloads\\Views\\add', $data);
    }

    public function create()
    {
        $this->downloadsModel->save([
            'title' => $this->request->getPost('title'),
            'description' => $this->request->getPost('description'),
            'file_path' => $this->request->getPost('file_path'), // adjust for file upload later
            'download_category_id' => $this->request->getPost('download_category_id'),
        ]);

        return redirect()->to(base_url('admin/downloads'));
    }

  public function view($id)
{
    $db = \Config\Database::connect();
    $builder = $db->table('downloads');
    $builder->select('downloads.*, download_categories.name as category_name');
    $builder->join('download_categories', 'download_categories.id = downloads.download_category_id', 'left');
    $builder->where('downloads.id', $id);
    $query = $builder->get();

    $download = $query->getRowArray();

    if (!$download) {
        throw new \CodeIgniter\Exceptions\PageNotFoundException("Download with ID $id not found.");
    }

    return view('App\Modules\Downloads\Views\view_download', ['download' => $download]);
}





    public function edit($id)
    {
        $data['download'] = $this->downloadsModel->find($id);
        $data['categories'] = $this->categoryModel->findAll();

        return view('App\\Modules\\Downloads\\Views\\edit', $data);
    }

    public function update($id)
    {
        $this->downloadsModel->update($id, [
            'title' => $this->request->getPost('title'),
            'description' => $this->request->getPost('description'),
            'file_path' => $this->request->getPost('file_path'),
            'download_category_id' => $this->request->getPost('download_category_id'),
        ]);

        return redirect()->to(base_url('admin/downloads'));
    }

    public function delete($id)
    {
        $this->downloadsModel->delete($id);
        return redirect()->to(base_url('admin/downloads'));
    }
}
