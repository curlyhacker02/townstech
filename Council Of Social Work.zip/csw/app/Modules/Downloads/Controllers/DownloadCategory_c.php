<?php

namespace App\Modules\Downloads\Controllers;

use App\Controllers\BaseController;
use App\Modules\Downloads\Models\DownloadCategory_m;

class DownloadCategory_c extends BaseController
{
    protected $categoryModel;

    public function __construct()
    {
        $this->categoryModel = new DownloadCategory_m();
    }

    public function index()
    {
        $data['categories'] = $this->categoryModel->findAll();
        return view('App\\Modules\\Downloads\\Views\\Categories\\index', $data);
    }

    public function create()
    {
        return view('App\\Modules\\Downloads\\Views\\Categories\\add');
    }

    public function store()
    {
        $this->categoryModel->save([
            'name' => $this->request->getPost('name')
        ]);
        return redirect()->to(base_url('admin/downloads/categories'));
    }

    public function edit($id)
    {
        $data['category'] = $this->categoryModel->find($id);
        return view('App\\Modules\\Downloads\\Views\\Categories\\edit', $data);
    }

    public function update($id)
    {
        $this->categoryModel->update($id, [
            'name' => $this->request->getPost('name')
        ]);
        return redirect()->to(base_url('admin/downloads/categories'));
    }

    public function delete($id)
    {
        $this->categoryModel->delete($id);
        return redirect()->to(base_url('admin/downloads/categories'));
    }
}
