<?php
$routes->group('admin/downloads', ['namespace' => 'App\Modules\Downloads\Controllers'], function($routes) {
    $routes->get('/', 'Downloads_c::index');
    $routes->get('add', 'Downloads_c::add');
    $routes->post('create', 'Downloads_c::create');
    $routes->get('view/(:num)', 'Downloads_c::view/$1');
    $routes->get('edit/(:num)', 'Downloads_c::edit/$1');
    $routes->post('update/(:num)', 'Downloads_c::update/$1');
    $routes->get('delete/(:num)', 'Downloads_c::delete/$1');
});

$routes->group('admin/downloads/categories', ['namespace' => 'App\Modules\Downloads\Controllers'], function($routes){
    $routes->get('/', 'DownloadCategory_c::index');
    $routes->get('add', 'DownloadCategory_c::create');
    $routes->post('store', 'DownloadCategory_c::store');
    $routes->get('edit/(:num)', 'DownloadCategory_c::edit/$1');
    $routes->post('update/(:num)', 'DownloadCategory_c::update/$1');
    $routes->get('delete/(:num)', 'DownloadCategory_c::delete/$1');
});
