<?php

$routes->group('admin/testimonials', ['namespace' => 'App\Modules\Testimonials\Controllers'], function($routes) {
    $routes->get('/', 'Testimonials_c::index');
    $routes->get('create', 'Testimonials_c::create');
    $routes->post('store', 'Testimonials_c::store');
    $routes->get('edit/(:num)', 'Testimonials_c::edit/$1');
    $routes->post('update/(:num)', 'Testimonials_c::update/$1');
    $routes->get('delete/(:num)', 'Testimonials_c::delete/$1');
});
