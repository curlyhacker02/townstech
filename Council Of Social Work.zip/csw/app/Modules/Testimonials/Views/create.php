<?= view('App\Views\Layout\dashheader') ?>
<?= view('App\Views\Layout\dashmenu') ?>

<div class="container mt-4">
    <h2>Add Testimonial</h2>
    <form method="post" action="<?= base_url('admin/testimonials/store') ?>" enctype="multipart/form-data">
        <div class="mb-3">
            <label>Name</label>
            <input type="text" name="name" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Role</label>
            <input type="text" name="role" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Photo (optional)</label>
            <input type="file" name="photo" class="form-control">
        </div>

        <div class="mb-3">
            <label>Message</label>
            <textarea name="message" class="form-control" rows="4" required></textarea>
        </div>

        <div class="mb-3">
            <label>Status</label>
            <select name="status" class="form-control" required>
                <option value="pending">Pending</option>
                <option value="approved">Approved</option>
                <option value="rejected">Rejected</option>
            </select>
        </div>

        <button type="submit" class="btn btn-success">Save</button>
        <a href="<?= base_url('admin/testimonials') ?>" class="btn btn-secondary">Cancel</a>
    </form>
</div>

<?= view('App\Views\Layout\dashfooter') ?>
