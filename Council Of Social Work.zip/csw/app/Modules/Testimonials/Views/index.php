<?= view('App\Views\Layout\dashheader') ?>
<?= view('App\Views\Layout\dashmenu') ?>

<div class="container mt-4">
    <h2>Testimonials</h2>
    <a href="<?= base_url('admin/testimonials/create') ?>" class="btn btn-primary mb-3">Add Testimonial</a>

    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>Photo</th>
                <th>Name</th>
                <th>Role</th>
                <th>Message</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($testimonials)): ?>
                <tr><td colspan="6" class="text-center">No testimonials yet.</td></tr>
            <?php else: ?>
                <?php foreach ($testimonials as $t): ?>
                <tr>
                    <td>
                        <?php if (!empty($t['photo'])): ?>
                            <img src="<?= base_url('uploads/testimonials/' . $t['photo']) ?>" width="60" class="img-thumbnail">
                        <?php else: ?>
                            <span>No Photo</span>
                        <?php endif; ?>
                    </td>
                    <td><?= esc($t['name']) ?></td>
                    <td><?= esc($t['role']) ?></td>
                    <td><?= esc(character_limiter($t['message'], 60)) ?></td>
                    <td><?= esc(ucfirst($t['status'])) ?></td>
                    <td>
                        <a href="<?= base_url('admin/testimonials/edit/' . $t['id']) ?>" class="btn btn-sm btn-warning">Edit</a>
                        <a href="<?= base_url('admin/testimonials/delete/' . $t['id']) ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this testimonial?')">Delete</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?= view('App\Views\Layout\dashfooter') ?>
