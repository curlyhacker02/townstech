<?= view('App\Views\Layout\dashheader') ?>
<?= view('App\Views\Layout\dashmenu') ?>

<div class="container mt-4">
    <h2>Edit Testimonial</h2>
    <form method="post" action="<?= base_url('admin/testimonials/update/' . $testimonial['id']) ?>" enctype="multipart/form-data">
        <div class="mb-3">
            <label>Name</label>
            <input type="text" name="name" value="<?= esc($testimonial['name']) ?>" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Role</label>
            <input type="text" name="role" value="<?= esc($testimonial['role']) ?>" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Current Photo</label><br>
            <?php if (!empty($testimonial['photo'])): ?>
                <img src="<?= base_url('uploads/testimonials/' . $testimonial['photo']) ?>" width="80" class="img-thumbnail mb-2">
            <?php else: ?>
                <p>No Photo</p>
            <?php endif; ?>
            <input type="file" name="photo" class="form-control">
        </div>

        <div class="mb-3">
            <label>Message</label>
            <textarea name="message" class="form-control" rows="4" required><?= esc($testimonial['message']) ?></textarea>
        </div>

        <div class="mb-3">
            <label>Status</label>
            <select name="status" class="form-control" required>
                <?php foreach (['pending', 'approved', 'rejected'] as $stat): ?>
                    <option value="<?= $stat ?>" <?= $testimonial['status'] === $stat ? 'selected' : '' ?>>
                        <?= ucfirst($stat) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Update</button>
        <a href="<?= base_url('admin/testimonials') ?>" class="btn btn-secondary">Cancel</a>
    </form>
</div>

<?= view('App\Views\Layout\dashfooter') ?>
