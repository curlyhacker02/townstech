<?= $this->include('App\Views\layout\dashheader') ?>
<?= $this->include('App\Views\layout\dashmenu') ?>

<div class="content-wrapper">
    <section class="content-header">
        <h1>Registration Page</h1>
    </section>

    <section class="content">
        <a href="<?= base_url('admin/registration/edit/' . $pages['id']) ?>" class="btn btn-primary mb-3">Edit</a>

        <div class="card">
            <div class="card-body">
                <h3><?= esc($pages['title']) ?></h3>
                <div><?= esc($pages['content']) ?></div>
            </div>
        </div>
    </section>
</div>

<?= $this->include('App\Views\layout\dashfooter') ?>
