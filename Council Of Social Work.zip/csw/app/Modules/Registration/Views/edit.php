<?= $this->include('App\Views\layout\dashheader') ?>
<?= $this->include('App\Views\layout\dashmenu') ?>

<div class="content-wrapper">
    <section class="content-header">
        <h1>Edit Registration Page</h1>
    </section>

    <section class="content">
        <form action="<?= base_url('admin/registration/update/' . $page['id']) ?>" method="post">
            <div class="form-group">
                <label>Title</label>
                <input type="text" name="title" class="form-control" value="<?= esc($page['title']) ?>" required>
            </div>

            <div class="form-group">
                <label>Content</label>
                <textarea name="content" rows="8" class="form-control" required><?= esc($page['content']) ?></textarea>
            </div>

            <button type="submit" class="btn btn-success">Update</button>
        </form>
    </section>
</div>

<?= $this->include('App\Views\layout\dashfooter') ?>
