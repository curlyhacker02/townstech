<?php
namespace App\Modules\News\Models;

use CodeIgniter\Model;

class NewsCategory_m extends Model
{
    protected $table = 'news_categories';
    protected $primaryKey = 'id';
    protected $allowedFields = ['name', 'slug', 'created_at', 'updated_at'];
}
