<?= view('layout/dashheader') ?>
<?= view('layout/dashmenu') ?>

<div class="container">
  <h2>Create Article</h2>
  <form action="<?= base_url('admin/news/create') ?>" method="post" enctype="multipart/form-data">
    <div class="form-group">
      <label>Title</label>
      <input type="text" name="title" class="form-control" required>
    </div>
    <div class="form-group">
      <label>Author Name</label>
      <input type="text" name="author_name" class="form-control" required>
    </div>
    <div class="form-group">
      <label>Category</label>
      <select name="news_category_id" class="form-control">
        <?php foreach ($categories as $c): ?>
          <option value="<?= $c['id'] ?>"><?= esc($c['name']) ?></option>
        <?php endforeach ?>
      </select>
    </div>
    <div class="form-group">
      <label>Featured Image</label>
      <input type="file" name="image" class="form-control">
    </div>
    <div class="form-group">
      <label>Content</label>
      <textarea name="content" class="form-control" rows="10" required></textarea>
    </div>
    <button type="submit" class="btn btn-success">Publish</button>
  </form>
</div>

<?= view('layout/dashfooter') ?>
