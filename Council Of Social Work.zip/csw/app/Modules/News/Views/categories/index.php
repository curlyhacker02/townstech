<?= view('layout/dashheader') ?>
<?= view('layout/dashmenu') ?>

<div class="container">
  <h2>News Categories</h2>
  <a href="<?= base_url('admin/news/categories/add') ?>" class="btn btn-primary mb-3">Add Category</a>
  <table class="table table-bordered">
    <thead><tr><th>ID</th><th>Name</th><th>Slug</th><th>Actions</th></tr></thead>
    <tbody>
      <?php foreach ($cats as $c): ?>
      <tr>
        <td><?= esc($c['id']) ?></td>
        <td><?= esc($c['name']) ?></td>
        <td><?= esc($c['slug']) ?></td>
        <td>
          <a href="<?= base_url('admin/news/categories/edit/'.$c['id']) ?>" class="btn btn-sm btn-warning">Edit</a>
          <a href="<?= base_url('admin/news/categories/delete/'.$c['id']) ?>" onclick="return confirm('Delete?')" class="btn btn-sm btn-danger">Delete</a>
        </td>
      </tr>
      <?php endforeach ?>
    </tbody>
  </table>
</div>

<?= view('layout/dashfooter') ?>
