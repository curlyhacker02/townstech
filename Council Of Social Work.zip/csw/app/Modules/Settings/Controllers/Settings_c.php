<?php
namespace App\Modules\Settings\Controllers;

use App\Controllers\BaseController;
use App\Modules\Settings\Models\Settings_m;

class Settings_c extends BaseController
{
    protected $settingsModel;

    public function __construct()
    {
        $this->settingsModel = new Settings_m();
    }

    public function index()
    {
        $data['settings'] = $this->settingsModel->getAllSettings();
        return view('App\Modules\Settings\Views\index', $data);
    }

    public function update()
    {
        $post = $this->request->getPost();

        // Handle file upload for site_logo
        $logo = $this->request->getFile('site_logo');
        if ($logo && $logo->isValid() && !$logo->hasMoved()) {
            $newName = $logo->getRandomName();
            $logo->move(FCPATH . 'uploads/settings', $newName);
            $this->settingsModel->updateSetting('site_logo', 'uploads/settings/' . $newName);
        }

        foreach ($post as $key => $value) {
            $this->settingsModel->updateSetting($key, $value);
        }

        return redirect()->to('admin/settings')->with('success', 'Settings updated.');
    }
}
