<?php
namespace App\Modules\Settings\Models;

use CodeIgniter\Model;

class Settings_m extends Model
{
    protected $table = 'settings';
    protected $primaryKey = 'id';
    protected $allowedFields = ['key', 'value'];

    // Get a setting by key
    public function getSetting($key)
    {
        return $this->where('key', $key)->first();
    }

    // Get all settings as key-value array
    public function getAllSettings()
    {
        $settings = $this->findAll();
        $result = [];

        foreach ($settings as $setting) {
            $result[$setting['key']] = $setting['value'];
        }

        return $result;
    }

    // Save/update a setting
    public function updateSetting($key, $value)
    {
        $existing = $this->getSetting($key);

        if ($existing) {
            return $this->where('key', $key)->set(['value' => $value])->update();
        }

        return $this->insert(['key' => $key, 'value' => $value]);
    }
}
