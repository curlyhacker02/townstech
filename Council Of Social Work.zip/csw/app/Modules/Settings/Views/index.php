<?= view('App\Views\Layout\dashheader') ?>
<?= view('App\Views\Layout\dashmenu') ?>

<div class="container mt-4">
    <h3>Site Settings</h3>

    <?php if (session()->getFlashdata('success')): ?>
        <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
    <?php endif; ?>

    <form method="post" action="<?= base_url('admin/settings/update') ?>" enctype="multipart/form-data">
        <?= csrf_field() ?>

        <div class="form-group">
            <label>Site Name</label>
            <input type="text" name="site_name" class="form-control" value="<?= $settings['site_name'] ?? '' ?>">
        </div>

        <div class="form-group">
            <label>Tagline</label>
            <input type="text" name="site_tagline" class="form-control" value="<?= $settings['site_tagline'] ?? '' ?>">
        </div>

        <div class="form-group">
            <label>Contact Email</label>
            <input type="email" name="contact_email" class="form-control" value="<?= $settings['contact_email'] ?? '' ?>">
        </div>

        <div class="form-group">
            <label>Phone</label>
            <input type="text" name="contact_phone" class="form-control" value="<?= $settings['contact_phone'] ?? '' ?>">
        </div>

        <div class="form-group">
            <label>Address</label>
            <textarea name="contact_address" class="form-control"><?= $settings['contact_address'] ?? '' ?></textarea>
        </div>

        <div class="form-group">
            <label>Facebook URL</label>
            <input type="text" name="facebook_url" class="form-control" value="<?= $settings['facebook_url'] ?? '' ?>">
        </div>

        <div class="form-group">
            <label>Site Logo</label>
            <?php if (!empty($settings['site_logo'])): ?>
                <div><img src="<?= base_url($settings['site_logo']) ?>" width="100"></div>
            <?php endif; ?>
            <input type="file" name="site_logo" class="form-control">
        </div>

        <div class="form-group mt-3">
            <button class="btn btn-primary">Save Settings</button>
        </div>
    </form>
</div>

<?= view('App\Views\Layout\dashfooter') ?>
