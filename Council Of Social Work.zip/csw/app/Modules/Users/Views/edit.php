<?= view('App\Views\Layout\dashheader') ?>
<?= view('App\Views\Layout\dashmenu') ?>

<div class="container mt-4">
    <h2>Edit User</h2>
    <form method="post" action="<?= base_url('admin/users/update/' . $user['id']) ?>" enctype="multipart/form-data">
        <div class="mb-3">
            <label>Name</label>
            <input type="text" name="name" value="<?= esc($user['name']) ?>" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Email</label>
            <input type="email" name="email" value="<?= esc($user['email']) ?>" class="form-control">
        </div>

        <div class="mb-3">
            <label>Role</label>
            <input type="text" name="role" value="<?= esc($user['role']) ?>" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Current Photo</label><br>
            <?php if ($user['photo']): ?>
                <img src="<?= base_url('uploads/users/' . $user['photo']) ?>" width="80" class="img-thumbnail mb-2">
            <?php else: ?>
                <p>No Photo</p>
            <?php endif; ?>
            <input type="file" name="photo" class="form-control">
        </div>

        <button type="submit" class="btn btn-primary">Update</button>
    </form>
</div>

<?= view('App\Views\Layout\dashfooter') ?>
