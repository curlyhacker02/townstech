<?php 
$routes->group('admin/users', ['namespace' => 'App\Modules\Users\Controllers'], function($routes) {
    $routes->get('/', 'User_c::index');
    $routes->get('create', 'User_c::create');
    $routes->post('store', 'User_c::store');
    $routes->get('edit/(:num)', 'User_c::edit/$1');
    $routes->post('update/(:num)', 'User_c::update/$1');
    $routes->get('delete/(:num)', 'User_c::delete/$1');
});
