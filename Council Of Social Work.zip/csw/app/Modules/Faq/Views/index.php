<?= view('App\Views\Layout\dashheader') ?>
<?= view('App\Views\Layout\dashmenu') ?>

<div class="container mt-4">
    <h2>FAQs</h2>
    <a href="<?= site_url('admin/faq/create') ?>" class="btn btn-primary mb-3">Add New FAQ</a>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Question</th>
                <th>Answer</th>
                <th style="width:120px">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($faqs)): ?>
                <tr>
                    <td colspan="3" class="text-center">No FAQs found.</td>
                </tr>
            <?php else: foreach ($faqs as $faq): ?>
                <tr>
                    <td><?= esc($faq['question']) ?></td>
                    <td><?= esc($faq['answer']) ?></td>
                    <td>
                        <a href="<?= site_url('admin/faq/edit/' . $faq['id']) ?>" class="btn btn-sm btn-warning">Edit</a>
                        <a href="<?= site_url('admin/faq/delete/' . $faq['id']) ?>"
                           class="btn btn-sm btn-danger"
                           onclick="return confirm('Delete this FAQ?');">
                           Delete
                        </a>
                    </td>
                </tr>
            <?php endforeach; endif; ?>
        </tbody>
    </table>
</div>

<?= view('App\Views\Layout\dashfooter') ?>
