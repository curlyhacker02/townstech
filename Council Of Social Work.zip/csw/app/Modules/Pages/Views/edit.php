<?= view('Layout/dashheader') ?>
<?= view('Layout/dashmenu') ?>

<div class="container">
    <h2>Edit Page - <?= esc($page['title']) ?></h2>
    <form action="<?= base_url($action) ?>" method="post" enctype="multipart/form-data">
    <?= csrf_field() ?>

    <div class="mb-3">
        <label for="title" class="form-label">Title</label>
        <input type="text" name="title" class="form-control" value="<?= esc($page['title'] ?? '') ?>" required>
    </div>

    <div class="mb-3">
        <label for="slug" class="form-label">Slug</label>
        <input type="text" name="slug" class="form-control" value="<?= esc($page['slug'] ?? '') ?>" required>
    </div>

    <div class="mb-3">
        <label for="content" class="form-label">Content</label>
        <textarea name="content" class="form-control" rows="6"><?= esc($page['content'] ?? '') ?></textarea>
    </div>

    <div class="mb-3">
        <label for="mission" class="form-label">Mission</label>
        <textarea name="mission" class="form-control"><?= esc($page['mission'] ?? '') ?></textarea>
    </div>

    <div class="mb-3">
        <label for="vision" class="form-label">Vision</label>
        <textarea name="vision" class="form-control"><?= esc($page['vision'] ?? '') ?></textarea>
    </div>

    <div class="mb-3">
        <label for="history" class="form-label">Company History</label>
        <textarea name="history" class="form-control"><?= esc($page['history'] ?? '') ?></textarea>
    </div>

    <div class="mb-3">
        <label for="image" class="form-label">Image</label><br>
        <?php if (!empty($page['image'])): ?>
            <img src="<?= base_url('uploads/pages/' . $page['image']) ?>" alt="Image" width="120" class="mb-2"><br>
        <?php endif; ?>
        <input type="file" name="image" class="form-control">
    </div>

    <button type="submit" class="btn btn-primary"><?= $btnText ?></button>
</form>

</div>


<?= view('Layout/dashfooter') ?>
