<?= view('Layout/dashheader') ?>
<?= view('Layout/dashmenu') ?>

<div class="content-wrapper">
    <section class="content-header">
        <h1><?= esc($page['title']) ?></h1>
    </section>

    <section class="content">
        <div class="card card-body">
            <p><strong>Slug:</strong> <?= esc($page['slug']) ?></p>
            <p><strong>Status:</strong> <?= ucfirst($page['status']) ?></p>
            <hr>
            <p><?= esc($page['content']) ?></p>
            <a href="<?= base_url('admin/pages') ?>" class="btn btn-secondary mt-3">Back</a>
        </div>
    </section>
</div>

<?= view('Layout/dashfooter') ?>
