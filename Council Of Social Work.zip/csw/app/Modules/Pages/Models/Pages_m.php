<?php

namespace App\Modules\Pages\Models;

use CodeIgniter\Model;

class Pages_m extends Model
{
    protected $table      = 'pages';
    protected $primaryKey = 'id';

    protected $allowedFields = [
        'title', 'slug', 'intro', 'content',
        'hero_image', 'page_image', 'mission',
        'vision', 'values', 'history',
        'created_at', 'updated_at'
    ];

    protected $useTimestamps = true;
}
