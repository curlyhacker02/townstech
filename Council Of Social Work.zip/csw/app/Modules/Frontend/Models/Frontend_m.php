<?php
namespace App\Modules\Frontend\Models;

use CodeIgniter\Model;

class Frontend_m extends Model
{
    protected $table = 'contact_messages';
    protected $allowedFields = ['name', 'email', 'subject', 'message', 'created_at'];

    public function getContactInfo($slug = 'contact')
    {
        return $this->db->table('contact_info')
                        ->where('slug', $slug)
                        ->get()
                        ->getRowArray();
    }



    public function saveContactMessage($data)
{
    
    return $this->db->table('contact_messages')->insert($data);
}



}
