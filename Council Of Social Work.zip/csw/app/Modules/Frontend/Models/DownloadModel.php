<?php

namespace App\Modules\Frontend\Models;

use CodeIgniter\Model;

class DownloadModel extends Model
{
    protected $table = 'downloads';
    protected $allowedFields = ['title', 'description', 'file', 'status']; // removed download_category_id
    protected $returnType = 'array';

    /**
     * Get all downloads, optionally filtered by search query, grouped by category name.
     *
     * @param string|null $search
     * @return array
     */
    public function getDownloadsGroupedByCategory($search = null)
    {
        $builder = $this->db->table('downloads d')
            ->select('d.*, c.name as category_name')
            ->join('download_categories c', 'c.id = d.category_id') // changed join to use d.category_id
            ->where('d.status', 1)
            ->orderBy('c.name, d.title');

        if ($search) {
            $builder->groupStart()
                ->like('d.title', $search)
                ->orLike('d.description', $search)
                ->orLike('c.name', $search)
                ->groupEnd();
        }

        $results = $builder->get()->getResultArray();

        $grouped = [];
        foreach ($results as $row) {
            $grouped[$row['category_name']][] = $row;
        }

        return $grouped;
    }
}
