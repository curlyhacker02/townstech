<?php

namespace App\Modules\Frontend\Models;

use CodeIgniter\Model;

class Contact_m extends Model
{
    protected $table = 'contacts';
    protected $primaryKey = 'id';
    protected $allowedFields = ['name', 'email', 'subject', 'message'];
    public $timestamps = false;
}
