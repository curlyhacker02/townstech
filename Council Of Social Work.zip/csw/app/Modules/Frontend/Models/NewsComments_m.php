<?php 
namespace App\Modules\Frontend\Models;

use CodeIgniter\Model;

class NewsComments_m extends Model
{
    protected $table            = 'news_comments';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';

    // Enable automatic timestamps management
    protected $useTimestamps    = true;

    // Tell the model which fields to manage for timestamps
    protected $createdField     = 'created_at';
    protected $updatedField     = 'updated_at';

    protected $allowedFields    = ['news_id', 'name', 'email', 'comment'];
}
