<?php

namespace App\Modules\Frontend\Models;

use CodeIgniter\Model;

class SettingsModel extends Model
{
    protected $table = 'settings';
    protected $primaryKey = 'id';
    protected $allowedFields = ['key', 'value'];
    protected $returnType = 'array';

    public function getSetting($key)
    {
        $row = $this->where('key', $key)->first();
        return $row ? $row['value'] : null;
    }

    public function getAllSettings()
    {
        return $this->findAll();
    }
}
