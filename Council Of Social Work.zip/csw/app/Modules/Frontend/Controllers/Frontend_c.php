<?php
namespace App\Modules\Frontend\Controllers;

use App\Controllers\BaseController;
use App\Modules\Frontend\Models\Frontend_m;

class Frontend_c extends BaseFrontendController

{
    protected $frontendModel;

    public function __construct()
    {
        $this->frontendModel = new Frontend_m();
    }

    public function contact()
    {
        $data['info'] = $this->frontendModel->getContactInfo();

        if ($this->request->getMethod() === 'post') {
            $form = $this->request->getPost(['name', 'email', 'subject', 'message']);
            $form['created_at'] = date('Y-m-d H:i:s');
            $this->frontendModel->saveContactMessage($form);

            return redirect()->to('/contact')->with('success', 'Message sent successfully!');
        }

        return view('App\Modules\Frontend\Views\contact', $data);
    }
}
