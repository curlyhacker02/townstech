<?php
namespace App\Modules\Frontend\Controllers;

use App\Controllers\BaseController;
use App\Modules\Frontend\Models\FrontendSettings_m;

class BaseFrontendController extends BaseController
{
    protected $settings = [];

    public function __construct()
    {
        $model = new FrontendSettings_m();
        $this->settings = $model->getAll();

        // Make available to all views
        view()->setVar('settings', $this->settings);
    }
}
