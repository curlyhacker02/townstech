<?= view('App\Modules\Frontend\Views\layout\header') ?>


<section class="container mt-5">
    <h1><?= esc($home['welcome_message']) ?></h1>
    <p><?= esc($home['intro_paragraph']) ?></p>

    <h2>Why Join CSW</h2>
    <p><?= esc($home['why_join_csw']) ?></p>

    <div class="row text-center mt-4">
        <div class="col-md-3">
            <h3><?= esc($registered_users) ?>+</h3>
            <p>Registered Users</p>
        </div>
        <div class="col-md-3">
            <h3><?= esc($home['years_of_service']) ?>+</h3>
            <p>Years of Service</p>
        </div>
        <div class="col-md-3">
            <h3><?= esc($home['training_events']) ?>+</h3>
            <p>Training Events</p>
        </div>
        <div class="col-md-3">
            <h3><?= esc($home['professional_partners']) ?>+</h3>
            <p>Professional Partners</p>
        </div>
    </div>

    <hr class="my-5">

    <h2>What Our Members Say</h2>
    <div class="row">
        <?php foreach ($testimonials as $testimonial): ?>
            <div class="col-md-4 mb-4">
                <div class="card h-100">
                    <img src="<?= base_url('uploads/testimonials/' . esc($testimonial['photo'])) ?>" class="card-img-top" alt="<?= esc($testimonial['name']) ?>">
                    <div class="card-body">
                        <p class="card-text">"<?= esc($testimonial['message']) ?>"</p>
                        <h5 class="card-title mt-2"><?= esc($testimonial['name']) ?></h5>
                        <small class="text-muted"><?= esc($testimonial['role']) ?></small>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <hr class="my-5">

    <!-- Testimonial Submission Form -->
    <h2>Submit Your Testimonial</h2>
    <?php if (session('errors')): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach (session('errors') as $error): ?>
                    <li><?= esc($error) ?></li>
                <?php endforeach ?>
            </ul>
        </div>
    <?php endif ?>
    <?php if (session('success')): ?>
        <div class="alert alert-success">
            <?= esc(session('success')) ?>
        </div>
    <?php endif ?>
    <form action="<?= site_url('testimonials/submit') ?>" method="post" enctype="multipart/form-data">
        <?= csrf_field() ?>

        <div class="mb-3">
            <label for="name" class="form-label">Your Name</label>
            <input type="text" class="form-control" id="name" name="name" required>
        </div>

        <div class="mb-3">
            <label for="role" class="form-label">Your Role</label>
            <input type="text" class="form-control" id="role" name="role" required>
        </div>

        <div class="mb-3">
            <label for="photo" class="form-label">Upload Your Photo</label>
            <input type="file" class="form-control" id="photo" name="photo" accept="image/*" required>
        </div>

        <div class="mb-3">
            <label for="message" class="form-label">Your Testimonial</label>
            <textarea class="form-control" id="message" name="message" rows="4" required></textarea>
        </div>

        <button type="submit" class="btn btn-primary">Submit Testimonial</button>
    </form>
</section>

<?= view('App\Modules\Frontend\Views\layout\footer') ?>
