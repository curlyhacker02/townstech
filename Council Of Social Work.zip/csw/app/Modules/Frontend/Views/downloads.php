<?= view('App\Modules\Frontend\Views\Layout\header') ?>

<h2>Downloads</h2>

<?php if (!empty($downloads_by_category)): ?>
    <?php foreach ($downloads_by_category as $category => $items): ?>
        <h3><?= esc($category) ?></h3>
        <ul>
            <?php foreach ($items as $download): ?>
                <li>
                    <strong><?= esc($download['title']) ?></strong><br>
                    <p><?= esc($download['description']) ?></p>
                    <a href="<?= base_url('uploads/downloads/' . $download['file_path']) ?>" class="btn btn-primary" download>
                        Download
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php endforeach; ?>
<?php else: ?>
    <p>No downloads available.</p>
<?php endif; ?>

<?= view('App\Modules\Frontend\Views\Layout\footer') ?>
