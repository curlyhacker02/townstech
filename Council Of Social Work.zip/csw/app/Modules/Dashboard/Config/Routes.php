<?php
$routes->group('admin/dashboard', ['namespace' => 'App\Modules\Dashboard\Controllers'], function($routes) {
    $routes->get('/', 'Dashboard_c::index');
});
