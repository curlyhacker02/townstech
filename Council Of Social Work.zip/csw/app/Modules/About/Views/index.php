<?= view('App\Views\Layout\dashheader') ?>
<?= view('App\Views\Layout\dashmenu') ?>

<div class="container mt-4">
    <h2>About Page Content</h2>
    <a href="<?= site_url('admin/about/edit/' . $about['id']) ?>" class="btn btn-primary mb-3">Edit About Page</a>

    <div class="card">
        <div class="card-body">
            <h4>Who We Are</h4>
            <p><?= esc($about['who_we_are']) ?></p>

            <h4>Our Work</h4>
            <p><?= esc($about['our_work']) ?></p>

            <h4>Mission</h4>
            <p><?= esc($about['mission']) ?></p>

            <h4>Vision</h4>
            <p><?= esc($about['vision']) ?></p>

            <h4>Core Values</h4>
            <p><?= esc($about['core_values']) ?></p>
        </div>
    </div>
</div>

<?= view('App\Views\Layout\dashfooter') ?>
