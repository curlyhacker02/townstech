<?php 
namespace App\Modules\About\Controllers;

use App\Controllers\BaseController;
use App\Modules\About\Models\About_m;

class About_c extends BaseController
{
    protected $aboutModel;

    public function __construct()
    {
        $this->aboutModel = new About_m();
    }

    public function index()
    {
        $data['about'] = $this->aboutModel->first();
        return view('App\Modules\About\Views\index', $data);
    }

    public function create()
    {
        return view('App\Modules\About\Views\create');
    }

    public function store()
    {
        $this->aboutModel->save([
            'who_we_are'   => $this->request->getPost('who_we_are'),
            'our_work'     => $this->request->getPost('our_work'),
            'mission'      => $this->request->getPost('mission'),
            'vision'       => $this->request->getPost('vision'),
            'core_values'  => $this->request->getPost('core_values'),
        ]);
        return redirect()->to('admin/about');
    }

    public function edit($id)
    {
        $data['about'] = $this->aboutModel->find($id);
        return view('App\Modules\About\Views\edit', $data);
    }

    public function update($id)
    {
        $this->aboutModel->update($id, [
            'who_we_are'   => $this->request->getPost('who_we_are'),
            'our_work'     => $this->request->getPost('our_work'),
            'mission'      => $this->request->getPost('mission'),
            'vision'       => $this->request->getPost('vision'),
            'core_values'  => $this->request->getPost('core_values'),
        ]);
        return redirect()->to('admin/about');
    }
}
