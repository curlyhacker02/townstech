<?php 
$routes->group('admin/about', ['namespace' => 'App\Modules\About\Controllers'], function ($routes) {
    $routes->get('/', 'About_c::index');
    $routes->get('create', 'About_c::create');
    $routes->post('store', 'About_c::store');
    $routes->get('edit/(:num)', 'About_c::edit/$1');
    $routes->post('update/(:num)', 'About_c::update/$1');
});

