<?php 

namespace App\Modules\About\Models;

use CodeIgniter\Model;

class About_m extends Model
{
    protected $table = 'about';
    protected $primaryKey = 'id';
    protected $allowedFields = ['who_we_are', 'our_work', 'mission', 'vision', 'core_values'];
    protected $useTimestamps = true;
}
