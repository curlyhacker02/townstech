<?= view('App\Views\Layout\dashheader') ?>
<?= view('App\Views\Layout\dashmenu') ?>

<div class="container mt-4">
    <h2>Home Page Content</h2>
    <a href="<?= site_url('admin/home/edit/' . $home['id']) ?>" class="btn btn-primary mb-3">Edit Home Page</a>

    <div class="card">
        <div class="card-body">
            <h4>Welcome Message</h4>
            <p><?= esc($home['welcome_message']) ?></p>

            <h4>Intro Paragraph</h4>
            <p><?= esc($home['intro_paragraph']) ?></p>

            <h4>Why Join CSW</h4>
            <p><?= esc($home['why_join_csw']) ?></p>

            <h4>Statistics</h4>
            <ul>
                <li>Registered Users: <?= esc($registered_users) ?>+</li>
                <li>Years of Service: <?= esc($home['years_of_service']) ?>+</li>
                <li>Training Events: <?= esc($home['training_events']) ?>+</li>
                <li>Professional Partners: <?= esc($home['professional_partners']) ?>+</li>
            </ul>
        </div>
    </div>
</div>

<?= view('App\Views\Layout\dashfooter') ?>
