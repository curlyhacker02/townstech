<?php

$routes->group('admin/home', ['namespace' => 'App\Modules\Home\Controllers'], function($routes) {
    $routes->get('/', 'Home_c::index'); //
    $routes->get('edit', 'Home_c::edit');
    $routes->post('update', 'Home_c::update');
});
