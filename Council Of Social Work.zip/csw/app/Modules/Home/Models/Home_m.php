<?php

namespace App\Modules\Home\Models;

use CodeIgniter\Model;

class Home_m extends Model
{
    protected $table = 'home';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'welcome_message',
        'intro_paragraph',
        'why_join_csw',
        'years_of_service',
        'training_events',
        'professional_partners',
    ];

    public function getHomeData()
    {
        return $this->first(); // since only one row
    }
}
