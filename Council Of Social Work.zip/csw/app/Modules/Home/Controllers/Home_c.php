<?php

namespace App\Modules\Home\Controllers;

use App\Controllers\BaseController;
use App\Modules\Home\Models\Home_m;
use Config\Database;

class Home_c extends BaseController
{
    protected $homeModel;
    protected $db;

    public function __construct()
    {
        $this->homeModel = new Home_m();
        $this->db = Database::connect();
    }

    public function index()
    {
        $data['home'] = $this->homeModel->getHomeData();

        // Get testimonials for "What our members say"
        $data['testimonials'] = $this->db->table('testimonials')
            ->where('status', 'approved') // assuming 'approved' status for shown testimonials
            ->orderBy('id', 'DESC')
            ->limit(5)
            ->get()
            ->getResultArray();

        // Get registered users count dynamically
        $data['registered_users'] = $this->db->table('users')->countAllResults();

        return view('App\Modules\Home\Views\index', $data);
    }

    public function edit()
    {
        $data['home'] = $this->homeModel->getHomeData();
        return view('App\Modules\Home\Views\edit', $data);
    }

    public function update()
    {
        $home = $this->homeModel->getHomeData();

        $this->homeModel->update($home['id'], [
            'welcome_message'    => $this->request->getPost('welcome_message'),
            'intro_paragraph'    => $this->request->getPost('intro_paragraph'),
            'why_join_csw'       => $this->request->getPost('why_join_csw'),
            'years_of_service'   => $this->request->getPost('years_of_service'),
            'training_events'    => $this->request->getPost('training_events'),
            'professional_partners' => $this->request->getPost('professional_partners'),
        ]);

        return redirect()->to('admin/home/edit')->with('success', 'Home page updated successfully');
    }
}
