<?php

use App\Modules\Settings\Models\Settings_m;

if (!function_exists('get_setting')) {
    function get_setting(string $key)
    {
        static $settings = [];

        // Load settings once and reuse
        if (empty($settings)) {
            $model = new Settings_m();
            $allSettings = $model->findAll();
            foreach ($allSettings as $setting) {
                $settings[$setting['key']] = $setting['value'];
            }
        }

        return $settings[$key] ?? null;
    }
}
