<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class FrontendController extends BaseController
{
    protected $data = [];

    public function initController(\CodeIgniter\HTTP\RequestInterface $request, 
                                   \CodeIgniter\HTTP\ResponseInterface $response, 
                                   \Psr\Log\LoggerInterface $logger)
    {
        parent::initController($request, $response, $logger);

        // Default values for all frontend views
        $this->data['title'] = 'My Application';
        $this->data['page_title'] = '';
    }

    protected function render(string $view, array $viewData = [])
    {
        $data = array_merge($this->data, $viewData);

        echo view('frontend/layouts/header', $data);
        echo view($view, $data);
        echo view('frontend/layouts/footer', $data);
    }
}
