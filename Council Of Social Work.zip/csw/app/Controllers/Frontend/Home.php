<?php

namespace App\Controllers\Frontend;

use App\Controllers\FrontendController;

class Home extends FrontendController
{
    public function index()
    {
        $newsModel = new \App\Modules\Frontend\Models\News_m();
        $recentPosts = $newsModel->getRecentPosts(5);
        return $this->render('frontend/pages/home', [
            'page_title' => 'Welcome to the Homepage',
            'recentPosts' => $recentPosts,
        ]);
    } 

    public function support()
    {
        $faqModel = new \App\Modules\Frontend\Models\Faq_m();
        $faqs = $faqModel->findAll();
        return $this->render('frontend/pages/support', [
            'page_title' => 'Help & Support',
            'faqs' => $faqs,
        ]);
    }

    public function downloads()
    {
        $downloadsModel = new \App\Modules\Downloads\Models\Downloads_m();
        $categoryModel = new \App\Modules\Downloads\Models\DownloadCategory_m();

        // Fetch all categories
        $categories = $categoryModel->orderBy('name', 'ASC')->findAll();

        // Fetch all downloads and join with category name
        $downloadsRaw = $downloadsModel
            ->select('downloads.*, download_categories.name as category')
            ->join('download_categories', 'download_categories.id = downloads.download_category_id', 'left')
            ->findAll();

        // Optional: filter by search query
        $search = isset($_GET['q']) ? trim($_GET['q']) : '';
        $downloads = $downloadsRaw;
        if ($search !== '') {
            $downloads = array_filter($downloadsRaw, function($doc) use ($search) {
                return stripos($doc['title'], $search) !== false
                    || stripos($doc['description'] ?? '', $search) !== false
                    || stripos($doc['category'], $search) !== false;
            });
        }

        // Add file URL for each download, only if 'file' key exists
        foreach ($downloads as &$doc) {
            $doc['url'] = !empty($doc['file']) ? base_url('uploads/downloads/' . $doc['file']) : '';
        }
        unset($doc);

        return $this->render('frontend/pages/downloads', [
            'page_title' => 'Downloads',
            'downloads' => $downloads,
            'categories' => $categories,
            'search' => $search,
        ]);
    }
    
    public function about()
    {
        $aboutModel = new \App\Modules\About\Models\About_m();
        $about = $aboutModel->first();
        $whyUsSlides = [
            [
                'title' => 'Vision',
                'content' => $about['vision'] ?? '',
            ],
            [
                'title' => 'Mission',
                'content' => $about['mission'] ?? '',
            ],
            [
                'title' => 'Values',
                'content' => $about['core_values'] ?? '',
            ],
        ];
        return $this->render('frontend/pages/about', [
            'page_title' => 'About Us',
            'about' => $about,
            'whyUsSlides' => $whyUsSlides,
        ]);
    }

    public function contact()
    {
        $contactModel = new \App\Modules\Contact\Models\Contact_m();
        $contact = $contactModel->getInfo('contact');
        // Fallback if phones is a comma-separated string
        if (!empty($contact['phones']) && is_string($contact['phones'])) {
            $contact['phones'] = array_map('trim', explode(',', $contact['phones']));
        } elseif (empty($contact['phones'])) {
            $contact['phones'] = [];
        }

        // Handle POST (form submission)
        if ($this->request->getMethod() === 'post') {
            $data = [
                'name'    => trim($this->request->getPost('name')),
                'email'   => trim($this->request->getPost('email')),
                'subject' => trim($this->request->getPost('subject')),
                'message' => trim($this->request->getPost('message')),
                'created_at' => date('Y-m-d H:i:s'),
            ];
            // Basic validation
            if (empty($data['name']) || empty($data['email']) || empty($data['subject']) || empty($data['message'])) {
                session()->setFlashdata('error', 'All fields are required.');
                return redirect()->to(base_url('contact'))->withInput();
            }
            if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
                session()->setFlashdata('error', 'Please enter a valid email address.');
                return redirect()->to(base_url('contact'))->withInput();
            }
            // Save to DB
            try {
                $contactModel->insert($data);
                session()->setFlashdata('success', 'Thank you for contacting us! We will get back to you soon.');
                return redirect()->to(base_url('contact'));
            } catch (\Exception $e) {
                session()->setFlashdata('error', 'There was an error submitting your message. Please try again later.');
                return redirect()->to(base_url('contact'))->withInput();
            }
        }

        return $this->render('frontend/pages/contact', [
            'page_title' => 'Contact Us',
            'contact' => $contact,
        ]);
    }

    public function Updates()
    {
        $newsModel = new \App\Modules\Frontend\Models\News_m();
        $tagsModel = new \App\Modules\Frontend\Models\NewsTags_m();

        $categories = $newsModel->getCategoriesWithCount();
        $tags = $tagsModel->getAllTags();

        // Search functionality
        $q = $this->request->getGet('q');
        $page = (int)($this->request->getGet('page') ?? 1);
        if ($q) {
            $articles = $newsModel
                ->like('news.title', $q)
                ->orLike('news.content', $q)
                ->orLike('news.slug', $q)
                ->select('news.*, news_categories.name AS category_name')
                ->join('news_categories', 'news_categories.id = news.news_category_id', 'left')
                ->orderBy('news.created_at', 'DESC')
                ->paginate(6, 'group1', $page);
        } else {
            $articles = $newsModel->getPagedNews(6, $page);
        }
        $recentPosts = $newsModel->getRecentPosts(5);
        $pager = $newsModel->getPager();

        return $this->render('frontend/pages/updates', [
            'page_title' => 'Updates',
            'categories' => $categories,
            'tags' => $tags,
            'articles' => $articles,
            'recentPosts' => $recentPosts,
            'pager' => $pager,
        ]);
    }

    public function updatesDetails($slug = null)
    {
        $newsModel = new \App\Modules\Frontend\Models\News_m();
        $tagsModel = new \App\Modules\Frontend\Models\NewsTags_m();
        if (!$slug) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound('Article not found');
        }
        $article = $newsModel->getNewsBySlug($slug);
        if (!$article) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound('Article not found');
        }
        $comments = $newsModel->getComments($article['id']);
        $tags = $newsModel->getTags($article['id']); // Use getTags from News_m, not from NewsTags_m
        $categories = $newsModel->getCategoriesWithCount();
        $recentPostsWidget = $newsModel->getRecentPosts(5);
        $author = [
            'name' => $article['author_name'] ?? '',
            'photo' => $article['author_image'] ?? 'assets/img/blog/blog-author.jpg',
            'bio' => $article['author_bio'] ?? '',
            'twitter' => $article['author_twitter'] ?? '#',
            'facebook' => $article['author_facebook'] ?? '#',
            'instagram' => $article['author_instagram'] ?? '#',
        ];
        return $this->render('frontend/pages/updatesDetails', [
            'article' => $article,
            'comments' => $comments,
            'tags' => $tags,
            'categories' => $categories,
            'recentPostsWidget' => $recentPostsWidget,
            'author' => $author,
        ]);
    }
}

