<?php

use CodeIgniter\Router\RouteCollection;

$routes->get('/', 'Frontend\Home::index');
    $routes->get('support', 'Frontend\Home::support');
    $routes->get('downloads', 'Frontend\Home::downloads');
    $routes->get('about', 'Frontend\Home::about');
    $routes->match(['get', 'post'], 'contact', 'Frontend\Home::contact');
    $routes->get('updates', 'Frontend\UpdatesController::index');
    $routes->get('updates/(:segment)', 'Frontend\UpdatesController::view/$1');
    $routes->post('testimonials/submit', 'Home_c::submitTestimonial');
    $routes->get('news', 'Modules\Frontend\Controllers\News_c::index');
    $routes->get('news/(:segment)', 'Modules\Frontend\Controllers\News_c::show/$1');
    $routes->get('news/category/(:segment)', 'Frontend\UpdatesController::category/$1');

/**
 * @var RouteCollection $routes
 */

// Autoload module routes
$modulesPath = ROOTPATH . 'app/Modules/';
$modules = scandir($modulesPath);

foreach ($modules as $module) {
    if ($module === '.' || $module === '..') continue;

    $routePath = $modulesPath . $module . '/Config/Routes.php';
    if (file_exists($routePath)) {
        require $routePath;
    }
}

// At the bottom of Routes.php
if (file_exists(APPPATH . 'Modules/Registration/Config/Routes.php')) {
    require APPPATH . 'Modules/Registration/Config/Routes.php';
}

