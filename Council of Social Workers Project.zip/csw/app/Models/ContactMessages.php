<?php

namespace App\Models;

use CodeIgniter\Model;

class ContactMessages extends Model
{
    protected $table = 'contact_messages';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $useSoftDeletes = false;
    protected $protectFields = true;
    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = '';
    protected $deletedField = '';

    protected $validationRules = [
        'name' => 'required|min_length[2]|max_length[100]',
        'email' => 'required|valid_email|max_length[100]',
        'subject' => 'required|min_length[3]|max_length[255]',
        'message' => 'required|min_length[10]'
    ];

    protected $validationMessages = [
        'name' => [
            'required' => 'Name is required',
            'min_length' => 'Name must be at least 2 characters long',
            'max_length' => 'Name cannot exceed 100 characters'
        ],
        'email' => [
            'required' => 'Email is required',
            'valid_email' => 'Please enter a valid email address',
            'max_length' => 'Email cannot exceed 100 characters'
        ],
        'subject' => [
            'required' => 'Subject is required',
            'min_length' => 'Subject must be at least 3 characters long',
            'max_length' => 'Subject cannot exceed 255 characters'
        ],
        'message' => [
            'required' => 'Message is required',
            'min_length' => 'Message must be at least 10 characters long'
        ]
    ];

    protected $skipValidation = false;
    protected $cleanValidationRules = true;

    public function saveMessage($data)
    {
        try {
            // Log the data being saved
            log_message('info', 'Attempting to save contact message: ' . json_encode($data));
            
            // Add created_at timestamp if not present
            if (!isset($data['created_at'])) {
                $data['created_at'] = date('Y-m-d H:i:s');
            }
            
            // Try to save the data
            $result = parent::insert($data);
            
            if ($result === false) {
                $errors = $this->errors();
                log_message('error', 'Contact form save failed: ' . json_encode($errors));
                return false;
            }
            
            log_message('info', 'Contact message saved successfully with ID: ' . $this->getInsertID());
            return true;
        } catch (\Exception $e) {
            log_message('error', 'Contact form save error: ' . $e->getMessage());
            log_message('error', 'Contact form save error details: ' . json_encode($e->getTraceAsString()));
            return false;
        }
    }
}
