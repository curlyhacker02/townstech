<?php

if (!function_exists('capitalize_text')) {
    /**
     * Capitalize text with special handling for titles and names
     * @param string $text The text to capitalize
     * @return string The capitalized text
     */
    function capitalize_text($text)
    {
        // Handle special cases for titles and names
        $specialWords = [
            'zcs' => 'ZCS',
            'zcs' => 'ZCS',
            'zimbabwe' => 'Zimbabwe',
            'council' => 'Council',
            'social' => 'Social',
            'workers' => 'Workers',
            'cs' => 'CS',
            'zim' => 'ZIM'
        ];

        // Convert to lowercase first
        $text = strtolower($text);

        // Replace special words
        foreach ($specialWords as $search => $replace) {
            $text = str_replace($search, $replace, $text);
        }

        // Capitalize the first letter of each word
        return ucwords($text);
    }
}
