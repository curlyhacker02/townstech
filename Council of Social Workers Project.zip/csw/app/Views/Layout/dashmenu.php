
  <body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
    <!--begin::App Wrapper-->
    <div class="app-wrapper">
    
      <aside class="app-sidebar bg-body-secondary shadow" data-bs-theme="light">
        <!--begin::Sidebar Brand-->
        <div class="sidebar-brand">
          <!--begin::Brand Link-->
          <a href="<?= base_url(); ?>" class="brand-link">
            <!--begin::Brand Image-->
          <img
            src="<?= base_url(esc(get_setting('site_logo') ?? 'default-logo.jpg')) ?>"
            alt="<?= esc(get_setting('site_name') ?? 'CSW Site') ?> Logo"
            class="brand-image opacity-75 shadow" />

            <!--end::Brand Image-->

            <!--begin::Brand Text-->
            <span class="brand-text fw-light"><?= esc(get_setting('site_name')); ?></span>
            <!--end::Brand Text-->
          </a>
        </div>
        <!--end::Sidebar Brand-->
        <!--begin::Sidebar Wrapper-->
        <div class="sidebar-wrapper">
          <nav class="mt-2">
            <!--begin::Sidebar Menu-->
            <ul
              class="nav sidebar-menu flex-column"
              data-lte-toggle="treeview"
              role="menu"
              data-accordion="false"
            >
            <li class="nav-item">
                <a href="<?= base_url('admin/dashboard'); ?>" class="nav-link">
                  <i class="nav-icon bi bi-speedometer"></i>
                  <p>
                    Dashboard
                  </p>
                </a>
              </li>

              <li class="nav-item">
                <a href="<?= base_url('admin/home'); ?>" class="nav-link">
                  <i class="nav-icon bi bi-house"></i>
                  <p>
                   Home
                  </p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?= base_url('admin/about'); ?>" class="nav-link">
                  <i class="nav-icon bi bi-info-circle"></i>
                  <p>
                   About
                  </p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?= base_url('admin/news'); ?>" class="nav-link">
                  <i class="nav-icon bi bi-newspaper"></i>
                  <p>
                    News
                  </p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?= base_url('admin/downloads'); ?>" class="nav-link">
                  <i class="nav-icon bi bi-cloud-arrow-down"></i>
                  <p>
                    Downloads
                  </p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?= base_url('admin/contact'); ?>" class="nav-link">
                  <i class="nav-icon bi bi-person-lines-fill"></i>
                  <p>
                    Contacts  Us
                  </p>
                </a>
              </li>
             <li class="nav-item">
                <a href="<?= base_url('admin/registration'); ?>" class="nav-link">
                  <i class="nav-icon bi bi-person-plus"></i>
                  <p>
                    Users
                  </p>
                </a>
                <li class="nav-item">
                <a href="<?= base_url('admin/faq'); ?>" class="nav-link">
                  <i class="nav-icon bi bi-question-circle"></i>
                  <p>
                    Help&Support
                  </p>
                </a>
              </li>
               <li class="nav-item">
                <a href="<?= base_url('admin/testimonials'); ?>" class="nav-link">
                  <i class="nav-icon bi bi-chat-quote"></i>
                  <p>
                    Testimonials
                  </p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?= base_url('admin/settings'); ?>" class="nav-link">
                  <i class="nav-icon bi bi-gear"></i>
                  <p>
                    Settings
                  </p>
                </a>
              </li>
            </ul>
            <!--end::Sidebar Menu-->
          </nav>
        </div>
        <!--end::Sidebar Wrapper-->
      </aside>
