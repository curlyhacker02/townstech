<h1 class="mb-4"><?= esc($title) ?></h1>

<a href="<?= site_url('admin/settings/create') ?>" class="btn btn-success mb-4">
    <i class="bi bi-plus-lg"></i> Add Setting
</a>

<?= view('admin/partials/flash') ?>

<div class="table-responsive">
    <table class="table table-striped table-hover align-middle">
        <thead class="table-dark">
            <tr>
                <th scope="col">Key</th>
                <th scope="col">Value</th>
                <th scope="col">Description</th>
                <th scope="col" style="width: 140px;">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($settings as $setting): ?>
            <tr>
                <td><?= esc($setting['key']) ?></td>
                <td><?= esc($setting['value']) ?></td>
                <td><?= esc($setting['description']) ?></td>
                <td>
                    <a href="<?= site_url('admin/settings/edit/' . $setting['id']) ?>" class="btn btn-sm btn-primary me-1" title="Edit">
                        <i class="bi bi-pencil-fill"></i>
                    </a>

                    <form action="<?= site_url('admin/settings/delete/' . $setting['id']) ?>" method="post" style="display:inline;" onsubmit="return confirm('Are you sure you want to delete this setting?');">
                        <?= csrf_field() ?>
                        <button type="submit" class="btn btn-sm btn-danger" title="Delete">
                            <i class="bi bi-trash-fill"></i>
                        </button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
