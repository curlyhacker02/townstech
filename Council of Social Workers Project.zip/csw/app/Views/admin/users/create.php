<h1 class="mb-4"><?= esc($title) ?></h1>

<?= view('admin/partials/flash') ?>

<form action="<?= site_url('admin/users/store') ?>" method="post">
  <?= csrf_field() ?>

  <?= view('admin/users/form', ['user' => null, 'roles' => $roles]) ?>

  <button type="submit" class="btn btn-success">Create</button>
  <a href="<?= site_url('admin/users') ?>" class="btn btn-secondary">Cancel</a>
</form>
