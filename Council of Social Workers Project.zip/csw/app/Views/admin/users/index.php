<h1><?= esc($title) ?></h1>

<a href="<?= site_url('admin/users/create') ?>" class="btn btn-primary mb-3">Add User</a>

<table class="table table-bordered">
    <thead>
        <tr>
            <th>ID</th><th>Username</th><th>Email</th><th>Roles</th><th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($users as $user): ?>
        <tr>
            <td><?= esc($user->id) ?></td>
            <td><?= esc($user->username) ?></td>
            <td><?= esc($user->email) ?></td>
            <td>
                <?php if (!empty($user->roles)): ?>
                    <?= esc(implode(', ', array_map(fn($role) => $role->name, $user->roles))) ?>
                <?php else: ?>
                    <em>No role assigned</em>
                <?php endif ?>
            </td>
            <td>
                <a href="<?= site_url('admin/users/edit/' . $user->id) ?>" class="btn btn-sm btn-warning">Edit</a>
                <a href="<?= site_url('admin/users/delete/' . $user->id) ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this user?')">Delete</a>
            </td>
        </tr>
        <?php endforeach ?>
    </tbody>
</table>
