<h1 class="mb-4"><?= esc($title) ?></h1>
<?= view('admin/partials/flash') ?>

<form action="<?= site_url('admin/profiles/update/' . $profile['id']) ?>" method="post">
    <?= csrf_field() ?>
    <input type="hidden" name="id" value="<?= esc($profile['id']) ?>">

    <!-- User Info -->
    <div class="card mb-4">
        <div class="card-header">User Information</div>
        <div class="card-body">
            <div class="mb-3">
                <label class="form-label">User</label>
                <input type="text" class="form-control" value="<?= esc($user->username) ?> (<?= esc($user->email) ?>)" readonly>
                <input type="hidden" name="user_id" value="<?= esc($user->id) ?>">
            </div>
        </div>
    </div>

    <!-- Personal Information -->
    <div class="card mb-4">
        <div class="card-header">Personal Information</div>
        <div class="card-body">
            <div class="row g-3">
                <div class="col-md-3">
                    <label for="title" class="form-label">Title</label>
                    <input type="text" name="title" id="title" value="<?= esc($profile['title']) ?>" class="form-control">
                </div>
                <div class="col-md-4">
                    <label for="first_name" class="form-label">First Name</label>
                    <input type="text" name="first_name" id="first_name" value="<?= esc($profile['first_name']) ?>" class="form-control" required>
                </div>
                <div class="col-md-5">
                    <label for="surname" class="form-label">Surname</label>
                    <input type="text" name="surname" id="surname" value="<?= esc($profile['surname']) ?>" class="form-control" required>
                </div>
                <div class="col-md-6">
                    <label for="previous_name" class="form-label">Previous Name</label>
                    <input type="text" name="previous_name" id="previous_name" value="<?= esc($profile['previous_name']) ?>" class="form-control">
                </div>
                <div class="col-md-3">
                    <label for="dob" class="form-label">Date of Birth</label>
                    <input type="date" name="dob" id="dob" value="<?= esc($profile['dob']) ?>" class="form-control" required>
                </div>
                <div class="col-md-3">
                    <label for="gender" class="form-label">Gender</label>
                    <select name="gender" id="gender" class="form-select" required>
                        <option value="">-- Select --</option>
                        <option value="Male" <?= $profile['gender'] == 'Male' ? 'selected' : '' ?>>Male</option>
                        <option value="Female" <?= $profile['gender'] == 'Female' ? 'selected' : '' ?>>Female</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label for="nationality" class="form-label">Nationality</label>
                    <input type="text" name="nationality" id="nationality" value="<?= esc($profile['nationality']) ?>" class="form-control">
                </div>
                <div class="col-md-4">
                    <label for="national_id" class="form-label">National ID</label>
                    <input type="text" name="national_id" id="national_id" value="<?= esc($profile['national_id']) ?>" class="form-control">
                </div>
                <div class="col-md-4">
                    <label for="country_of_birth" class="form-label">Country of Birth</label>
                    <input type="text" name="country_of_birth" id="country_of_birth" value="<?= esc($profile['country_of_birth']) ?>" class="form-control">
                </div>
                <div class="col-md-4">
                    <label for="city_of_birth" class="form-label">City of Birth</label>
                    <input type="text" name="city_of_birth" id="city_of_birth" value="<?= esc($profile['city_of_birth']) ?>" class="form-control">
                </div>
            </div>
        </div>
    </div>

    <!-- Home Contact -->
    <div class="card mb-4">
        <div class="card-header">Home Contact</div>
        <div class="card-body">
            <div class="row g-3">
                <div class="col-md-3">
                    <label for="home_house_number" class="form-label">House No.</label>
                    <input type="text" name="home_house_number" id="home_house_number" value="<?= esc($profile['home_house_number']) ?>" class="form-control">
                </div>
                <div class="col-md-5">
                    <label for="home_street_name" class="form-label">Street Name</label>
                    <input type="text" name="home_street_name" id="home_street_name" value="<?= esc($profile['home_street_name']) ?>" class="form-control">
                </div>
                <div class="col-md-4">
                    <label for="home_city" class="form-label">City</label>
                    <input type="text" name="home_city" id="home_city" value="<?= esc($profile['home_city']) ?>" class="form-control">
                </div>
                <div class="col-md-4">
                    <label for="home_telephone" class="form-label">Telephone</label>
                    <input type="text" name="home_telephone" id="home_telephone" value="<?= esc($profile['home_telephone']) ?>" class="form-control">
                </div>
                <div class="col-md-4">
                    <label for="home_mobile" class="form-label">Mobile</label>
                    <input type="text" name="home_mobile" id="home_mobile" value="<?= esc($profile['home_mobile']) ?>" class="form-control">
                </div>
                <div class="col-md-4">
                    <label for="home_email" class="form-label">Email</label>
                    <input type="email" name="home_email" id="home_email" value="<?= esc($profile['home_email']) ?>" class="form-control">
                </div>
            </div>
        </div>
    </div>

    <!-- Work Contact -->
    <div class="card mb-4">
        <div class="card-header">Work Contact</div>
        <div class="card-body">
            <div class="row g-3">
                <div class="col-md-6">
                    <label for="work_organization" class="form-label">Organization</label>
                    <input type="text" name="work_organization" id="work_organization" value="<?= esc($profile['work_organization']) ?>" class="form-control">
                </div>
                <div class="col-md-6">
                    <label for="work_department" class="form-label">Department</label>
                    <input type="text" name="work_department" id="work_department" value="<?= esc($profile['work_department']) ?>" class="form-control">
                </div>
                <div class="col-md-4">
                    <label for="work_street_name" class="form-label">Street Name</label>
                    <input type="text" name="work_street_name" id="work_street_name" value="<?= esc($profile['work_street_name']) ?>" class="form-control">
                </div>
                <div class="col-md-4">
                    <label for="work_city" class="form-label">City</label>
                    <input type="text" name="work_city" id="work_city" value="<?= esc($profile['work_city']) ?>" class="form-control">
                </div>
                <div class="col-md-4">
                    <label for="work_country" class="form-label">Country</label>
                    <input type="text" name="work_country" id="work_country" value="<?= esc($profile['work_country']) ?>" class="form-control">
                </div>
                <div class="col-md-4">
                    <label for="work_telephone" class="form-label">Telephone</label>
                    <input type="text" name="work_telephone" id="work_telephone" value="<?= esc($profile['work_telephone']) ?>" class="form-control">
                </div>
                <div class="col-md-4">
                    <label for="work_mobile" class="form-label">Mobile</label>
                    <input type="text" name="work_mobile" id="work_mobile" value="<?= esc($profile['work_mobile']) ?>" class="form-control">
                </div>
                <div class="col-md-4">
                    <label for="work_email" class="form-label">Email</label>
                    <input type="email" name="work_email" id="work_email" value="<?= esc($profile['work_email']) ?>" class="form-control">
                </div>
            </div>
        </div>
    </div>

    <!-- Current Post -->
    <div class="card mb-4">
        <div class="card-header">Current Position</div>
        <div class="card-body">
            <div class="mb-3">
                <label for="current_post" class="form-label">Current Post</label>
                <input type="text" name="current_post" id="current_post" value="<?= esc($profile['current_post']) ?>" class="form-control">
            </div>
        </div>
    </div>

    <button class="btn btn-primary">Update Profile</button>
</form>
