<h1><?= esc($title) ?></h1>
<?= view('admin/partials/flash') ?>

<a href="<?= site_url('admin/profiles/create') ?>" class="btn btn-primary mb-3">Create New Profile</a>

<table class="table table-bordered">
    <thead>
        <tr>
            <th>Full Name</th>
            <th>User</th>
            <th>Gender</th>
            <th>DOB</th>
            <th>Nationality</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($profiles as $profile): ?>
            <tr>
                <td><?= esc($profile['first_name'] . ' ' . $profile['surname']) ?></td>
                <td><?= esc($profile['username'] ?? '-') ?> <br><small><?= esc($profile['email'] ?? '') ?></small></td>
                <td><?= esc($profile['gender']) ?></td>
                <td><?= esc($profile['dob']) ?></td>
                <td><?= esc($profile['nationality']) ?></td>
                <td>
                    <a href="<?= site_url('admin/profiles/view/' . $profile['id']) ?>" class="btn btn-sm btn-info">View</a>
                    <a href="<?= site_url('admin/profiles/edit/' . $profile['id']) ?>" class="btn btn-sm btn-warning">Edit</a>
                    <a href="<?= site_url('admin/profiles/delete/' . $profile['id']) ?>" onclick="return confirm('Delete this profile?');" class="btn btn-sm btn-danger">Delete</a>
                </td>

            </tr>
        <?php endforeach ?>
    </tbody>
</table>
