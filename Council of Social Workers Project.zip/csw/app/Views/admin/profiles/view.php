<div class="container mt-4">

    <div class="card shadow-lg mb-4">
        <div class="card-body d-flex flex-column flex-md-row align-items-center">
            <div class="me-md-4 mb-3 mb-md-0 text-center">
                <div class="bg-secondary rounded-circle" style="width: 120px; height: 120px; display: flex; align-items: center; justify-content: center; font-size: 40px; color: white;">
                    <?= strtoupper(substr($profile['first_name'], 0, 1)) ?>
                </div>
            </div>
            <div>
                <h2 class="mb-1"><?= esc($profile['title']) ?> <?= esc($profile['first_name']) ?> <?= esc($profile['surname']) ?></h2>
                <p class="text-muted mb-1"><?= esc($user->username) ?> — <?= esc($user->email) ?></p>
                <p class="mb-0"><strong>Current Post:</strong> <?= esc($profile['current_post']) ?></p>
            </div>
        </div>
    </div>

    <div class="row g-4">
        <!-- Personal Info -->
        <div class="col-md-6">
            <div class="card shadow-sm h-100">
                <div class="card-header bg-primary text-white">Personal Information</div>
                <div class="card-body">
                    <p><strong>Date of Birth:</strong> <?= esc($profile['dob']) ?></p>
                    <p><strong>Gender:</strong> <?= esc($profile['gender']) ?></p>
                    <p><strong>Nationality:</strong> <?= esc($profile['nationality']) ?></p>
                    <p><strong>National ID:</strong> <?= esc($profile['national_id']) ?></p>
                    <p><strong>Birthplace:</strong> <?= esc($profile['city_of_birth']) ?>, <?= esc($profile['country_of_birth']) ?></p>
                    <?php if (!empty($profile['previous_name'])): ?>
                        <p><strong>Previous Name:</strong> <?= esc($profile['previous_name']) ?></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Home Contact -->
        <div class="col-md-6">
            <div class="card shadow-sm h-100">
                <div class="card-header bg-success text-white">Home Contact</div>
                <div class="card-body">
                    <p><strong>Address:</strong> <?= esc($profile['home_house_number']) ?> <?= esc($profile['home_street_name']) ?>, <?= esc($profile['home_city']) ?></p>
                    <p><strong>Telephone:</strong> <?= esc($profile['home_telephone']) ?></p>
                    <p><strong>Mobile:</strong> <?= esc($profile['home_mobile']) ?></p>
                    <p><strong>Email:</strong> <?= esc($profile['home_email']) ?></p>
                </div>
            </div>
        </div>

        <!-- Work Contact -->
        <div class="col-md-6">
            <div class="card shadow-sm h-100">
                <div class="card-header bg-info text-white">Work Contact</div>
                <div class="card-body">
                    <p><strong>Organization:</strong> <?= esc($profile['work_organization']) ?></p>
                    <p><strong>Department:</strong> <?= esc($profile['work_department']) ?></p>
                    <p><strong>Address:</strong> <?= esc($profile['work_street_name']) ?>, <?= esc($profile['work_city']) ?>, <?= esc($profile['work_country']) ?></p>
                    <p><strong>Telephone:</strong> <?= esc($profile['work_telephone']) ?></p>
                    <p><strong>Mobile:</strong> <?= esc($profile['work_mobile']) ?></p>
                    <p><strong>Email:</strong> <?= esc($profile['work_email']) ?></p>
                </div>
            </div>
        </div>
    </div>

    <div class="mt-4 text-end">
        <a href="<?= site_url('admin/profiles/edit/' . $profile['id']) ?>" class="btn btn-warning me-2">Edit Profile</a>
        <a href="<?= site_url('admin/profiles') ?>" class="btn btn-secondary">Back to List</a>
    </div>
</div>
