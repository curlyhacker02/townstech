<!--begin::Sidebar-->
<aside class="app-sidebar bg-body-secondary shadow" data-bs-theme="dark">
  <!--begin::Sidebar Brand-->
  <div class="sidebar-brand">
    <a href="/dashboard" class="brand-link">
      <img src="/assets/img/logo.png" alt="ZCSW Logo" class="brand-image opacity-75 shadow" />
      <span class="brand-text fw-light">ZCSW System</span>
    </a>
  </div>
  <!--end::Sidebar Brand-->

  <!--begin::Sidebar Wrapper-->
  <div class="sidebar-wrapper">
    <nav class="mt-2">
      <ul class="nav sidebar-menu flex-column" data-lte-toggle="treeview" role="menu" data-accordion="false">
        
        <!-- Dashboard -->
        <li class="nav-item">
          <a href="/dashboard" class="nav-link">
            <i class="nav-icon bi bi-speedometer2"></i>
            <p>Dashboard</p>
          </a>
        </li>

        <!-- Social Workers -->
        <li class="nav-item">
          <a href="#" class="nav-link">
            <i class="nav-icon bi bi-person-lines-fill"></i>
            <p>
              Social Workers
              <i class="nav-arrow bi bi-chevron-right"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item"><a href="<?=base_url('admin/profiles');?>" class="nav-link"><i class="nav-icon bi bi-circle"></i> <p>All Social Workers</p></a></li>
            <li class="nav-item"><a href="<?=base_url('admin/profiles/create');?>" class="nav-link"><i class="nav-icon bi bi-circle"></i> <p>Register New</p></a></li>
            <li class="nav-item"><a href="/social-workers/pending" class="nav-link"><i class="nav-icon bi bi-circle"></i> <p>Pending Approvals</p></a></li>
          </ul>
        </li>

        <!-- Licensing -->
        <li class="nav-item">
          <a href="#" class="nav-link">
            <i class="nav-icon bi bi-card-checklist"></i>
            <p>
              Licensing
              <i class="nav-arrow bi bi-chevron-right"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item"><a href="/licenses/current" class="nav-link"><i class="nav-icon bi bi-circle"></i> <p>Current Licenses</p></a></li>
            <li class="nav-item"><a href="/licenses/renewals" class="nav-link"><i class="nav-icon bi bi-circle"></i> <p>Renewals</p></a></li>
            <li class="nav-item"><a href="/licenses/history" class="nav-link"><i class="nav-icon bi bi-circle"></i> <p>License History</p></a></li>
          </ul>
        </li>

        <!-- Payments -->
        <li class="nav-item">
          <a href="#" class="nav-link">
            <i class="nav-icon bi bi-cash-coin"></i>
            <p>
              Payments
              <i class="nav-arrow bi bi-chevron-right"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item"><a href="/payments/invoices" class="nav-link"><i class="nav-icon bi bi-circle"></i> <p>Invoices</p></a></li>
            <li class="nav-item"><a href="/payments/receipts" class="nav-link"><i class="nav-icon bi bi-circle"></i> <p>Receipts</p></a></li>
            <li class="nav-item"><a href="/payments/history" class="nav-link"><i class="nav-icon bi bi-circle"></i> <p>Payment History</p></a></li>
          </ul>
        </li>

        <!-- Compliance -->
        <li class="nav-item">
          <a href="#" class="nav-link">
            <i class="nav-icon bi bi-shield-check"></i>
            <p>
              Compliance
              <i class="nav-arrow bi bi-chevron-right"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item"><a href="/compliance/violations" class="nav-link"><i class="nav-icon bi bi-circle"></i> <p>Violations</p></a></li>
            <li class="nav-item"><a href="/compliance/audits" class="nav-link"><i class="nav-icon bi bi-circle"></i> <p>Audit Logs</p></a></li>
          </ul>
        </li>

        <!-- CPD -->
        <li class="nav-item">
          <a href="#" class="nav-link">
            <i class="nav-icon bi bi-award"></i>
            <p>
              CPD (Continuous Dev.)
              <i class="nav-arrow bi bi-chevron-right"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item"><a href="/cpd/programs" class="nav-link"><i class="nav-icon bi bi-circle"></i> <p>Programs</p></a></li>
            <li class="nav-item"><a href="/cpd/submissions" class="nav-link"><i class="nav-icon bi bi-circle"></i> <p>Submissions</p></a></li>
          </ul>
        </li>

        <!-- Reports -->
        <li class="nav-item">
          <a href="/reports" class="nav-link">
            <i class="nav-icon bi bi-bar-chart-fill"></i>
            <p>Reports</p>
          </a>
        </li>

        <!-- User Management -->
        <li class="nav-item">
          <a href="#" class="nav-link">
            <i class="nav-icon bi bi-people-fill"></i>
            <p>
              Users & Roles
              <i class="nav-arrow bi bi-chevron-right"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="<?= base_url('admin/users');?>" class="nav-link">
                <i class="nav-icon bi bi-circle"></i> 
                <p>All Users</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?= base_url('admin/roles')?>" class="nav-link">
                <i class="nav-icon bi bi-circle"></i> 
                <p>Role Management</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?= base_url('admin/permissions')?>" class="nav-link">
                <i class="nav-icon bi bi-circle"></i> 
                <p>Permission Management</p>
              </a>
            </li>
          </ul>
        </li>


        <!-- Settings -->
        <li class="nav-item">
          <a href="<?= base_url('admin/settings');?>" class="nav-link">
            <i class="nav-icon bi bi-gear-fill"></i>
            <p>System Settings</p>
          </a>
        </li>

        <!-- Logout -->
        <li class="nav-item">
          <a href="<?= base_url('logout');?>" class="nav-link">
            <i class="nav-icon bi bi-box-arrow-right"></i>
            <p>Logout</p>
          </a>
        </li>

      </ul>
    </nav>
  </div>
  <!--end::Sidebar Wrapper-->
</aside>
<!--end::Sidebar-->
