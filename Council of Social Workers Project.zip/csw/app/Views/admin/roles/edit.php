<h1><?= esc($title) ?></h1>

<form action="<?= site_url('admin/roles/update/' . $role->id) ?>" method="post">
    <?= csrf_field() ?>

    <div class="mb-3">
        <label for="name" class="form-label">Role Name</label>
        <input type="text" name="name" class="form-control" value="<?= esc(old('name', $role->name)) ?>" required>
    </div>

    <div class="mb-3">
        <label for="description" class="form-label">Description</label>
        <textarea name="description" class="form-control"><?= esc(old('description', $role->description)) ?></textarea>
    </div>

    <div class="mb-3">
        <label class="form-label">Permissions</label>
        <?php
            // Extract assigned permission IDs
            $assignedPermissionIds = array_column($rolePermissions, 'id');

            // Group permissions by category prefix (e.g., 'user' => [...])
            $groupedPermissions = [];
            foreach ($permissions as $perm) {
                $parts = explode('.', $perm->name);
                $group = $parts[0] ?? 'other';
                $groupedPermissions[$group][] = $perm;
            }
        ?>

        <?php foreach ($groupedPermissions as $group => $groupPerms): ?>
            <div class="mb-2 mt-3">
                <strong class="text-uppercase"><?= ucfirst(esc($group)) ?> Permissions</strong>
            </div>
            <?php foreach ($groupPerms as $permission): ?>
                <div class="form-check">
                    <input
                        type="checkbox"
                        name="permissions[]"
                        value="<?= esc($permission->id) ?>"
                        class="form-check-input"
                        id="perm_<?= esc($permission->id) ?>"
                        <?= in_array($permission->id, $assignedPermissionIds) ? 'checked' : '' ?>
                    >
                    <label class="form-check-label" for="perm_<?= esc($permission->id) ?>">
                        <?= esc($permission->name) ?> - <?= esc($permission->description) ?>
                    </label>
                </div>
            <?php endforeach ?>
        <?php endforeach ?>
    </div>

    <button type="submit" class="btn btn-primary">Update Role</button>
</form>
