<h1><?= esc($title) ?></h1>
<?= view('admin/partials/flash') ?>
<a href="<?= site_url('admin/roles/create') ?>" class="btn btn-primary mb-3">Create New Role</a>

<table class="table table-bordered">
    <thead>
        <tr>
            <th>Name</th>
            <th>Description</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($roles as $role): ?>
            <tr>
                <td><?= esc($role->name) ?></td>
                <td><?= esc($role->description) ?></td>
                <td>
                    <a href="<?= site_url('admin/roles/edit/' . $role->id) ?>" class="btn btn-sm btn-warning">Edit</a>
                    <form action="<?= site_url('admin/roles/delete/' . $role->id) ?>" method="post" style="display:inline;" onsubmit="return confirm('Delete this role?');">
                        <?= csrf_field() ?>
                        <button class="btn btn-sm btn-danger">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach ?>
    </tbody>
</table>