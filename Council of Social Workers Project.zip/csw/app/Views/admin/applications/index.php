<h1><?= esc($title) ?></h1>
<?= view('admin/partials/flash') ?>

<a href="<?= site_url('admin/applications/create') ?>" class="btn btn-primary mb-3">Create New Application</a>

<table class="table table-bordered">
    <thead>
        <tr>
            <th>User</th>
            <th>Profile</th>
            <th>Status</th>
            <th>Submitted At</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($applications as $app): ?>
            <tr>
                <td>
                    <?= esc($app['user']->username ?? 'N/A') ?><br>
                    <small><?= esc($app['user']->email ?? 'N/A') ?></small>
                </td>

                <td>
                    <?= esc(($app['profile']['first_name'] ?? '') . ' ' . ($app['profile']['surname'] ?? '')) ?>
                </td>

                <td><span class="badge bg-secondary"><?= esc($app['status'] ?? 'Unknown') ?></span></td>
                <td><?= esc($app['submitted_at'] ?? '-') ?></td>
                <td>
                    <a href="<?= site_url('admin/applications/edit/' . $app['id']) ?>" class="btn btn-sm btn-warning">Edit</a>
                    <a href="<?= site_url('admin/applications/delete/' . $app['id']) ?>" onclick="return confirm('Delete this application?');" class="btn btn-sm btn-danger">Delete</a>
                </td>
            </tr>
        <?php endforeach ?>
    </tbody>
</table>
