<h1><?= esc($title) ?></h1>
<?= view('admin/partials/flash') ?>

<form action="<?= site_url('admin/applications/store') ?>" method="post">
    <?= csrf_field() ?>

    <div class="mb-3">
        <label for="user_id" class="form-label">User</label>
        <select name="user_id" id="user_id" class="form-select" required>
            <option value="">-- Select User --</option>
            <?php foreach ($users as $user): ?>
                <option value="<?= esc($user->id) ?>"><?= esc($user->username) ?> (<?= esc($user->email) ?>)</option>
            <?php endforeach ?>
        </select>
    </div>

    <div class="mb-3">
        <label for="profile_id" class="form-label">Profile</label>
        <select name="profile_id" id="profile_id" class="form-select" required>
            <option value="">-- Select Profile --</option>
            <?php foreach ($profiles as $profile): ?>
                <option value="<?= esc($profile['id']) ?>"><?= esc($profile['first_name'] . ' ' . $profile['surname']) ?></option>
            <?php endforeach ?>
        </select>
    </div>

    <div class="mb-3">
        <label for="status" class="form-label">Status</label>
        <select name="status" id="status" class="form-select" required>
            <option value="draft">Draft</option>
            <option value="submitted">Submitted</option>
            <option value="under_review">Under Review</option>
            <option value="approved">Approved</option>
            <option value="rejected">Rejected</option>
        </select>
    </div>

    <button class="btn btn-success">Save Application</button>
</form>
