<?php
/**
 * Category View
 * @package ZCSW
 */

// Load text helper
helper('text');
?>

<section class="py-5 bg-csw-dark text-white text-center">
    <div class="container">
        <h1 class="display-5 fw-bold"><?= esc(capitalize_text($category['name'])) ?></h1>
        <nav aria-label="breadcrumb" class="breadcrumb-container mb-4">
            <div class="breadcrumb-modern justify-content-center">
                <a href="<?= base_url(); ?>" class="breadcrumb-item text-white">Home</a>
                <span class="breadcrumb-separator text-white">/</span>
                <a href="<?= base_url('updates'); ?>" class="breadcrumb-item text-white">Updates</a>
                <span class="breadcrumb-separator text-white">/</span>
                <span class="breadcrumb-item active text-csw-primary" aria-current="page"><?= esc(capitalize_text($category['name'])) ?></span>
            </div>
        </nav>
        </div>
</section>

<div class="container">
    <div class="row">
        <div class="col-lg-8">
            <!-- Blog Posts Section -->
            <section id="blog-posts" class="blog-posts section">
                <?php if (empty($articles)): ?>
                    <div class="alert alert-info bg-csw-light border-0">
                        <div class="d-flex align-items-center">
                            <i class="bi bi-info-circle-fill text-csw-primary me-2"></i>
                            <span>No articles found in this category.</span>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="row gy-4">
                        <?php foreach ($articles as $article): ?>
                            <div class="col-12">
                                <div class="article-card bg-csw-light border-0 rounded-4 overflow-hidden">
                                    <?php if (!empty($article['image'])): ?>
                                        <img src="<?= base_url('uploads/news/' . esc($article['image'])) ?>" class="card-img-top" alt="<?= esc($article['title']) ?>">
                                    <?php endif; ?>
                                    <div class="card-body">
                                        <h5 class="card-title text-csw-primary"><?= esc(capitalize_text($article['title'])) ?></h5>
                                        <div class="post-meta d-flex gap-3 mb-3">
                                            <?php if (!empty($article['category_name'])): ?>
                                                <span class="badge text-bg-csw-primary"><?= esc(capitalize_text($article['category_name'])) ?></span>
                                            <?php endif; ?>
                                            <span class="text-muted"><?= date('M j, Y', strtotime($article['created_at'])) ?></span>
                                        </div>
                                        <?php if (!empty($article['tags'])): ?>
                                            <div class="tags d-flex flex-wrap gap-2 mb-3">
                                                <?php foreach ($article['tags'] as $tag): ?>
                                                    <a href="<?= base_url('updates/tags/' . esc($tag['slug'])) ?>" class="badge bg-csw-dark text-white">
                                                        <i class="bi bi-tag-fill me-1"></i>
                                                        <?= esc(capitalize_text($tag['name'])) ?>
                                                    </a>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                        <p class="card-text text-muted"><?= esc(substr(strip_tags($article['content']), 0, 200)) ?>...</p>
                                        <a href="<?= base_url('updates/' . esc($article['slug'])) ?>" class="btn btn-csw-primary">Read More</a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </section>
        </div>
        
        <div class="col-lg-4 sidebar">
            <div class="widgets-container">
                <!-- Search Widget -->
                <div class="search-widget widget-item mb-4 p-3 bg-csw-light rounded-4 shadow-sm">
                    <h3 class="widget-title text-csw-primary"><i class="bi bi-search text-csw-primary me-2"></i> Search Updates</h3>
                    <form action="<?= base_url('updates') ?>" method="get" class="d-flex">
                        <input type="text" name="q" value="<?= esc($_GET['q'] ?? '') ?>" class="form-control bg-white me-2" placeholder="Search updates...">
                        <button type="submit" class="btn btn-csw-primary" title="Search">
                            <i class="bi bi-search"></i>
                        </button>
                    </form>
                </div>

                <!-- Categories Widget -->
                <div class="categories-widget widget-item mb-4 p-3 bg-csw-light rounded-4 shadow-sm">
                    <h3 class="widget-title mb-3 text-csw-primary"><i class="bi bi-folder me-2"></i>Categories</h3>
                    <ul class="list-group list-group-flush bg-transparent">
                        <?php if (!empty($categories)) {
                            foreach ($categories as $cat) {
                                echo '<li class="list-group-item d-flex justify-content-between align-items-center">'
                                    . '<span>' . esc(capitalize_text($cat['name'])) . '</span>'
                                    . '<span class="badge bg-csw-primary text-white rounded-pill">' . esc($cat['news_count']) . '</span>'
                                    . '</li>';
                            }
                        } else {
                            echo '<li class="list-group-item">No categories available</li>';
                        } ?>
                    </ul>
                </div>

                <!-- Recent Posts Widget -->
                <div class="recent-posts-widget widget-item mb-4 p-3 bg-csw-light rounded-4 shadow-sm">
                    <h3 class="widget-title mb-3 text-csw-primary"><i class="bi bi-clock-history me-2"></i>Recent Posts</h3>
                    <?php if (!empty($recentPosts)) {
                        echo '<ul class="list-unstyled mb-0">';
                        foreach ($recentPosts as $post) {
                            echo '<li class="mb-3">'
                                 . '<div class="d-flex justify-content-between align-items-start">'
                                 . '<div>'
                                 . '<a class="fw-semibold text-csw-primary hover:text-csw-dark" href="' . base_url('updates/' . esc($post['slug'])) . '">' . esc(capitalize_text($post['title'])) . '</a>'
                                . '<br><small class="text-muted"><i class="bi bi-calendar-event"></i> ' . date('M d, Y', strtotime($post['created_at'])) . '</small>'
                                . '</div>'
                                . '</div>'
                                . '</li>';
                        }
                        echo '</ul>';
                    } else {
                        echo '<div class="text-muted">No recent posts available</div>';
                    } ?>
                </div>

                <!-- Tags Widget -->
                <div class="tags-widget widget-item mb-4 p-3 bg-white rounded shadow-sm">
                    <h3 class="widget-title mb-3 text-csw-primary"><i class="bi bi-tags me-2"></i>Tags</h3>
                    <div class="d-flex flex-wrap gap-2">
                        <?php if (!empty($tags)) {
                            foreach ($tags as $tag) {
                                echo '<span class="badge bg-secondary px-3 py-2">' . esc(capitalize_text($tag['name'])) . '</span>';
                            }
                        } else {
                            echo '<span class="text-muted">No tags available</span>';
                        } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
