<?php
helper('form');
?>

<style>
.no-hover {
    background-color: var(--csw-primary) !important;
    color: white !important;
    border: none !important;
    transition: none !important;
}
.no-hover:hover {
    background-color: var(--csw-primary) !important;
    color: white !important;
    transform: none !important;
}

/* Loading state */
.no-hover.loading {
    opacity: 0.8;
    cursor: not-allowed;
}

/* Success/Error messages */
.alert {
    border-radius: 0.375rem;
    padding: 1rem;
    margin-bottom: 1rem;
}

.alert .bi {
    font-size: 1.25rem;
}

/* Form validation */
.form-control.is-invalid {
    border-color: #dc3545;
    padding-right: calc(1.5em + 0.75rem);
    background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 12 12' width='12' height='12' fill='none' stroke='%23dc3545'%3e%3ccircle cx='6' cy='6' r='4.5'/%3e%3cpath stroke-linejoin='round' d='M5.8 3.6h.4L6 6.5z'/%3e%3ccircle cx='6' cy='8.2' r='.6' fill='%23dc3545' stroke='none'/%3e%3c/svg%3e");
    background-repeat: no-repeat;
    background-position: right calc(0.375em + 0.1875rem) center;
    background-size: calc(0.75em + 0.375rem) calc(0.75em + 0.375rem);
}

.invalid-feedback {
    display: block;
    margin-top: 0.25rem;
    color: #dc3545;
}
</style>

<section class="py-5 bg-csw-dark text-white text-center">
</br>
  <div class="container">
    <h1 class="display-5 fw-bold">Contact</h1>
    <nav aria-label="breadcrumb" class="breadcrumb-container mb-4">
      <div class="breadcrumb-modern justify-content-center">
        <a href="<?= base_url(); ?>" class="breadcrumb-item text-white">Home</a>
        <span class="breadcrumb-separator text-white">/</span>
        <span class="breadcrumb-item active text-csw-primary" aria-current="page">Contact</span>
      </div>
    </nav>
    <p class="lead">Contact Us</p>
  </div>
</section>

<!-- Contact Section -->
<section id="contact" class="contact section">
  <div class="container position-relative" data-aos="fade-up" data-aos-delay="100">
    <div class="row gy-4 justify-content-center">
      <div class="col-lg-5">
        <?php // Contact info is now provided by the controller as $contact ?>
        <div class="info-item d-flex" data-aos="fade-up" data-aos-delay="200">
          <i class="bi bi-geo-alt flex-shrink-0"></i>
          <div>
            <h3>Address</h3>
            <p><?= esc($contact['address'] ?? '') ?></p>
          </div>
        </div><!-- End Info Item -->
        <div class="info-item d-flex" data-aos="fade-up" data-aos-delay="300">
          <i class="bi bi-telephone flex-shrink-0"></i>
          <div class="ps-2">
            <h3>Call Us</h3>
            <?php 
              $phones = [];
              if (!empty($contact['phone'])) {
                if (is_array($contact['phone'])) {
                  $phones = $contact['phone'];
                } else {
                  $phones = array_map('trim', explode(',', $contact['phone']));
                }
              }
            ?>
            <?php foreach ($phones as $idx => $phone): ?>
              <span class="d-inline-block" style="margin-right:8px; margin-bottom:2px;"> <?= esc($phone) ?> </span>
            <?php endforeach; ?>
          </div>
        </div><!-- End Info Item -->
        <div class="info-item d-flex" data-aos="fade-up" data-aos-delay="400">
          <i class="bi bi-envelope flex-shrink-0"></i>
          <div>
            <h3>Email Us</h3>
            <p><?= esc($contact['email'] ?? '') ?></p>
          </div>
        </div><!-- End Info Item -->
      </div>
      <div class="col-lg-7">
        <div class="card shadow-sm">
          <div class="card-body">
            <h5 class="mb-3">Send Us a Message</h5>
            
            <!-- Success Message -->
            <?php if (session()->has('success')): ?>
                <div class="alert alert-success bg-csw-light border-0">
                    <div class="d-flex align-items-center">
                        <i class="bi bi-check-circle-fill text-csw-primary me-2"></i>
                        <span><?= esc(session()->get('success')) ?></span>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Error Message -->
            <?php if (session()->has('error')): ?>
                <div class="alert alert-danger bg-csw-light border-0">
                    <div class="d-flex align-items-center">
                        <i class="bi bi-exclamation-circle-fill text-danger me-2"></i>
                        <span><?= esc(session()->get('error')) ?></span>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Form Validation Errors -->
            <?php if (session()->has('validation')): ?>
                <div class="alert alert-danger bg-csw-light border-0">
                    <div class="d-flex align-items-center">
                        <i class="bi bi-exclamation-circle-fill text-danger me-2"></i>
                        <div>
                            <h6 class="mb-0">Please fix the following errors:</h6>
                            <ul class="mb-0">
                                <?php foreach (session()->get('validation') as $error): ?>
                                    <li><?= esc($error) ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <?= form_open('contact', ['id' => 'contactForm', 'class' => 'php-email-form']) ?>
              <div class="row">
                <div class="col-md-6 form-group">
                  <label for="name" class="form-label">Name *</label>
                  <input type="text" 
                         name="name" 
                         class="form-control <?= session()->has('errors.name') ? 'is-invalid' : '' ?>" 
                         id="name" 
                         placeholder="Your Name" 
                         required
                         value="<?= old('name') ?>">
                  <?php if (session()->has('errors.name')): ?>
                    <div class="invalid-feedback">
                      <?= session()->get('errors.name') ?>
                    </div>
                  <?php endif; ?>
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                  <label for="email" class="form-label">Email *</label>
                  <input type="email" 
                         class="form-control <?= session()->has('errors.email') ? 'is-invalid' : '' ?>" 
                         name="email" 
                         id="email" 
                         placeholder="Your Email" 
                         required
                         value="<?= old('email') ?>">
                  <?php if (session()->has('errors.email')): ?>
                    <div class="invalid-feedback">
                      <?= session()->get('errors.email') ?>
                    </div>
                  <?php endif; ?>
                </div>
              </div>
              <div class="form-group mt-3">
                <label for="subject" class="form-label">Subject *</label>
                <input type="text" 
                       class="form-control <?= session()->has('errors.subject') ? 'is-invalid' : '' ?>" 
                       name="subject" 
                       id="subject" 
                       placeholder="Subject" 
                       required
                       value="<?= old('subject') ?>">
                <?php if (session()->has('errors.subject')): ?>
                  <div class="invalid-feedback">
                    <?= session()->get('errors.subject') ?>
                  </div>
                <?php endif; ?>
              </div>
              <div class="form-group mt-3">
                <label for="message" class="form-label">Message *</label>
                <textarea class="form-control <?= session()->has('errors.message') ? 'is-invalid' : '' ?>" 
                          name="message" 
                          id="message" 
                          rows="5" 
                          placeholder="Message" 
                          required
                          ><?= old('message') ?></textarea>
                <?php if (session()->has('errors.message')): ?>
                  <div class="invalid-feedback">
                    <?= session()->get('errors.message') ?>
                  </div>
                <?php endif; ?>
              </div>
              <div class="text-center mt-3">
                <button type="submit" class="btn btn-csw-primary no-hover" id="submitBtn">
                    <span id="submitText">Send Message</span>
                    <span id="loadingSpinner" class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
                </button>
              </div>
            <?= form_close() ?>
          </div>
        </div>
      </div><!-- End Contact Form -->

    </div>

  </div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('contactForm');
    const submitBtn = document.getElementById('submitBtn');
    const submitText = document.getElementById('submitText');
    const loadingSpinner = document.getElementById('loadingSpinner');

    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Show loading state
        submitBtn.classList.add('loading');
        submitText.style.display = 'none';
        loadingSpinner.classList.remove('d-none');
        
        // Submit the form
        form.submit();
    });

    // Handle form reset
    form.addEventListener('reset', function() {
        submitBtn.classList.remove('loading');
        submitText.style.display = 'inline';
        loadingSpinner.classList.add('d-none');
    });

    // Handle form error
    window.addEventListener('error', function() {
        submitBtn.classList.remove('loading');
        submitText.style.display = 'inline';
        loadingSpinner.classList.add('d-none');
    });
});
</script>

</section><!-- /Contact Section -->
