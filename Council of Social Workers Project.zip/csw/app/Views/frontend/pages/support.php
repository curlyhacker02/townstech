<!-- Hero Section Modernized -->
<section class="py-5 bg-csw-dark text-white text-center position-relative">
  <div class="container position-relative z-2">
    <h1 class="display-4 fw-bold mb-2">Help & Support</h1>
    <nav aria-label="breadcrumb" class="breadcrumb-container mb-4">
      <div class="breadcrumb-modern justify-content-center">
        <a href="<?= base_url(); ?>" class="breadcrumb-item text-white">Home</a>
        <span class="breadcrumb-separator text-white">/</span>
        <span class="breadcrumb-item active text-csw-primary" aria-current="page">Support</span>
      </div>
    </nav>
    <p class="lead mb-0">Find answers to common questions or contact us for assistance.</p>
  </div>
  <div class="bg-overlay position-absolute top-0 start-0 w-100 h-100" style="background: linear-gradient(90deg, #1a2233 60%, rgba(26,34,51,0.7) 100%); opacity: 0.7;"></div>
</section>

<main class="py-5">
  <div class="container">
    <div class="row g-5">
      <!-- FAQ Section Modernized -->
      <div class="col-lg-8">
        <div class="bg-white rounded-4 shadow-sm p-4 mb-4">
          <h2 class="mb-4 fw-bold text-csw-primary">Frequently Asked Questions</h2>
          <div class="accordion accordion-flush" id="faqAccordion">
            <?php if (!empty($faqs)): ?>
              <?php foreach ($faqs as $index => $faq): ?>
                <?php
                  // Auto-capitalize question and answer
                  $question = isset($faq['question']) ? ucwords(strtolower($faq['question'])) : '';
                  $answer = isset($faq['answer']) ? ucfirst($faq['answer']) : '';
                ?>
                <div class="accordion-item rounded-3 mb-2 border-0 shadow-sm">
                  <h2 class="accordion-header" id="faq<?= $index ?>">
                    <button class="accordion-button <?= $index !== 0 ? 'collapsed' : '' ?> fw-semibold" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?= $index ?>">
                      <i class="bi bi-question-circle-fill text-csw-primary me-2"></i> <?= esc($question) ?>
                    </button>
                  </h2>
                  <div id="collapse<?= $index ?>" class="accordion-collapse collapse <?= $index === 0 ? 'show' : '' ?>" data-bs-parent="#faqAccordion">
                    <div class="accordion-body fs-6 text-muted">
                      <?= esc($answer) ?>
                    </div>
                  </div>
                </div>
              <?php endforeach; ?>
            <?php else: ?>
              <div class="alert alert-info">No FAQs available at this time.</div>
            <?php endif; ?>
          </div>
        </div>
      </div>
      <!-- Sidebar Modernized -->
      <div class="col-lg-4">
        <div class="card shadow-sm border-0 rounded-4 mb-4">
          <div class="card-body">
            <h5 class="card-title fw-bold text-csw-primary mb-3">Need More Help?</h5>
            <ul class="list-unstyled mb-0">
              <li class="mb-2"><i class="bi bi-envelope-fill text-csw-primary me-2"></i> <span class="fw-semibold">Email:</span> <a href="mailto:support@zcsw.org.zw" class="text-csw-primary">support@zcsw.org.zw</a></li>
              <li class="mb-2"><i class="bi bi-phone-fill text-csw-primary me-2"></i> <span class="fw-semibold">Call:</span> <a href="tel:+263712345678" class="text-csw-primary">+263 712 345 678</a></li>
              <li><i class="bi bi-clock-fill text-csw-primary me-2"></i> <span class="fw-semibold">Mon–Fri:</span> 8:00am – 4:30pm</li>
            </ul>
          </div>
        </div>
        <div class="card shadow-sm border-0 rounded-4">
          <div class="card-body">
            <h5 class="card-title fw-bold text-csw-primary mb-3">Quick Links</h5>
            <ul class="list-group list-group-flush">
              <li class="list-group-item bg-transparent border-0 px-0"><a href="<?= site_url('updates'); ?>" class="text-csw-primary fw-semibold"><i class="bi bi-newspaper me-2"></i>Updates</a></li>
              <li class="list-group-item bg-transparent border-0 px-0"><a href="<?= site_url('downloads'); ?>" class="text-csw-primary fw-semibold"><i class="bi bi-download me-2"></i>Downloads</a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</main>
