<!-- Simple Login Page Placeholder -->
<section class="py-5 bg-csw-dark text-white text-center">
  <div class="container">
    <h1 class="display-5 fw-bold">Login</h1>
    <p class="lead">This is a placeholder for the login page. Integrate your authentication system here.</p>
  </div>
</section>
