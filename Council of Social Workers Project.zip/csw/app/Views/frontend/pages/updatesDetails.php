
<section class="py-5 bg-csw-dark text-white text-center position-relative">
  <div class="container position-relative z-2">
    <h1 class="display-4 fw-bold mb-2"><?= esc(capitalize_text('Updates')) ?></h1>
    <nav aria-label="breadcrumb" class="breadcrumb-container mb-4">
      <ol class="breadcrumb justify-content-center">
        <li class="breadcrumb-item"><a href="<?= base_url(); ?>" class="text-white">Home</a></li>
        <span class="breadcrumb-separator text-white">/</span>
        <li class="breadcrumb-item"><a href="<?= base_url('updates'); ?>" class="text-white">Updates</a></li>
        <span class="breadcrumb-separator text-white">/</span>
        <li class="breadcrumb-item active text-csw-primary" aria-current="page"><?= esc($article['title']) ?></li>
      </ol>
    </nav>
  </div>
  <div class="bg-overlay position-absolute top-0 start-0 w-100 h-100" style="background: linear-gradient(90deg, #1a2233 60%, rgba(26,34,51,0.7) 100%); opacity: 0.7;"></div>
</section>

    <!-- Main Content -->
    <div class="container py-5">
        <div class="row g-4">
            <div class="col-lg-8">
                <!-- Blog Details Section -->
                <section id="blog-details" class="blog-details section">
                    <div class="post-item">
                        <?php if (!empty($article['image'])): ?>
                            <img src="<?= base_url('uploads/news/' . esc($article['image'])) ?>" alt="<?= esc($article['title']) ?>" class="img-fluid mb-4">
                        <?php endif; ?>
                        <h2 class="title"><?= esc(capitalize_text($article['title'])) ?></h2>
                        <div class="meta-top mb-4">
                            <ul class="list-unstyled d-flex gap-3">
                                <li class="d-flex align-items-center">
                                    <i class="bi bi-person text-csw-primary me-2"></i>
                                    <span><?= esc(capitalize_text($article['author_name'] ?? $article['author'])) ?></span>
                                </li>
                                <li class="d-flex align-items-center">
                                    <i class="bi bi-clock text-csw-primary me-2"></i>
                                    <span><time datetime="<?= esc($article['created_at'] ?? $article['date']) ?>"><?= date('M j, Y', strtotime($article['created_at'] ?? $article['date'])) ?></time></span>
                                </li>
                            </ul>
                        </div>
                        <div class="meta-bottom mb-4">
                            <i class="bi bi-folder text-csw-primary me-2"></i>
                            <?php if (!empty($article['category_name'])): ?>
                                <a href="#" class="badge bg-csw-primary text-white"><?= esc(capitalize_text($article['category_name'])) ?></a>
                            <?php endif; ?>
                            <i class="bi bi-tags text-csw-primary me-2"></i>
                            <div class="tags d-flex flex-wrap gap-2">
                                <?php foreach ($tags as $tag): ?>
                                    <a href="<?= site_url('news/tags/' . esc($tag['slug'])) ?>" class="badge bg-csw-primary text-white">
                                        <i class="bi bi-tag-fill me-1"></i>
                                        <?= esc(capitalize_text($tag['name'])) ?>
                                    </a>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <div class="content">
                            <?= $article['content'] ?>
                        </div>
                    </div>
                </section>

                <!-- Related Posts Section -->
                <section id="related-posts" class="related-posts section mt-5">
                    <h3 class="section-title mb-4">Related Updates</h3>
                    <div class="row g-4">
                        <?php foreach ($relatedArticles as $related): ?>
                            <div class="col-md-6">
                                <div class="article-card">
                                    <?php if (!empty($related['image'])): ?>
                                        <img src="<?= base_url('uploads/news/' . esc($related['image'])) ?>" alt="<?= esc($related['title']) ?>" class="card-img-top">
                                    <?php endif; ?>
                                    <div class="card-body">
                                        <h4 class="card-title"><?= esc(capitalize_text($related['title'])) ?></h4>
                                        <p class="card-text"><?= esc(substr(strip_tags($related['content']), 0, 100)) ?>...</p>
                                        <a href="<?= base_url('updates/' . esc($related['slug'])) ?>" class="btn btn-csw-primary btn-sm">Read More</a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </section>

                <!-- Blog Comments Section -->
                <section id="blog-comments" class="blog-comments section mt-5">
                    <div class="container">
                        <h4 class="comments-count text-csw-primary"><?= count($comments) ?> Comments</h4>
                        <?php foreach ($comments as $i => $comment): ?>
                            <div id="comment-<?= $i+1 ?>" class="comment mb-4">
                                <div class="d-flex">
                                    <div class="comment-img">
                                        <img src="<?= esc($comment['photo'] ?? 'assets/img/blog/comments-1.jpg') ?>" alt="" class="rounded-circle">
                                    </div>
                                    <div>
                                        <h5 class="mb-1"><?= esc(capitalize_text($comment['name'])) ?></h5>
                                        <time datetime="<?= esc($comment['created_at'] ?? '2025-01-01') ?>" class="text-muted mb-2"><?= date('d M, Y', strtotime($comment['created_at'] ?? '2025-01-01')) ?></time>
                                        <p class="mb-0"><?= esc($comment['comment']) ?></p>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </section>

                <!-- Comment Form Section -->
                <?php if ($isLoggedIn): ?>
                <section id="comment-form" class="comment-form section mt-5">
                    <div class="container">
                        <h3 class="section-title mb-4">Leave a Comment</h3>
                        <form action="<?= site_url('comments/add/' . $article['id']) ?>" method="post" class="row g-3">
                            <div class="col-md-6">
                                <input type="text" name="name" class="form-control" placeholder="Your Name*" required>
                            </div>
                            <div class="col-md-6">
                                <input type="email" name="email" class="form-control" placeholder="Your Email*" required>
                            </div>
                            <div class="col-12">
                                <textarea name="comment" class="form-control" rows="5" placeholder="Your Comment*" required></textarea>
                            </div>
                            <div class="col-12">
                                <button type="submit" class="btn btn-csw-primary">Post Comment</button>
                            </div>
                        </form>
                    </div>
                </section>
                <?php else: ?>
                <section class="login-required section mt-5">
                    <div class="container">
                        <div class="alert alert-info text-center">
                            <p>Please <a href="<?= site_url('login') ?>" class="alert-link">login</a> to leave a comment.</p>
                        </div>
                    </div>
                </section>
                <?php endif; ?>
            </div>

            <div class="col-lg-4 sidebar">
                <div class="widgets-container">
                    <!-- Search Widget -->
                    <div class="search-widget widget-item mb-4">
                        <h3 class="widget-title"><i class="bi bi-search"></i> <?= esc(capitalize_text('Search Updates')) ?></h3>
                        <form action="<?= site_url('updates') ?>" method="get" class="d-flex">
                            <input type="text" name="q" value="<?= esc($_GET['q'] ?? '') ?>" class="form-control me-2" placeholder="Search updates...">
                            <button type="submit" class="btn btn-primary" title="Search">
                                <i class="bi bi-search"></i>
                            </button>
                        </form>
                    </div>

                    <!-- Categories Widget -->
                    <div class="categories-widget widget-item mb-4">
                        <h3 class="widget-title"><i class="bi bi-folder"></i> Categories</h3>
                        <ul class="mt-3">
                            <?php foreach ($categories as $category): ?>
                                <li>
                                    <a href="<?= site_url('news/category/' . esc($category['id'])) ?>" class="d-flex align-items-center">
                                        <i class="bi bi-folder-fill me-2"></i>
                                        <?= esc(capitalize_text($category['name'])) ?>
                                        <span class="ms-auto text-csw-primary fw-bold"><?= esc($category['news_count']) ?></span>
                                    </a>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>

                    <!-- Recent Posts Widget -->
                    <div class="recent-posts-widget widget-item mb-4">
                        <h3 class="widget-title"><i class="bi bi-clock"></i> Recent Updates</h3>
                        <ul class="mt-3">
                            <?php foreach ($recentPostsWidget as $post): ?>
                                <li>
                                    <a href="<?= site_url('news/' . esc($post['slug'])) ?>" class="d-flex align-items-center">
                                        <?php if (!empty($post['image'])): ?>
                                            <img src="<?= base_url('uploads/news/' . esc($post['image'])) ?>" alt="" class="flex-shrink-0 rounded" style="width: 60px; height: 60px; object-fit: cover;">
                                        <?php endif; ?>
                                        <div class="ms-3">
                                            <h6 class="mb-1"><?= esc(capitalize_text($post['title'])) ?></h6>
                                            <small class="text-muted"><?= date('M j, Y', strtotime($post['created_at'])) ?></small>
                                        </div>
                                    </a>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>

                    <!-- Tags Widget -->
                    <div class="tags-widget widget-item mb-4">
                        <h3 class="widget-title"><i class="bi bi-tags"></i> Tags</h3>
                        <div class="d-flex flex-wrap gap-2 mt-3">
                            <?php foreach ($tags as $tag): ?>
                                <a href="<?= site_url('news/tags/' . esc($tag['slug'])) ?>" class="badge bg-secondary">
                                    <i class="bi bi-tag-fill me-1"></i>
                                    <?= esc(capitalize_text($tag['name'])) ?>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- Author Widget -->
                    <div class="author-widget widget-item mb-4">
                        <h3 class="widget-title"><i class="bi bi-person"></i> About the Author</h3>
                        <div class="d-flex align-items-center mt-3">
                            <img src="<?= esc($author['photo']) ?>" alt="Author" class="rounded-circle me-3" style="width: 60px; height: 60px;">
                            <div>
                                <h5 class="mb-1"><?= esc(capitalize_text($author['name'])) ?></h5>
                                <p class="mb-0"><?= esc($author['bio']) ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-
?>
