<!-- Simple Register Page Placeholder -->
<section class="py-5 bg-csw-dark text-white text-center">
  <div class="container">
    <h1 class="display-5 fw-bold">Register</h1>
    <p class="lead">This is a placeholder for the registration page. Integrate your registration system here.</p>
  </div>
</section>
