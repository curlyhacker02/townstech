<!-- Hero/About Banner -->
<section class="py-5 bg-csw-dark text-white text-center position-relative pt-5">
  <div class="container position-relative z-2">
    <h1 class="display-4 fw-bold mb-2">About Us</h1>
    <nav aria-label="breadcrumb" class="breadcrumb-container mb-4">
      <div class="breadcrumb-modern justify-content-center">
        <a href="<?= base_url(); ?>" class="breadcrumb-item text-white">Home</a>
        <span class="breadcrumb-separator text-white">/</span>
        <span class="breadcrumb-item active text-csw-primary" aria-current="page">About</span>
      </div>
    </nav>
    </div>
  <div class="bg-overlay position-absolute top-0 start-0 w-100 h-100" style="background: linear-gradient(90deg, #1a2233 60%, rgba(26,34,51,0.7) 100%); opacity: 0.7;"></div>
</section>

<!-- About Section Modern Layout -->
<section id="about" class="about section py-5">
  <div class="container">
    <div class="row align-items-center g-5">
      <div class="col-lg-6 order-lg-2" data-aos="fade-left">
        <img src="/csw/public/assets/img/csw/image1.jpg" class="img-fluid rounded-4 shadow-lg" alt="About ZCSW">
      </div>
      <div class="col-lg-6 order-lg-1" data-aos="fade-right">
        <div class="content bg-white rounded-4 shadow-sm p-4">
          <h3 class="fw-bold text-csw-primary mb-3">Who We Are</h3>
          <p class="mb-4 fs-5 text-muted"><?= esc($about['who_we_are']) ?></p>
          <h4 class="fw-semibold text-csw-dark mb-3">Our Work</h4>
          <ul class="list-unstyled mb-0">
            <?php if (!empty($about['our_work'])): ?>
              <?php foreach (array_filter(array_map('trim', explode(',', $about['our_work']))) as $statement): ?>
                <li class="mb-2">
                  <i class="bi bi-check-circle-fill text-csw-primary me-2"></i>
                  <?= esc($statement) ?>
                </li>
              <?php endforeach; ?>
            <?php else: ?>
              <li class="mb-2 text-muted">No work statements available.</li>
            <?php endif; ?>
          </ul>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Why Us Section Modern Layout -->
<section id="why-us" class="why-us section py-5 bg-light">
  <div class="container">
    <div class="row align-items-center g-5">
      <div class="col-xl-5 img-bg" data-aos="zoom-in-up" data-aos-delay="100">
        <img src="/csw/public/assets/img/csw/image2.jpg" class="img-fluid rounded-4 shadow-lg" alt="Why Choose ZCSW">
      </div>
      <div class="col-xl-7 slides position-relative d-flex align-items-center" data-aos="flip-left" data-aos-delay="200">
        <div class="swiper init-swiper w-100 bg-white rounded-4 shadow-sm p-4" style="min-height:400px; min-width: 370px;">
          <script type="application/json" class="swiper-config">
            {
              "loop": true,
              "speed": 600,
              "autoplay": {
                "delay": 5000
              },
              "slidesPerView": "auto",
              "centeredSlides": true,
              "pagination": {
                "el": ".swiper-pagination",
                "type": "bullets",
                "clickable": true
              },
              "navigation": {
                "nextEl": ".swiper-button-next",
                "prevEl": ".swiper-button-prev"
              }
            }
          </script>
          <div class="swiper-wrapper">
            <?php foreach ($whyUsSlides as $slide): ?>
            <div class="swiper-slide">
              <div class="item px-3 py-4 text-center">
                <h3 class="mb-3 text-csw-primary fw-bold fs-4"><?= esc($slide['title']) ?></h3>
                <p class="fs-5 text-muted mb-0 lh-lg"><?= esc($slide['content']) ?></p>
              </div>
            </div>
            <?php endforeach; ?>
          </div>
          <div class="swiper-pagination mt-3"></div>
        </div>
        <div class="swiper-button-prev"></div>
        <div class="swiper-button-next"></div>
      </div>
    </div>
  </div>
</section>

<!-- Call To Action Section Modern -->
<section id="call-to-action" class="call-to-action section dark-background py-5 position-relative overflow-hidden">
  <img src="/csw/public/assets/img/csw/image4.jpg" alt="" class="position-absolute top-0 start-0 w-100 h-100 object-fit-cover" style="z-index:0; opacity:0.45;">
  <div class="container position-relative z-2">
    <div class="row justify-content-center align-items-center min-vh-40" data-aos="zoom-in" data-aos-delay="100">
      <div class="col-xl-10">
        <div class="text-center py-5 px-3">
          <h3 class="display-5 fw-bold mb-3 text-csw-primary text-shadow">Be Part Of The Family</h3>
          <p class="lead mb-4 text-white text-shadow">Council of Social Workers is the regulatory board for the Social Work Profession in Zimbabwe established in terms of the Social Workers Act 27:21.</p>
          <a class="cta-btn btn btn-lg btn-csw-primary rounded-pill px-5 shadow" href="registration.html">Register Today</a>
        </div>
      </div>
    </div>
  </div>
</section>
