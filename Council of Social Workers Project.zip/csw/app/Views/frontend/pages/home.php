<?php
// Fetch articles for hero and news section from the same source as updates page
// Controller should pass $articles (latest 5 or as needed) from the same query as updates page

// Auto-capitalize all article titles for swiper and cards
if (!empty($articles)) {
    foreach ($articles as &$article) {
        if (isset($article['title'])) {
            $article['title'] = ucwords(strtolower($article['title']));
        }
    }
    unset($article);
}
?>

<!-- Hero Section with Side Carousel -->
<section id="hero" class="hero section dark-background" style="background: linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), url('assets/img/csw/image4.jpg') center center / cover no-repeat; min-height: 80vh;">
  <div class="container d-flex align-items-center justify-content-start h-100">
    <div class="row align-items-center g-5 g-lg-0">
      <!-- Welcome Content Column -->
      <div class="col-lg-6 mb-4 mb-lg-0" data-aos="fade-up" data-aos-delay="100">
        <div class="hero-content-wrapper">
          <h1 class="display-4 fw-bold text-white mb-3">Welcome to ZCSW</h1>
          <p class="lead mb-4 text-white fs-lg">The Zimbabwe Council for Social Workers is the premier professional body supporting social work practitioners across the nation.</p>
          <div class="d-flex gap-3">
            <a href="<?= base_url('about'); ?>" class="btn btn-primary btn-lg d-flex align-items-center gap-2">
              <i class="bi bi-info-circle"></i> Learn More
            </a>
            <a href="<?= base_url('login'); ?>" class="btn btn-outline-light btn-lg d-flex align-items-center gap-2">
              <i class="bi bi-box-arrow-in-right"></i> Login
            </a>
          </div>
        </div>
      </div>
      
      <!-- Recent Articles Carousel Column -->
      <div class="col-lg-6">
        <div class="card bg-transparent border-0 shadow-none rounded-3 overflow-visible">
          <div class="card-body p-0">
            <div id="heroPostsCarousel" class="carousel slide" data-bs-ride="carousel">
              <div class="carousel-inner">
                <?php if (!empty($articles)) {
                  foreach ($articles as $index => $article) {
                    $activeClass = $index === 0 ? 'active' : '';
                ?>
                <div class="carousel-item <?= $activeClass ?>">
                  <div class="p-4 bg-white bg-opacity-75 rounded-4 shadow position-relative" style="min-height: 220px;">
                    <div class="d-flex align-items-center mb-2">
                      <small class="text-muted me-2"><i class="bi bi-calendar-event"></i> <?= isset($article['created_at']) ? date('M d, Y', strtotime($article['created_at'])) : '' ?></small>
                    </div>
                    <h5 class="card-title mb-2 fw-bold text-csw-primary"> <?= esc($article['title']) ?> </h5>
                    <p class="card-text small text-muted mb-3"> <?= isset($article['content']) ? esc(substr(strip_tags($article['content']), 0, 100)) . '...' : '' ?> </p>
                    <a href="<?= site_url('updates') ?>" class="btn btn-link text-csw-primary px-0 position-absolute end-0 bottom-0 m-3">View All News <i class="bi bi-arrow-right"></i></a>
                  </div>
                </div>
                <?php }
                } else { ?>
                <div class="carousel-item active">
                  <div class="p-4 text-center bg-white bg-opacity-75 rounded-4 shadow">
                    <i class="bi bi-newspaper display-6 text-muted mb-3"></i>
                    <p class="text-muted">No recent articles available</p>
                    <a href="<?= site_url('updates') ?>" class="btn btn-csw-primary btn-sm rounded-pill">View News</a>
                  </div>
                </div>
                <?php } ?>
              </div>
             
            </div>
          </div>
      
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Features Section -->
<section class="py-5">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="fw-bold">Why Join Council of Social Workers?</h2>
            <p class="lead text-muted">Discover the benefits of being part of our professional community</p>
        </div>
        
        <div class="row g-4">
            <div class="col-md-4 text-center">
                <div class="feature-icon">
                    <i class="bi bi-people-fill"></i>
                </div>
                <h3>Professional Network</h3>
                <p>Connect with fellow social workers across Zimbabwe and share knowledge, experiences, and best practices.</p>
            </div>
            
            <div class="col-md-4 text-center">
                <div class="feature-icon">
                    <i class="bi bi-book-half"></i>
                </div>
                <h3>Resources Library</h3>
                <p>Access a comprehensive collection of research papers, case studies, and professional development materials.</p>
            </div>
            
            <div class="col-md-4 text-center">
                <div class="feature-icon">
                    <i class="bi bi-award-fill"></i>
                </div>
                <h3>Continuing Education</h3>
                <p>Participate in workshops, webinars, and training programs to maintain and enhance your professional skills.</p>
            </div>
        </div>
    </div>
</section>
  

      <!-- CTA Section -->
     <section id="call-to-action" class="call-to-action section dark-background">

      <img src="assets/img/csw/image4.jpg" alt="">

      <div class="container">
        <div class="row justify-content-center" data-aos="zoom-in" data-aos-delay="100">
          <div class="col-xl-10">
            <div class="text-center">
              <h3>Be Part Of The Family</h3>
              <p>Council of Social Workers is the regulatory board for the Social Work Profession in Zimbabwe established in terms of the Social Workers Act 27:21.</p>
              <a class="cta-btn" href="register">Register Today</a>
            </div>
          </div>
        </div>
      </div>

    </section>


    <!-- Testimonials -->
    <section class="py-5">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="fw-bold"><?= esc(ucwords('What Our Members Say')) ?></h2>
                <p class="lead text-muted"><?= esc(ucwords('Hear from social workers who are part of our community')) ?></p>
            </div>
            <div class="row g-4">
                <?php foreach ($testimonials as $testimonial): ?>
                <div class="col-md-4">
                    <div class="card h-100 shadow-sm">
                        <div class="card-body">
                            <div class="testimonial-card">
                                <p class="fst-italic"><?= esc($testimonial['message'] ?? 'No testimonial message available') ?></p>
                                <div class="d-flex align-items-center mt-3">
                                    <img src="<?= esc($testimonial['photo'] ?? 'https://via.placeholder.com/50') ?>" alt="Testimonial" class="rounded-circle me-3">
                                    <div>
                                        <h6 class="mb-0"><?= esc(ucwords($testimonial['name'] ?? 'Anonymous')) ?></h6>
                                        <small class="text-muted"><?= esc(ucwords($testimonial['role'] ?? 'Social Worker')) ?></small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php if (empty($testimonials)): ?>
            <div class="text-center mt-4">
                <p class="text-muted">No testimonials available at this time</p>
            </div>
            <?php endif; ?>
        </div>
    </section>
            </div>
            <div class="row justify-content-center mt-5">
                <?php if (session()->get('isLoggedIn')): ?>
                <div class="col-md-8">
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <!-- Testimonial Submission Form -->
                            <h2>Submit Your Testimonial</h2>
                            <?php if (session('errors')): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php foreach (session('errors') as $error): ?>
                                            <li><?= esc($error) ?></li>
                                        <?php endforeach ?>
                                    </ul>
                                </div>
                            <?php endif ?>
                            <?php if (session('success')): ?>
                                <div class="alert alert-success">
                                    <?= esc(session('success')) ?>
                                </div>
                            <?php endif ?>
                            <form action="<?= site_url('testimonials/submit') ?>" method="post" enctype="multipart/form-data">
                                <?= csrf_field() ?>

                                <div class="mb-3">
                                    <label for="name" class="form-label">Your Name</label>
                                    <input type="text" class="form-control" id="name" name="name" required>
                                </div>

                                <div class="mb-3">
                                    <label for="role" class="form-label">Your Role</label>
                                    <input type="text" class="form-control" id="role" name="role" required>
                                </div>

                                <div class="mb-3">
                                    <label for="photo" class="form-label">Upload Your Photo</label>
                                    <input type="file" class="form-control" id="photo" name="photo" accept="image/*" required>
                                </div>

                                <div class="mb-3">
                                    <label for="message" class="form-label">Your Testimonial</label>
                                    <textarea class="form-control" id="message" name="message" rows="4" required></textarea>
                                </div>

                                <button type="submit" class="btn btn-primary">Submit Testimonial</button>
                            </form>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- News/Updates Section -->
    <section class="py-5 bg-light">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="fw-bold">Latest News & Updates</h2>
                <p class="lead text-muted">Stay informed about important developments in social work</p>
            </div>
            <div class="row row-cols-1 row-cols-md-2 row-cols-lg-4 g-4">
                <?php if (!empty($articles)) {
                    foreach ($articles as $article) { ?>
                        <div class="col">
                            <div class="card h-100 border-0 shadow rounded-4 overflow-hidden bg-white" style="min-height: 420px;">
                                <?php if (!empty($article['image'])): ?>
                                    <img src="<?= base_url('uploads/news/' . esc($article['image'])) ?>" class="card-img-top object-fit-cover" style="height: 240px; object-fit: cover;" alt="<?= esc($article['title']) ?>">
                                <?php else: ?>
                                    <img src="<?= base_url('assets/img/csw/ballot-1294935_1920.png') ?>" class="card-img-top object-fit-cover" style="height: 240px; object-fit: cover;" alt="Placeholder image">
                                <?php endif; ?>
                                <div class="card-body d-flex flex-column justify-content-between">
                                    <h5 class="card-title fw-bold text-csw-primary mb-2"><?= esc($article['title']) ?></h5>
                                    <div class="mb-2 small text-muted">
                                        <i class="bi bi-calendar-event"></i> <?= isset($article['created_at']) ? date('M d, Y', strtotime($article['created_at'])) : '' ?>
                                    </div>
                                    <a href="<?= site_url('updates') ?>" class="btn btn-csw-primary btn-sm rounded-pill mt-auto align-self-start">Read More <i class="bi bi-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                <?php }
                } else { ?>
                    <div class="col-12 text-center text-muted py-5">
                        <p>No recent articles available</p>
                    </div>
                <?php } ?>
            </div>
             </div>
    </section>


