<?php
// Load text helper
helper('text');

// Use data from controller
$search = $search ?? '';
$downloads = $downloads ?? [];
$categories = $categories ?? [];
$groupedDownloads = $groupedDownloads ?? [];

// Group filtered downloads by category name
if (!empty($downloads)) {
    foreach ($downloads as $doc) {
        $cat = $doc['category'] ?? 'Other';
        $groupedDownloads[$cat][] = $doc;
    }
}
?>

<!-- Downloads Section -->
<section class="py-5 bg-csw-dark text-white text-center">
    <div class="container">
        <h1 class="display-5 fw-bold"><?= esc(ucwords('Downloads')) ?></h1>
        <nav aria-label="breadcrumb" class="breadcrumb-container mb-4">
            <div class="breadcrumb-modern justify-content-center">
                <a href="<?= base_url(); ?>" class="breadcrumb-item text-white">Home</a>
                <span class="breadcrumb-separator text-white">/</span>
                <span class="breadcrumb-item active text-csw-primary" aria-current="page">Downloads</span>
            </div>
        </nav>
        <p class="lead">Access important documents and resources related to the Zimbabwe Council of Social Workers.</p>
        <form method="get" class="my-4">
            <div class="input-group input-group-lg justify-content-center">
                <input type="text" name="q" class="form-control w-50" placeholder="Search for a document..." value="<?= esc($search) ?>">
                <button class="btn btn-primary" type="submit"><i class="bi bi-search"></i> Search</button>
            </div>
        </form>
    </div>
</section>

<section class="section downloads-section">
    <div class="container">
        <div class="row">
            <?php if (!empty($categories)): ?>
                <?php foreach ($categories as $cat): ?>
                    <?php $docs = $groupedDownloads[$cat['name']] ?? []; ?>
                    <div class="col-lg-6 mb-5" id="<?= strtolower(esc($cat['name'])) ?>">
                        <h2 class="section-title"><?= esc(ucwords($cat['name'])) ?></h2>
                        <ul class="list-group">
                            <?php if (!empty($docs)): ?>
                                <?php foreach ($docs as $doc): ?>
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        <div>
                                            <strong><?= esc(ucwords($doc['title'])) ?></strong>
                                            <?php if (!empty($doc['description'])): ?>
                                                <br><small class="text-muted"><?= esc(ucwords($doc['description'])) ?></small>
                                            <?php endif; ?>
                                        </div>
                                        <?php if (!empty($doc['url'])): ?>
                                            <a href="<?= esc($doc['url']) ?>" class="btn btn-csw-primary btn-sm" download>
                                                <i class="bi bi-download"></i> Download
                                            </a>
                                        <?php else: ?>
                                            <span class="text-muted">File not available</span>
                                        <?php endif; ?>
                                    </li>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <li class="list-group-item text-center text-muted">No downloads available in this category.</li>
                            <?php endif; ?>
                        </ul>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="col-12">
                    <div class="alert alert-info text-center">
                        No download categories available.
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>
    </div>
  </div>
</section>