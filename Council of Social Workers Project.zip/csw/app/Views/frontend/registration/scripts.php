<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

<script>
  const totalSteps = 10;
  let currentStep = 1;

  const BASE_URL = <?= json_encode(base_url('/')) ?>;

  $(document).ready(function () {
    updateProgress();
    showStep(currentStep);

    $('#nextBtn').on('click', function (event) {
      event.preventDefault();

      // Show the current step first (if not already visible)
      showStep(currentStep);

      // Add a short delay to let DOM update
      setTimeout(() => {
        submitStep(currentStep, { moveNext: true, isFinalSubmit: false });
      }, 50);
    });

    $('#prevBtn').on('click', function () {
      if (currentStep > 1) {
        currentStep--;
        showStep(currentStep);
        updateProgress();
      }
    });

    $('.step-sidebar-item').on('click', function () {
      const step = parseInt($(this).data('step'));
      currentStep = step;
      showStep(currentStep);
      updateProgress();
    });

    $('#confirmReviewed').on('change', function () {
      $('#submitApplicationBtn').prop('disabled', !this.checked);
    });

    $('#saveDraftBtn').on('click', function (event) {
      event.preventDefault();
      submitStep(currentStep, { moveNext: false, isFinalSubmit: false });
    });

    $('#submitApplicationBtn').on('click', function (event) {
      event.preventDefault();
      if (!$('#confirmReviewed').is(':checked')) {
        alert('You must confirm the declaration before submitting.');
        return;
      }
      submitStep(currentStep, { moveNext: false, isFinalSubmit: true });
    });

    function showStep(step) {
      $('.step').removeClass('active').hide();
      $(`.step[data-step="${step}"]`).addClass('active').fadeIn(200);

      $('.step-sidebar-item').removeClass('active');
      $(`.step-sidebar-item[data-step="${step}"]`).addClass('active');

      if (step === totalSteps) {
        $('#nextBtn').hide();
      } else {
        $('#nextBtn').show();
      }
    }

    function updateProgress() {
      const percent = (currentStep / totalSteps) * 100;
      $('#progressBar').css('width', percent + '%');
      $('#progressBar .progress-bar-label').text(`Step ${currentStep} of ${totalSteps}`);
    }

    function submitStep(step, options = { moveNext: true, isFinalSubmit: false }) {
      let data;
      let contentType = 'application/x-www-form-urlencoded; charset=UTF-8';
      let processData = true;

      if (step === 9) {
        const formData = new FormData();

        const appId = $('#application_id').val();
        if (appId) formData.append('application_id', appId);

        // File input names, one file per category
        const fileInputNames = [
          'identity_document',
          'academic_certificates',
          'professional_qualifications',
          'character_references',
          'employer_endorsements',
          'private_practice_docs'
        ];

        let hasAnyFile = false;
        const removedCategories = [];

        // Collect removed categories from Remove buttons marked as removed
        $('.remove-existing-file').each(function () {
          if ($(this).data('removed')) {
            removedCategories.push($(this).data('category'));
          }
        });

        fileInputNames.forEach(name => {
          const input = document.querySelector(`input[name="${name}"]`);
          const inputVisible = input && input.offsetParent !== null;

          if (inputVisible && input.files.length > 0) {
            // Append only the first file for each category
            formData.append(name, input.files[0]);
            hasAnyFile = true;
          } else {
            // No new file selected, but if existing file NOT removed, count as existing present
            if (!removedCategories.includes(name)) {
              hasAnyFile = true;
            }
          }
        });

        if (!hasAnyFile) {
          alert('Please upload at least one document or keep an existing one.');
          return;
        }

        // Append removed categories info for server to delete
        removedCategories.forEach(cat => {
          formData.append('remove_files[]', cat);
        });

        if (options.isFinalSubmit) formData.append('final_submit', 'true');

        data = formData;
        contentType = false;
        processData = false;
      } else {
        const formDataArray = $(`.step[data-step="${step}"] :input`).serializeArray();
        data = {};
        formDataArray.forEach(({ name, value }) => {
          data[name] = value;
        });

        const appId = $('#application_id').val();
        if (appId) data['application_id'] = appId;
        if (options.isFinalSubmit) data['final_submit'] = true;
      }

      const endpoint = `${BASE_URL}registration/step${step}`;

      $.ajax({
        url: endpoint,
        method: 'POST',
        data: data,
        contentType: contentType,
        processData: processData,
        success: function (res) {
          if (res.application_id) {
            $('#application_id').val(res.application_id);
          }

          if (options.isFinalSubmit) {
            alert('🎉 Application submitted successfully!');
          } else if (!options.moveNext) {
            alert('📝 Draft saved successfully.');
          } else if (currentStep < totalSteps) {
            currentStep++;
            showStep(currentStep);
            updateProgress();
          }
        },
        error: function (xhr) {
          try {
            const response = JSON.parse(xhr.responseText);
            const errors = response.errors || {};
            let message = 'Please fix the following:\n';

            for (const key in errors) {
              message += `- ${errors[key]}\n`;
            }

            if (message === 'Please fix the following:\n') {
              message += '- Unknown error. Please check your inputs.';
            }

            alert(message);
          } catch (e) {
            console.error("AJAX error:", xhr.responseText);
            alert('An unexpected error occurred. Please check the console or contact support.');
          }
        }
      });
    }
  });

  // Handle Remove existing file button click for step 9
  $(document).on('click', '.remove-existing-file', function () {
    const $btn = $(this);
    const category = $btn.data('category');

    // Hide existing file link and remove button itself
    $btn.closest('div.mb-3').find('a').hide();
    $btn.data('removed', true).hide();

    // Show file input for user to upload replacement
    const input = $(`input[name="${category}"]`);
    if (input.length) {
      input.show();
    }
  });

  // Additional UI interactions
  document.addEventListener('DOMContentLoaded', function () {
    // Step 7 Disciplinary details toggle
    const disciplinaryYes = document.getElementById('disciplinaryYes');
    const disciplinaryNo = document.getElementById('disciplinaryNo');
    const detailsWrapper = document.getElementById('disciplinaryDetailsWrapper');

    function toggleDisciplinaryDetails() {
      if (disciplinaryYes && disciplinaryYes.checked) {
        detailsWrapper.style.display = 'block';
      } else {
        detailsWrapper.style.display = 'none';
      }
    }

    if (disciplinaryYes && disciplinaryNo && detailsWrapper) {
      toggleDisciplinaryDetails();
      disciplinaryYes.addEventListener('change', toggleDisciplinaryDetails);
      disciplinaryNo.addEventListener('change', toggleDisciplinaryDetails);
    }

    // Step 8 Private practice toggle
    const practicedYes = document.getElementById('practicedYes');
    const practicedNo = document.getElementById('practicedNo');
    const detailsSection = document.getElementById('privatePracticeDetails');

    function togglePracticeDetails() {
      if (practicedYes && practicedYes.checked) {
        detailsSection.style.display = 'block';
      } else {
        detailsSection.style.display = 'none';
      }
    }

    if (practicedYes && practicedNo && detailsSection) {
      togglePracticeDetails();
      practicedYes.addEventListener('change', togglePracticeDetails);
      practicedNo.addEventListener('change', togglePracticeDetails);
    }

    // Step 8 Practice form toggle (extra)
    const yesRadio = document.getElementById('practiceYes');
    const noRadio = document.getElementById('practiceNo');
    const formSection = document.getElementById('practiceDetailsForm');

    function togglePracticeForm() {
      if (yesRadio && yesRadio.checked) {
        formSection.style.display = 'block';
      } else {
        formSection.style.display = 'none';
      }
    }

    if (yesRadio && noRadio && formSection) {
      togglePracticeForm();
      yesRadio.addEventListener('change', togglePracticeForm);
      noRadio.addEventListener('change', togglePracticeForm);
    }
  });

  // Education repeater
  $(document).on('click', '#addEducationEntry', function () {
    const $original = $('.education-entry').first();
    const $clone = $original.clone();
    $clone.find('input, textarea').val('');
    $clone.find('.remove-education-entry').removeClass('d-none');
    $('#educationRepeater').append($clone);
  });

  $(document).on('click', '.remove-education-entry', function () {
    $(this).closest('.education-entry').remove();
  });

  // Toggle fields with Yes/No radios
  $(document).on('change', '.toggle-details', function () {
    const target = $(this).data('target');
    if ($(this).val() === 'Yes') {
      $(target).slideDown();
    } else {
      $(target).slideUp().find('textarea').val('');
    }
  });
</script>
