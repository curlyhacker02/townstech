<section class="py-5 bg-csw-dark text-white text-center">
  <div class="container">
    <br/>
    <br/>
    <h1 class="display-5 fw-bold"><?= esc($profile['first_name'] . ' ' . $profile['surname']) ?></h1>
    <p class="lead">Application as a Social Worker</p>
  </div>
</section>

<title><?= esc($title) ?></title>
<body class="bg-light">

<div class="container py-5">
  <div class="row">
    <!-- Sidebar: Step Navigation -->
    <div class="col-md-3 mb-4">
      <div class="card shadow-sm">
        <div class="card-body p-3">
          <h5 class="mb-3">Steps</h5>
          <ul class="list-group list-group-flush" id="stepSidebar">
            <?php for ($i = 1; $i <= 10; $i++): ?>
              <li class="list-group-item step-sidebar-item <?= $i === 1 ? 'active' : '' ?>" data-step="<?= $i ?>">
                Step <?= $i ?>
              </li>
            <?php endfor; ?>
          </ul>
        </div>
      </div>
    </div>

    <!-- Main Content -->
    <div class="col-md-9">
      <h2 class="mb-4">Registration Wizard</h2>

      <!-- Progress Bar -->
      <div class="progress mb-4">
        <div class="progress-bar" role="progressbar" style="width: 10%;" id="progressBar">
          <span class="progress-bar-label">Step 1 of 10</span>
        </div>
      </div>

      <!-- Step Form -->
      <form id="registrationForm">
        <input type="hidden" name="application_id" id="application_id" value="<?= esc($application_id) ?>">

        <div id="stepsContainer">
          <?= $this->include('frontend/registration/steps/step1') ?>
          <?= $this->include('frontend/registration/steps/step2') ?>
          <?= $this->include('frontend/registration/steps/step3') ?>
          <?= $this->include('frontend/registration/steps/step4') ?>
          <?= $this->include('frontend/registration/steps/step5') ?>
          <?= $this->include('frontend/registration/steps/step6') ?>
          <?= $this->include('frontend/registration/steps/step7') ?>
          <?= $this->include('frontend/registration/steps/step8') ?>
          <?= $this->include('frontend/registration/steps/step9') ?>
          <?= $this->include('frontend/registration/steps/step10') ?>
        </div>

        <div class="d-flex justify-content-between mt-4">
          <button type="button" class="btn btn-secondary" id="prevBtn">Previous</button>
          <button type="button" class="btn btn-primary" id="nextBtn">Next</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- External JS -->
<?= $this->include('frontend/registration/scripts') ?>
