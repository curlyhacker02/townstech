<div class="step" data-step="10" style="display: none;">
  <div class="card mb-3">
    <div class="card-header bg-csw-primary text-white">
      <strong><i class="bi bi-eye-fill me-2"></i>Step 10: Review & Submit Application</strong>
    </div>
    <div class="card-body">
      <p class="mb-3">Please carefully review the summary of your application before submission. You can go back and edit any section if needed.</p>

      <div class="accordion" id="applicationReviewAccordion">
        <?php foreach (range(1, 9) as $step): ?>
          <div class="accordion-item">
            <h2 class="accordion-header" id="heading<?= $step ?>">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?= $step ?>" aria-expanded="false" aria-controls="collapse<?= $step ?>">
                Step <?= $step ?> Summary
              </button>
            </h2>
            <div id="collapse<?= $step ?>" class="accordion-collapse collapse" aria-labelledby="heading<?= $step ?>" data-bs-parent="#applicationReviewAccordion">
              <div class="accordion-body">
                <div id="review-step-<?= $step ?>">
                  <em>Loading summary...</em>
                </div>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>

      <div class="form-check mt-4">
        <input class="form-check-input" type="checkbox" name="confirm_reviewed" id="confirmReviewed">
        <label class="form-check-label fw-bold" for="confirmReviewed">
          I confirm that I have reviewed all the information and documents, and I declare that everything provided is true and correct.
        </label>
      </div>

      <div class="d-flex justify-content-between mt-4">
        <button type="button" id="saveDraftBtn" class="btn btn-secondary">
          <i class="bi bi-save2 me-2"></i>Save Draft
        </button>

        <button type="button" id="submitApplicationBtn" class="btn btn-success" disabled>
          <i class="bi bi-send-check-fill me-2"></i>Submit Application
        </button>
      </div>
    </div>
  </div>
</div>
