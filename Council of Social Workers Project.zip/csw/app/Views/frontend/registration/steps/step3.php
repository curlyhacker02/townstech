<div class="step" data-step="3" style="display: none;">
  <div class="card mb-3">
    <div class="card-header bg-csw-primary text-white">
      <strong><i class="bi bi-mortarboard me-2"></i>Step 3: Education and Training</strong>
    </div>
    <div class="card-body">
      <div id="educationRepeater">

        <?php if (!empty($step3Data) && is_array($step3Data)): ?>
          <?php foreach ($step3Data as $index => $education): ?>
            <div class="education-entry border rounded p-3 mb-3 bg-light" data-index="<?= $index ?>">
              <h6 class="fw-bold">Education Entry</h6>
              <div class="row">
                <div class="col-md-6 mb-3">
                  <label class="form-label fw-bold">1. Title of your training</label>
                  <input type="text" name="education_training[<?= $index ?>][training_title]" class="form-control" required
                    value="<?= htmlspecialchars($education['training_title'] ?? '') ?>">
                </div>
                <div class="col-md-3 mb-3">
                  <label class="form-label fw-bold">2. Start Date</label>
                  <input type="date" name="education_training[<?= $index ?>][start_date]" class="form-control" required
                    value="<?= htmlspecialchars($education['start_date'] ?? '') ?>">
                </div>
                <div class="col-md-3 mb-3">
                  <label class="form-label fw-bold">3. End Date</label>
                  <input type="date" name="education_training[<?= $index ?>][end_date]" class="form-control" required
                    value="<?= htmlspecialchars($education['end_date'] ?? '') ?>">
                </div>
                <div class="col-md-6 mb-3">
                  <label class="form-label fw-bold">4. Name of Provider</label>
                  <input type="text" name="education_training[<?= $index ?>][provider_name]" class="form-control" required
                    value="<?= htmlspecialchars($education['provider_name'] ?? '') ?>">
                </div>
                <div class="col-md-6 mb-3">
                  <label class="form-label fw-bold">5. Street Name</label>
                  <input type="text" name="education_training[<?= $index ?>][street_name]" class="form-control"
                    value="<?= htmlspecialchars($education['street_name'] ?? '') ?>">
                </div>
                <div class="col-md-4 mb-3">
                  <label class="form-label fw-bold">6. Town/City</label>
                  <input type="text" name="education_training[<?= $index ?>][town_city]" class="form-control"
                    value="<?= htmlspecialchars($education['town_city'] ?? '') ?>">
                </div>
                <div class="col-md-4 mb-3">
                  <label class="form-label fw-bold">7. Country</label>
                  <input type="text" name="education_training[<?= $index ?>][country]" class="form-control"
                    value="<?= htmlspecialchars($education['country'] ?? '') ?>">
                </div>
                <div class="col-md-12 mt-3">
                  <label class="form-label fw-bold">8. Course Administrator Details</label>
                </div>
                <div class="col-md-6 mb-3">
                  <label class="form-label">Name</label>
                  <input type="text" name="education_training[<?= $index ?>][course_admin_name]" class="form-control"
                    value="<?= htmlspecialchars($education['course_admin_name'] ?? '') ?>">
                </div>
                <div class="col-md-6 mb-3">
                  <label class="form-label">Job Title</label>
                  <input type="text" name="education_training[<?= $index ?>][course_admin_job_title]" class="form-control"
                    value="<?= htmlspecialchars($education['course_admin_job_title'] ?? '') ?>">
                </div>
                <div class="col-md-6 mb-3">
                  <label class="form-label">Telephone</label>
                  <input type="text" name="education_training[<?= $index ?>][course_admin_phone]" class="form-control"
                    value="<?= htmlspecialchars($education['course_admin_phone'] ?? '') ?>">
                </div>
                <div class="col-md-6 mb-3">
                  <label class="form-label">Email</label>
                  <input type="email" name="education_training[<?= $index ?>][course_admin_email]" class="form-control"
                    value="<?= htmlspecialchars($education['course_admin_email'] ?? '') ?>">
                </div>
                <div class="col-md-12 mb-3">
                  <label class="form-label fw-bold">9. More Details (optional)</label>
                  <textarea name="education_training[<?= $index ?>][more_details]" class="form-control" rows="3"><?= htmlspecialchars($education['more_details'] ?? '') ?></textarea>
                </div>
              </div>
              <div class="text-end">
                <button type="button" class="btn btn-danger btn-sm remove-education-entry <?= $index === 0 ? 'd-none' : '' ?>">
                  <i class="bi bi-x-circle"></i> Remove
                </button>
              </div>
            </div>
          <?php endforeach; ?>
        <?php else: ?>
          <!-- No data - show one empty template -->
          <div class="education-entry border rounded p-3 mb-3 bg-light" data-index="0">
            <h6 class="fw-bold">Education Entry</h6>
            <div class="row">
              <div class="col-md-6 mb-3">
                <label class="form-label fw-bold">1. Title of your training</label>
                <input type="text" name="education_training[0][training_title]" class="form-control" required>
              </div>
              <div class="col-md-3 mb-3">
                <label class="form-label fw-bold">2. Start Date</label>
                <input type="date" name="education_training[0][start_date]" class="form-control" required>
              </div>
              <div class="col-md-3 mb-3">
                <label class="form-label fw-bold">3. End Date</label>
                <input type="date" name="education_training[0][end_date]" class="form-control" required>
              </div>
              <div class="col-md-6 mb-3">
                <label class="form-label fw-bold">4. Name of Provider</label>
                <input type="text" name="education_training[0][provider_name]" class="form-control" required>
              </div>
              <div class="col-md-6 mb-3">
                <label class="form-label fw-bold">5. Street Name</label>
                <input type="text" name="education_training[0][street_name]" class="form-control">
              </div>
              <div class="col-md-4 mb-3">
                <label class="form-label fw-bold">6. Town/City</label>
                <input type="text" name="education_training[0][town_city]" class="form-control">
              </div>
              <div class="col-md-4 mb-3">
                <label class="form-label fw-bold">7. Country</label>
                <input type="text" name="education_training[0][country]" class="form-control">
              </div>
              <div class="col-md-12 mt-3">
                <label class="form-label fw-bold">8. Course Administrator Details</label>
              </div>
              <div class="col-md-6 mb-3">
                <label class="form-label">Name</label>
                <input type="text" name="education_training[0][course_admin_name]" class="form-control">
              </div>
              <div class="col-md-6 mb-3">
                <label class="form-label">Job Title</label>
                <input type="text" name="education_training[0][course_admin_job_title]" class="form-control">
              </div>
              <div class="col-md-6 mb-3">
                <label class="form-label">Telephone</label>
                <input type="text" name="education_training[0][course_admin_phone]" class="form-control">
              </div>
              <div class="col-md-6 mb-3">
                <label class="form-label">Email</label>
                <input type="email" name="education_training[0][course_admin_email]" class="form-control">
              </div>
              <div class="col-md-12 mb-3">
                <label class="form-label fw-bold">9. More Details (optional)</label>
                <textarea name="education_training[0][more_details]" class="form-control" rows="3"></textarea>
              </div>
            </div>
            <div class="text-end">
              <button type="button" class="btn btn-danger btn-sm remove-education-entry d-none">
                <i class="bi bi-x-circle"></i> Remove
              </button>
            </div>
          </div>
        <?php endif; ?>

      </div>

      <div class="text-end mt-3">
        <button type="button" class="btn btn-outline-primary" id="addEducationEntry">
          <i class="bi bi-plus-circle me-1"></i> Add Another Education
        </button>
      </div>
    </div>
  </div>
</div>
