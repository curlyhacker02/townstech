<div class="step" data-step="4" style="display: none;">
  <div class="card mb-3">
    <div class="card-header bg-csw-primary text-white">
      <strong><i class="bi bi-briefcase me-2"></i>Step 4: Work Details in the Past 5 Years</strong>
    </div>
    <div class="card-body">
      <div id="workRepeater">

        <?php if (!empty($step4Data) && is_array($step4Data)): ?>
          <?php foreach ($step4Data as $index => $work): ?>
            <div class="work-entry border rounded p-3 mb-3 bg-light" data-index="<?= $index ?>">
              <h6 class="fw-bold">Work Experience Entry</h6>
              <div class="row">
                <div class="col-md-6 mb-3">
                  <label class="form-label fw-bold">1. Organization</label>
                  <input type="text" name="work_experience[<?= $index ?>][organization]" class="form-control" required
                    value="<?= htmlspecialchars($work['organization'] ?? '') ?>">
                </div>
                <div class="col-md-3 mb-3">
                  <label class="form-label fw-bold">2. Start Date</label>
                  <input type="date" name="work_experience[<?= $index ?>][start_date]" class="form-control" required
                    value="<?= htmlspecialchars($work['start_date'] ?? '') ?>">
                </div>
                <div class="col-md-3 mb-3">
                  <label class="form-label fw-bold">3. End Date</label>
                  <input type="date" name="work_experience[<?= $index ?>][end_date]" class="form-control" required
                    value="<?= htmlspecialchars($work['end_date'] ?? '') ?>">
                </div>
                <div class="col-md-6 mb-3">
                  <label class="form-label fw-bold">4. Post</label>
                  <input type="text" name="work_experience[<?= $index ?>][post]" class="form-control" required
                    value="<?= htmlspecialchars($work['post'] ?? '') ?>">
                </div>
                <div class="col-md-6 mb-3">
                  <label class="form-label fw-bold">5. Street Name</label>
                  <input type="text" name="work_experience[<?= $index ?>][street_name]" class="form-control"
                    value="<?= htmlspecialchars($work['street_name'] ?? '') ?>">
                </div>
                <div class="col-md-4 mb-3">
                  <label class="form-label fw-bold">6. Town/City</label>
                  <input type="text" name="work_experience[<?= $index ?>][town_city]" class="form-control"
                    value="<?= htmlspecialchars($work['town_city'] ?? '') ?>">
                </div>
                <div class="col-md-4 mb-3">
                  <label class="form-label fw-bold">7. Country</label>
                  <input type="text" name="work_experience[<?= $index ?>][country]" class="form-control"
                    value="<?= htmlspecialchars($work['country'] ?? '') ?>">
                </div>
                <div class="col-md-12 mt-3">
                  <label class="form-label fw-bold">8. Manager Details</label>
                </div>
                <div class="col-md-6 mb-3">
                  <label class="form-label">Name</label>
                  <input type="text" name="work_experience[<?= $index ?>][manager_name]" class="form-control"
                    value="<?= htmlspecialchars($work['manager_name'] ?? '') ?>">
                </div>
                <div class="col-md-6 mb-3">
                  <label class="form-label">Contact Number</label>
                  <input type="text" name="work_experience[<?= $index ?>][manager_contact]" class="form-control"
                    value="<?= htmlspecialchars($work['manager_contact'] ?? '') ?>">
                </div>
                <div class="col-md-6 mb-3">
                  <label class="form-label">Email Address</label>
                  <input type="email" name="work_experience[<?= $index ?>][manager_email]" class="form-control"
                    value="<?= htmlspecialchars($work['manager_email'] ?? '') ?>">
                </div>
              </div>
              <div class="text-end">
                <button type="button" class="btn btn-danger btn-sm remove-work-entry <?= $index === 0 ? 'd-none' : '' ?>">
                  <i class="bi bi-x-circle"></i> Remove
                </button>
              </div>
            </div>
          <?php endforeach; ?>
        <?php else: ?>
          <!-- No data - show one empty template -->
          <div class="work-entry border rounded p-3 mb-3 bg-light" data-index="0">
            <h6 class="fw-bold">Work Experience Entry</h6>
            <div class="row">
              <div class="col-md-6 mb-3">
                <label class="form-label fw-bold">1. Organization</label>
                <input type="text" name="work_experience[0][organization]" class="form-control" required>
              </div>
              <div class="col-md-3 mb-3">
                <label class="form-label fw-bold">2. Start Date</label>
                <input type="date" name="work_experience[0][start_date]" class="form-control" required>
              </div>
              <div class="col-md-3 mb-3">
                <label class="form-label fw-bold">3. End Date</label>
                <input type="date" name="work_experience[0][end_date]" class="form-control" required>
              </div>
              <div class="col-md-6 mb-3">
                <label class="form-label fw-bold">4. Post</label>
                <input type="text" name="work_experience[0][post]" class="form-control" required>
              </div>
              <div class="col-md-6 mb-3">
                <label class="form-label fw-bold">5. Street Name</label>
                <input type="text" name="work_experience[0][street_name]" class="form-control">
              </div>
              <div class="col-md-4 mb-3">
                <label class="form-label fw-bold">6. Town/City</label>
                <input type="text" name="work_experience[0][town_city]" class="form-control">
              </div>
              <div class="col-md-4 mb-3">
                <label class="form-label fw-bold">7. Country</label>
                <input type="text" name="work_experience[0][country]" class="form-control">
              </div>
              <div class="col-md-12 mt-3">
                <label class="form-label fw-bold">8. Manager Details</label>
              </div>
              <div class="col-md-6 mb-3">
                <label class="form-label">Name</label>
                <input type="text" name="work_experience[0][manager_name]" class="form-control">
              </div>
              <div class="col-md-6 mb-3">
                <label class="form-label">Contact Number</label>
                <input type="text" name="work_experience[0][manager_contact]" class="form-control">
              </div>
              <div class="col-md-6 mb-3">
                <label class="form-label">Email Address</label>
                <input type="email" name="work_experience[0][manager_email]" class="form-control">
              </div>
            </div>
            <div class="text-end">
              <button type="button" class="btn btn-danger btn-sm remove-work-entry d-none">
                <i class="bi bi-x-circle"></i> Remove
              </button>
            </div>
          </div>
        <?php endif; ?>

      </div>

      <div class="text-end mt-3">
        <button type="button" class="btn btn-outline-primary" id="addWorkEntry">
          <i class="bi bi-plus-circle me-1"></i> Add Another Work Entry
        </button>
      </div>
    </div>
  </div>
</div>
