<div class="step" data-step="7" style="display: none;">
  <div class="card mb-3">
    <div class="card-header bg-csw-primary text-white">
      <strong><i class="bi bi-globe-americas me-2"></i>Step 7: Practice Outside Zimbabwe</strong>
    </div>
    <div class="card-body">

      <!-- Did you practice outside Zimbabwe? -->
      <div class="mb-3">
        <label class="form-label fw-bold">Have you practiced social work outside Zimbabwe?</label>
        <div class="form-check form-check-inline">
          <input class="form-check-input" type="radio" name="did_you_practice" id="practiceYes" value="yes" required
            <?= (isset($step7Data['did_you_practice']) && $step7Data['did_you_practice'] === 'yes') ? 'checked' : '' ?>>
          <label class="form-check-label" for="practiceYes">Yes</label>
        </div>
        <div class="form-check form-check-inline">
          <input class="form-check-input" type="radio" name="did_you_practice" id="practiceNo" value="no" required
            <?= (!isset($step7Data['did_you_practice']) || $step7Data['did_you_practice'] === 'no') ? 'checked' : '' ?>>
          <label class="form-check-label" for="practiceNo">No</label>
        </div>
      </div>

      <!-- Conditional Form Content -->
      <div id="practiceDetailsForm" style="display: <?= (isset($step7Data['did_you_practice']) && $step7Data['did_you_practice'] === 'yes') ? 'block' : 'none' ?>;">

        <!-- Practice Details -->
        <div class="row">
          <div class="col-md-6 mb-3">
            <label class="form-label fw-bold">1. Country of Practice</label>
            <input type="text" name="country_of_practice" class="form-control" required
              value="<?= htmlspecialchars($step7Data['country_of_practice'] ?? '') ?>">
          </div>

          <div class="col-md-6 mb-3">
            <label class="form-label fw-bold">2. Regulatory Body</label>
            <input type="text" name="regulatory_body" class="form-control" required
              value="<?= htmlspecialchars($step7Data['regulatory_body'] ?? '') ?>">
          </div>

          <div class="col-md-6 mb-3">
            <label class="form-label fw-bold">3. Registration Number</label>
            <input type="text" name="registration_no" class="form-control" required
              value="<?= htmlspecialchars($step7Data['registration_no'] ?? '') ?>">
          </div>

          <div class="col-md-6 mb-3">
            <label class="form-label fw-bold">4. Organization</label>
            <input type="text" name="organization" class="form-control" required
              value="<?= htmlspecialchars($step7Data['organization'] ?? '') ?>">
          </div>

          <div class="col-md-3 mb-3">
            <label class="form-label fw-bold">5. Start Date</label>
            <input type="date" name="start_date" class="form-control" required
              value="<?= htmlspecialchars($step7Data['start_date'] ?? '') ?>">
          </div>

          <div class="col-md-3 mb-3">
            <label class="form-label fw-bold">6. End Date</label>
            <input type="date" name="end_date" class="form-control" required
              value="<?= htmlspecialchars($step7Data['end_date'] ?? '') ?>">
          </div>

          <div class="col-md-6 mb-3">
            <label class="form-label fw-bold">7. Post</label>
            <input type="text" name="post" class="form-control" required
              value="<?= htmlspecialchars($step7Data['post'] ?? '') ?>">
          </div>

          <div class="col-md-6 mb-3">
            <label class="form-label fw-bold">8. Street Name</label>
            <input type="text" name="street_name" class="form-control"
              value="<?= htmlspecialchars($step7Data['street_name'] ?? '') ?>">
          </div>

          <div class="col-md-4 mb-3">
            <label class="form-label fw-bold">9. Town/City</label>
            <input type="text" name="town_city" class="form-control"
              value="<?= htmlspecialchars($step7Data['town_city'] ?? '') ?>">
          </div>

          <div class="col-md-4 mb-3">
            <label class="form-label fw-bold">10. Country</label>
            <input type="text" name="country" class="form-control"
              value="<?= htmlspecialchars($step7Data['country'] ?? '') ?>">
          </div>
        </div>

        <!-- Manager Details -->
        <h6 class="fw-bold mt-4">Manager Information</h6>
        <div class="row">
          <div class="col-md-6 mb-3">
            <label class="form-label">11. Name of Manager</label>
            <input type="text" name="manager_name" class="form-control"
              value="<?= htmlspecialchars($step7Data['manager_name'] ?? '') ?>">
          </div>

          <div class="col-md-6 mb-3">
            <label class="form-label">12. Contact Number</label>
            <input type="text" name="manager_contact" class="form-control"
              value="<?= htmlspecialchars($step7Data['manager_contact'] ?? '') ?>">
          </div>

          <div class="col-md-6 mb-3">
            <label class="form-label">13. Email Address</label>
            <input type="email" name="manager_email" class="form-control"
              value="<?= htmlspecialchars($step7Data['manager_email'] ?? '') ?>">
          </div>
        </div>

        <!-- Disciplinary Section -->
        <h6 class="fw-bold mt-4">Disciplinary Record</h6>
        <div class="mb-3">
          <label class="form-label">14. Have you ever faced any disciplinary action by a professional or regulatory body or your employer?</label>
          <div class="form-check">
            <input class="form-check-input" type="radio" name="faced_disciplinary_action" value="yes" id="disciplinaryYes"
              <?= (isset($step7Data['faced_disciplinary_action']) && $step7Data['faced_disciplinary_action'] === 'yes') ? 'checked' : '' ?>>
            <label class="form-check-label" for="disciplinaryYes">Yes</label>
          </div>
          <div class="form-check">
            <input class="form-check-input" type="radio" name="faced_disciplinary_action" value="no" id="disciplinaryNo"
              <?= (!isset($step7Data['faced_disciplinary_action']) || $step7Data['faced_disciplinary_action'] === 'no') ? 'checked' : '' ?>>
            <label class="form-check-label" for="disciplinaryNo">No</label>
          </div>
        </div>

        <div class="mb-3" id="disciplinaryDetailsWrapper" style="display: <?= (isset($step7Data['faced_disciplinary_action']) && $step7Data['faced_disciplinary_action'] === 'yes') ? 'block' : 'none' ?>;">
          <label class="form-label">If yes, provide details:</label>
          <textarea name="disciplinary_details" class="form-control" rows="3"><?= htmlspecialchars($step7Data['disciplinary_details'] ?? '') ?></textarea>
        </div>

        <!-- Certification -->
        <h6 class="fw-bold mt-4">Certification</h6>
        <p>I certify that the facts set out above are to the best of my knowledge and belief true and correct.</p>

        <div class="row">
          <div class="col-md-4 mb-3">
            <label class="form-label fw-bold">Date</label>
            <input type="date" name="certification_date" class="form-control" required
              value="<?= htmlspecialchars($step7Data['certification_date'] ?? '') ?>">
          </div>

          <div class="col-md-8 mb-3">
            <label class="form-label fw-bold">Signature</label>
            <input type="text" name="certification_signature" class="form-control" required
              value="<?= htmlspecialchars($step7Data['certification_signature'] ?? '') ?>">
          </div>
        </div>

      </div> <!-- End Conditional Form Content -->

    </div>
  </div>
</div>
