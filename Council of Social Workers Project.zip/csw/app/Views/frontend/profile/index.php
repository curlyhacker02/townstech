<section class="py-5 bg-csw-dark text-white text-center">
  <div class="container">
    <br/>
    <br/>
    <h1 class="display-5 fw-bold"><?= esc($title) ?> <?= esc($profile['first_name'] . ' ' . $profile['surname']) ?></h1>
    <p class="lead">Your profile overview with details as registered with the Zimbabwe Council of Social Workers.</p>
  </div>
</section>

<div class="container py-5">

  <!-- Profile Summary Card -->
  <div class="row mb-5">
    <div class="col-lg-4 text-center">
      <div class="card shadow-lg">
        <div class="card-body">
          <div class="mb-3">
            <i class="bi bi-person-circle" style="font-size: 5rem; color: #EF8236;"></i>
          </div>
          <h4><?= esc($profile['first_name'] . ' ' . $profile['surname']) ?></h4>
          <p class="text-muted"><?= esc($profile['current_post']) ?></p>
          <p><i class="bi bi-geo-alt-fill me-1"></i> <?= esc($profile['home_city']) ?>, <?= esc($profile['nationality']) ?></p>
        </div>
      </div>
    </div>

    <div class="col-lg-8">
      <!-- Personal Information -->
      <div class="card mb-4">
        <div class="card-header bg-csw-primary text-white">
          <strong><i class="bi bi-info-circle-fill me-2"></i>Personal Information</strong>
        </div>
        <div class="card-body row">
          <?php
            $personal = [
              'Title' => 'title',
              'First Name' => 'first_name',
              'Surname' => 'surname',
              'Previous Name' => 'previous_name',
              'Date of Birth' => 'dob',
              'Gender' => 'gender',
              'Nationality' => 'nationality',
              'National ID' => 'national_id',
              'Country of Birth' => 'country_of_birth',
              'City of Birth' => 'city_of_birth',
            ];
            foreach ($personal as $label => $key): ?>
              <div class="col-md-6 mb-2">
                <strong><?= $label ?>:</strong> <?= esc($profile[$key]) ?>
              </div>
          <?php endforeach; ?>
        </div>
      </div>

      <!-- Home Contact -->
      <div class="card mb-4">
        <div class="card-header bg-csw-primary text-white">
          <strong><i class="bi bi-house-door-fill me-2"></i>Home Contact</strong>
        </div>
        <div class="card-body row">
          <?php
            $home = [
              'House Number' => 'home_house_number',
              'Street Name' => 'home_street_name',
              'City' => 'home_city',
              'Telephone' => 'home_telephone',
              'Mobile' => 'home_mobile',
              'Email' => 'home_email',
            ];
            foreach ($home as $label => $key): ?>
              <div class="col-md-6 mb-2">
                <strong><?= $label ?>:</strong> <?= esc($profile[$key]) ?>
              </div>
          <?php endforeach; ?>
        </div>
      </div>

      <!-- Work Contact -->
      <div class="card mb-4">
        <div class="card-header bg-csw-primary text-white">
          <strong><i class="bi bi-building me-2"></i>Work Contact</strong>
        </div>
        <div class="card-body row">
          <?php
            $work = [
              'Organization' => 'work_organization',
              'Department' => 'work_department',
              'Street Name' => 'work_street_name',
              'City' => 'work_city',
              'Country' => 'work_country',
              'Telephone' => 'work_telephone',
              'Mobile' => 'work_mobile',
              'Email' => 'work_email',
            ];
            foreach ($work as $label => $key): ?>
              <div class="col-md-6 mb-2">
                <strong><?= $label ?>:</strong> <?= esc($profile[$key]) ?>
              </div>
          <?php endforeach; ?>
        </div>
      </div>

      <!-- Employment -->
      <div class="card mb-4">
        <div class="card-header bg-csw-primary text-white">
          <strong><i class="bi bi-briefcase-fill me-2"></i>Current Employment</strong>
        </div>
        <div class="card-body">
          <p><strong>Post:</strong> <?= esc($profile['current_post']) ?></p>
        </div>
      </div>

      <!-- Edit Button -->
      <div class="text-end">
        <a href="<?= site_url('profile/edit') ?>" class="btn btn-csw-primary btn-lg">
          <i class="bi bi-pencil-square me-1"></i> Edit Profile
        </a>
      </div>
    </div>
  </div>

</div>
