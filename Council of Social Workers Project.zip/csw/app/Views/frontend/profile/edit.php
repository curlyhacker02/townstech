<section class="py-5 bg-csw-dark text-white text-center">
  <div class="container">
    <br/>
    <br/>
    <h1 class="display-5 fw-bold"><i class="bi bi-person-badge"></i> Edit Profile</h1>
    <p class="lead">Update your personal and contact information below.</p>
  </div>
</section>

<div class="container py-5">
  <form method="post" action="<?= site_url('profile/update/' . $profile['id']) ?>" class="needs-validation" novalidate>
    <?= csrf_field() ?>

    <!-- Personal Information -->
    <div class="card mb-4 shadow-sm">
      <div class="card-header bg-csw-primary text-white d-flex align-items-center">
        <i class="bi bi-person-fill me-2"></i> <strong>Personal Information</strong>
      </div>
      <div class="card-body row g-4">
        <?php
        $fields = [
          ['Title', 'title'],
          ['First Name', 'first_name'],
          ['Surname', 'surname'],
          ['Previous Name', 'previous_name'],
          ['Date of Birth', 'dob', 'date'],
          ['Gender', 'gender', 'select', ['Male', 'Female', 'Other']],
          ['Nationality', 'nationality'],
          ['National ID', 'national_id'],
          ['Country of Birth', 'country_of_birth'],
          ['City of Birth', 'city_of_birth']
        ];
        foreach ($fields as $field) {
          $label = $field[0];
          $name = $field[1];
          $type = $field[2] ?? 'text';
          $options = $field[3] ?? [];

          echo '<div class="col-md-6">';
          echo "<label for='$name' class='form-label'>$label</label>";

          if ($type === 'select') {
            echo "<select name='$name' id='$name' class='form-select'>";
            foreach ($options as $opt) {
              $selected = ($profile[$name] === $opt) ? 'selected' : '';
              echo "<option value='$opt' $selected>$opt</option>";
            }
            echo '</select>';
          } else {
            echo "<input type='$type' class='form-control' name='$name' id='$name' value='" . esc($profile[$name]) . "'>";
          }

          echo '</div>';
        }
        ?>
      </div>
    </div>

    <!-- Home Contact -->
    <div class="card mb-4 shadow-sm">
      <div class="card-header bg-csw-primary text-white d-flex align-items-center">
        <i class="bi bi-house-fill me-2"></i> <strong>Home Contact Details</strong>
      </div>
      <div class="card-body row g-4">
        <?php
        $homeFields = [
          ['House Number', 'home_house_number'],
          ['Street Name', 'home_street_name'],
          ['City', 'home_city'],
          ['Telephone', 'home_telephone'],
          ['Mobile', 'home_mobile'],
          ['Email', 'home_email', 'email']
        ];
        foreach ($homeFields as $field) {
          $label = $field[0];
          $name = $field[1];
          $type = $field[2] ?? 'text';

          echo '<div class="col-md-6">';
          echo "<label for='$name' class='form-label'>$label</label>";
          echo "<input type='$type' class='form-control' name='$name' id='$name' value='" . esc($profile[$name]) . "'>";
          echo '</div>';
        }
        ?>
      </div>
    </div>

    <!-- Work Contact -->
    <div class="card mb-4 shadow-sm">
      <div class="card-header bg-csw-primary text-white d-flex align-items-center">
        <i class="bi bi-building me-2"></i> <strong>Work Contact Details</strong>
      </div>
      <div class="card-body row g-4">
        <?php
        $workFields = [
          ['Organization', 'work_organization'],
          ['Department', 'work_department'],
          ['Street Name', 'work_street_name'],
          ['City', 'work_city'],
          ['Country', 'work_country'],
          ['Telephone', 'work_telephone'],
          ['Mobile', 'work_mobile'],
          ['Email', 'work_email', 'email']
        ];
        foreach ($workFields as $field) {
          $label = $field[0];
          $name = $field[1];
          $type = $field[2] ?? 'text';

          echo '<div class="col-md-6">';
          echo "<label for='$name' class='form-label'>$label</label>";
          echo "<input type='$type' class='form-control' name='$name' id='$name' value='" . esc($profile[$name]) . "'>";
          echo '</div>';
        }
        ?>
      </div>
    </div>

    <!-- Current Employment -->
    <div class="card mb-4 shadow-sm">
      <div class="card-header bg-csw-primary text-white d-flex align-items-center">
        <i class="bi bi-briefcase-fill me-2"></i> <strong>Current Employment</strong>
      </div>
      <div class="card-body">
        <label for="current_post" class="form-label">Current Post</label>
        <input type="text" class="form-control" name="current_post" id="current_post" value="<?= esc($profile['current_post']) ?>">
      </div>
    </div>

    <!-- Save Button -->
    <div class="text-end mt-4">
      <button type="submit" class="btn btn-csw-primary btn-lg px-4">
        <i class="bi bi-save me-1"></i> Save Changes
      </button>
    </div>
  </form>
</div>
