<?php
$routes->group('admin/registration', ['namespace' => 'App\Modules\Registration\Controllers'], function($routes) {
    $routes->get('/', 'Registration_c::index');
    $routes->get('edit/(:num)', 'Registration_c::edit/$1');
    $routes->post('update/(:num)', 'Registration_c::update/$1');
});
