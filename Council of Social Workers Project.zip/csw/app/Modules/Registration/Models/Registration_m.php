<?php namespace App\Modules\Registration\Models;

use CodeIgniter\Model;

class Registration_m extends Model
{
    protected $table = 'pages';
    protected $primaryKey = 'id';
    protected $allowedFields = ['title', 'slug', 'content', 'created_at', 'updated_at'];
}
