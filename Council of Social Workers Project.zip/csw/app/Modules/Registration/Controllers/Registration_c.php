<?php 
namespace App\Modules\Registration\Controllers;

use App\Controllers\BaseController;
use App\Modules\Registration\Models\Registration_m;

class Registration_c extends BaseController
{
    protected $registrationModel;

    public function __construct()
    {
        $this->registrationModel = new Registration_m();
    }

    public function index()
    {
        $data['pages'] = $this->registrationModel->where('slug', 'registration')->first();
        return view('App\Modules\Registration\Views\index', $data);
    }

    public function edit($id)
    {
        $data['page'] = $this->registrationModel->find($id);
        return view('App\Modules\Registration\Views\edit', $data);
    }

    public function update($id)
    {
        $this->registrationModel->update($id, [
            'title' => $this->request->getPost('title'),
            'slug' => 'registration',
            'content' => $this->request->getPost('content'),
        ]);

        return redirect()->to(base_url('admin/registration'))->with('success', 'Updated successfully.');
    }
}
