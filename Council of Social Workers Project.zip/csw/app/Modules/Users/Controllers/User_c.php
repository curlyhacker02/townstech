<?php

namespace App\Modules\Users\Controllers;

use App\Controllers\BaseController;
use App\Modules\Users\Models\User_m;

class User_c extends BaseController
{
    protected $userModel;

    public function __construct()
    {
        $this->userModel = new User_m();
    }

    public function index()
    {
        $data['users'] = $this->userModel->findAll();
        return view('App\Modules\Users\Views\index', $data);
    }

    public function create()
    {
        return view('App\Modules\Users\Views\create');
    }

    public function store()
    {
        $photo = $this->request->getFile('photo');
        $photoName = '';

        if ($photo && $photo->isValid()) {
            $photoName = $photo->getRandomName();
            $photo->move('uploads/users', $photoName);
        }

        $this->userModel->save([
            'name'  => $this->request->getPost('name'),
            'email' => $this->request->getPost('email'),
            'role'  => $this->request->getPost('role'),
            'photo' => $photoName
        ]);

        return redirect()->to('/admin/users');
    }

    public function edit($id)
    {
        $data['user'] = $this->userModel->find($id);
        return view('App\Modules\Users\Views\edit', $data);
    }

    public function update($id)
    {
        $photo = $this->request->getFile('photo');
        $photoName = $this->request->getPost('old_photo');

        if ($photo && $photo->isValid()) {
            $photoName = $photo->getRandomName();
            $photo->move('uploads/users', $photoName);
        }

        $this->userModel->update($id, [
            'name'  => $this->request->getPost('name'),
            'email' => $this->request->getPost('email'),
            'role'  => $this->request->getPost('role'),
            'photo' => $photoName
        ]);

        return redirect()->to('/admin/users');
    }

    public function delete($id)
    {
        $this->userModel->delete($id);
        return redirect()->to('/admin/users');
    }
}
