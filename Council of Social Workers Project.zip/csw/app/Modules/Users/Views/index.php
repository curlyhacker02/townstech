<?= view('App\Views\Layout\dashheader') ?>
<?= view('App\Views\Layout\dashmenu') ?>

<div class="container mt-4">
    <h2>Users</h2>
    <a href="<?= base_url('admin/users/create') ?>" class="btn btn-primary mb-3">Add User</a>

    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>Photo</th>
                <th>Name</th>
                <th>Email</th>
                <th>Role</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($users as $user): ?>
            <tr>
                <td>
                    <?php if ($user['photo']): ?>
                        <img src="<?= base_url('uploads/users/' . $user['photo']) ?>" width="50" class="img-thumbnail">
                    <?php else: ?>
                        <span>No Photo</span>
                    <?php endif; ?>
                </td>
                <td><?= esc($user['name']) ?></td>
                <td><?= esc($user['email']) ?></td>
                <td><?= esc($user['role']) ?></td>
                <td>
                    <a href="<?= base_url('admin/users/edit/' . $user['id']) ?>" class="btn btn-sm btn-warning">Edit</a>
                    <a href="<?= base_url('admin/users/delete/' . $user['id']) ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this user?')">Delete</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?= view('App\Views\Layout\dashfooter') ?>
