<?= view('layout/dashheader') ?>
<?= view('layout/dashmenu') ?>

<div class="container">
  <h2><?= esc($news['title']) ?></h2>
<p><strong>Category:</strong> <?= esc($news['category_name']) ?></p>
<p><strong>Published:</strong> <?= esc($news['created_at']) ?></p>

<?php if (!empty($news['image'])): ?>
    <img src="<?= base_url('uploads/news/' . $news['image']) ?>" alt="News Image" class="img-fluid mb-3">
<?php endif; ?>

<p><?= esc($news['content']) ?></p>
<a href="<?= base_url('admin/news') ?>" class="btn btn-secondary">Back to list</a>


<?= view('layout/dashfooter') ?>
 