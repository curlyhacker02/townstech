<?= view('layout/dashheader') ?>
<?= view('layout/dashmenu') ?>

<div class="container">
  <h2>News Articles</h2>
  <a href="<?= base_url('admin/news/add') ?>" class="btn btn-primary mb-3">New Article</a>
  <a href="<?= base_url('admin/news/categories') ?>" class="btn btn-secondary mb-3">Manage Categories</a>
  <table class="table table-bordered">
    <thead><tr>
      <th>#</th><th>Title</th><th>Category</th><th>Created</th><th>Actions</th>
    </tr></thead>
    <tbody>
      <?php foreach ($news as $n): ?>
      <tr>
        <td><?= esc($n['id']) ?></td>
        <td><?= esc($n['title']) ?></td>
        <td><?= esc($n['category_name']) ?></td>
        <td><?= esc($n['created_at']) ?></td>
        <td>
          <a href="<?= base_url('admin/news/view/'.$n['id']) ?>" class="btn btn-sm btn-info">View</a>
          <a href="<?= base_url('admin/news/edit/'.$n['id']) ?>" class="btn btn-sm btn-warning">Edit</a>
          <a href="<?= base_url('admin/news/delete/'.$n['id']) ?>" onclick="return confirm('Delete?')" class="btn btn-sm btn-danger">Delete</a>
        </td>
      </tr>
      <?php endforeach ?>
    </tbody>
  </table>
</div>

<?= view('layout/dashfooter') ?>
