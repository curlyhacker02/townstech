<?= view('layout/dashheader') ?>
<?= view('layout/dashmenu') ?>

<div class="container">
  <h2>Edit Category</h2>
  <form action="<?= base_url('admin/news/categories/update/'.$cat['id']) ?>" method="post">
    <div class="form-group">
      <label>Name</label>
      <input type="text" name="name" value="<?= esc($cat['name']) ?>" class="form-control" required>
    </div>
    <button class="btn btn-primary">Update</button>
  </form>
</div>

<?= view('layout/dashfooter') ?>
