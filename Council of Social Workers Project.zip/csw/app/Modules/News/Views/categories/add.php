<?= view('layout/dashheader') ?>
<?= view('layout/dashmenu') ?>

<div class="container">
  <h2>Create Category</h2>
  <form action="<?= base_url('admin/news/categories/create') ?>" method="post">
    <div class="form-group">
      <label>Category Name</label>
      <input type="text" name="name" class="form-control" required>
    </div>
    <button class="btn btn-success">Save</button>
  </form>
</div>

<?= view('layout/dashfooter') ?>
