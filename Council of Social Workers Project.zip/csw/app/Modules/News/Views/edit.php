<?= view('layout/dashheader') ?>
<?= view('layout/dashmenu') ?>

<div class="container">
  <h2>Edit Article</h2>
  <form action="<?= base_url('admin/news/update/'.$item['id']) ?>" method="post" enctype="multipart/form-data">
    <div class="form-group">
      <label>Title</label>
      <input type="text" name="title" value="<?= esc($item['title']) ?>" class="form-control" required>
    </div>
    <div class="form-group">
      <label>Author Name</label>
      <input type="text" name="author_name" value="<?= esc($item['author_name']) ?>" class="form-control" required>
    </div>
    <div class="form-group">
      <label>Category</label>
      <select name="news_category_id" class="form-control">
        <?php foreach ($categories as $c): ?>
          <option value="<?= $c['id'] ?>" <?= $item['news_category_id'] == $c['id'] ? 'selected' : '' ?>>
            <?= esc($c['name']) ?>
          </option>
        <?php endforeach ?>
      </select>
    </div>
    <div class="form-group">
      <label>Replace Image (optional)</label>
      <input type="file" name="image" class="form-control">
      <?php if ($item['image']): ?>
        <img src="<?= base_url($item['image']) ?>" style="max-width: 200px" class="mt-2">
      <?php endif ?>
    </div>
    <div class="form-group">
      <label>Content</label>
      <textarea name="content" class="form-control" rows="10" required><?= esc($item['content']) ?></textarea>
    </div>
    <button type="submit" class="btn btn-primary">Update</button>
  </form>
</div>

<?= view('layout/dashfooter') ?>
