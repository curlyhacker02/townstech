<?php

namespace App\Modules\News\Controllers;

use App\Controllers\BaseController;
use App\Modules\News\Models\News_m;
use App\Modules\News\Models\NewsCategory_m;

class NewsCategory_c extends BaseController
{
    protected $newsCategoryModel;

    public function __construct()
    {
        $this->newsCategoryModel = new NewsCategory_m();
    }

    public function index()
    {
        $data['categories'] = $this->newsCategoryModel->findAll();
        return view('App\Modules\News\Views\categories\index', $data);
    }



    public function add()
    {
        if ($this->request->getMethod() === 'post') {
            $this->categoryModel->save([
                'name' => $this->request->getPost('name'),
                'slug' => url_title($this->request->getPost('name'), '-', true)
            ]);
            return redirect()->to('/admin/news/categories');
        }

        echo view('App\Modules\News\Views\categories\add');
       
    }

    public function edit($id)
    {
        $data['category'] = $this->newsCategoryModel->find($id);

        if ($this->request->getMethod() === 'post') {
            $this->categoryModel->update($id, [
                'name' => $this->request->getPost('name'),
                'slug' => url_title($this->request->getPost('name'), '-', true)
            ]);
            return redirect()->to('/admin/news/categories');
        }

        echo view('App\Modules\News\Views\categories\edit', $data);
       
    }
    public function create()
{
    echo view('App\Modules\News\Views\categories\add');
}

public function store()
{
    $name = $this->request->getPost('name');

    $this->newsCategoryModel->save([
        'name' => $name,
        'slug' => url_title($name, '-', true),
    ]);

    return redirect()->to(base_url('admin/news/categories'))->with('message', 'Category created successfully.');
}

public function update($id)
{
    $name = $this->request->getPost('name');

    $this->newsCategoryModel->update($id, [
        'name' => $name,
        'slug' => url_title($name, '-', true),
    ]);

    return redirect()->to(base_url('admin/news/categories'))->with('message', 'Category updated successfully.');
}

    public function delete($id)
    {
        $this->categoryModel->delete($id);
        return redirect()->to('/admin/news/categories');
    }
}
