<?php
namespace App\Modules\News\Controllers;

use App\Controllers\BaseController;
use App\Modules\News\Models\News_m;
use App\Modules\News\Models\NewsCategory_m;

class News_c extends BaseController
{
    protected $newsModel;
    protected $categoryModel;

    public function __construct()
    {
        $this->newsModel = new News_m();
        $this->categoryModel = new NewsCategory_m();
    }

    // ========== NEWS ==========

    public function index()
    {
        $data['news'] = $this->newsModel->getAll();
        return view('App\Modules\News\Views\index', $data);
    }

    public function add()
    {
        $data['categories'] = $this->newsModel->getCategories();
        return view('App\Modules\News\Views\add', $data);
    }

    public function view($id)
{
    $data['news'] = $this->newsModel->getNewsById($id);

    if (!$data['news']) {
        throw new \CodeIgniter\Exceptions\PageNotFoundException("News with ID $id not found.");
    }

    return view('App\Modules\News\Views\view', $data);
}


    public function create()
    {
        $data = $this->request->getPost();
        $data['slug'] = url_title($data['title'], '-', true);
        $data['created_at'] = date('Y-m-d H:i:s');

        // Handle image upload...

        $this->newsModel->createNews($data);
        return redirect()->to('admin/news')->with('success', 'News added');
    }

    // ========== CATEGORIES ==========

    public function categories()
    {
        $data['cats'] = $this->categoryModel->findAll();
        return view('App\Modules\News\Views\categories\index', $data);
    }

    public function addCategory()
    {
        return view('App\Modules\News\Views\categories\add');
    }

    public function createCategory()
    {
        $this->categoryModel->insert([
            'name' => $this->request->getPost('name'),
            'slug' => url_title($this->request->getPost('name'), '-', true),
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        return redirect()->to(base_url('admin/news/categories'))->with('success', 'Category added');
    }

    public function editCategory($id)
    {
        $data['cat'] = $this->categoryModel->find($id);
        return view('App\Modules\News\Views\categories\edit', $data);
    }

    public function updateCategory($id)
    {
        $this->categoryModel->update($id, [
            'name' => $this->request->getPost('name'),
            'slug' => url_title($this->request->getPost('name'), '-', true),
            'updated_at' => date('Y-m-d H:i:s'),
        ]);

        return redirect()->to(base_url('admin/news/categories'))->with('success', 'Category updated');
    }

    public function deleteCategory($id)
    {
        $this->categoryModel->delete($id);
        return redirect()->to(base_url('admin/news/categories'))->with('success', 'Category deleted');
    }
}
