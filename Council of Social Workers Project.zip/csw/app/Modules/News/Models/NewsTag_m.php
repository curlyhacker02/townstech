<?php
namespace App\Modules\News\Models;

use CodeIgniter\Model;

class NewsTag_m extends Model
{
    protected $table = 'news_tags';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $useSoftDeletes = false;
    protected $allowedFields = ['name', 'slug'];
    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = '';
    protected $deletedField = '';
    protected $validationRules = [];
    protected $validationMessages = [];
    protected $skipValidation = false;

    protected $beforeInsert = ['createSlug'];
    protected $beforeUpdate = ['createSlug'];

    protected function createSlug(array $data)
    {
        $data['data']['slug'] = url_title($data['data']['name'], '-', true);
        return $data;
    }

    public function getTags()
    {
        return $this->findAll();
    }

    public function getTagsByArticle($articleId)
    {
        $builder = $this->builder()
            ->select('news_tags.*')
            ->join('news_tag_map', 'news_tags.id = news_tag_map.tag_id')
            ->where('news_tag_map.article_id', $articleId);

        return $builder->findAll();
    }

    public function getTagById($id)
    {
        return $this->find($id);
    }

    public function getTagBySlug($slug)
    {
        return $this->where('slug', $slug)->first();
    }

    public function createTag($data)
    {
        return $this->insert($data);
    }

    public function updateTag($id, $data)
    {
        return $this->update($id, $data);
    }

    public function deleteTag($id)
    {
        return $this->delete($id);
    }
}
