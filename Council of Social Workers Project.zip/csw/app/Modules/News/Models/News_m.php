<?php 
namespace App\Modules\News\Models;

use App\Modules\News\Models\NewsCategory_m;
use App\Modules\News\Models\NewsTag_m;
use CodeIgniter\Model;

class News_m extends Model
{
    protected $table = 'news';
    protected $allowedFields = ['title', 'slug', 'content', 'image', 'author_name', 'author_image', 'news_category_id', 'created_at'];

    public function getAll()
    {
        $articles = $this->select('news.*, news_categories.name as category_name')
                        ->join('news_categories', 'news.news_category_id = news_categories.id', 'left')
                        ->orderBy('created_at', 'DESC')
                        ->findAll();

        // Fetch tags for each article
        $newsTagModel = new NewsTag_m();
        foreach ($articles as &$article) {
            $article['news_tags'] = $newsTagModel->getTagsByArticle($article['id']);
        }

        return $articles;
    }

    public function getCategories()
    {
        return $this->db->table('news_categories')->get()->getResultArray();
    }

    public function createNews($data)
    {
        return $this->insert($data);
    }

    public function getNewsById($id)
    {
        $article = $this->select('news.*, news_categories.name as category_name')
                        ->join('news_categories', 'news_categories.id = news.news_category_id', 'left')
                        ->where('news.id', $id)
                        ->first();

        if ($article) {
            $newsTagModel = new NewsTag_m();
            $article['tags'] = $newsTagModel->getTagsByArticle($id);
        }

        return $article;
    }

}

