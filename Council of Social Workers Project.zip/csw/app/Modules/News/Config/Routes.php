<?php
$routes->group('admin/news', ['namespace' => 'App\Modules\News\Controllers'], function($routes) {
    $routes->get('/', 'News_c::index');
    $routes->get('add', 'News_c::add');
    $routes->post('create', 'News_c::create');
    $routes->get('edit/(:num)', 'News_c::edit/$1');
    $routes->post('update/(:num)', 'News_c::update/$1');
    $routes->get('delete/(:num)', 'News_c::delete/$1');
    $routes->get('view/(:num)', 'News_c::view/$1');

    // Categories
    $routes->get('categories', 'News_c::categories');
    $routes->get('categories/add', 'News_c::addCategory');
    $routes->post('categories/create', 'News_c::createCategory');
    $routes->get('categories/edit/(:num)', 'News_c::editCategory/$1');
    $routes->post('categories/update/(:num)', 'News_c::updateCategory/$1');
    $routes->get('categories/delete/(:num)', 'News_c::deleteCategory/$1');
});