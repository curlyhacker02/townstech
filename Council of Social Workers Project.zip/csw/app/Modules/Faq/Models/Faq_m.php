<?php

namespace App\Modules\Faq\Models;

use CodeIgniter\Model;

class Faq_m extends Model
{
    protected $table = 'faqs';
    protected $primaryKey = 'id';
    protected $allowedFields = ['question', 'answer', 'created_at', 'updated_at'];
    protected $useTimestamps = true;
}
