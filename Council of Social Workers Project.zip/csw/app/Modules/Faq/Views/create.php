<?= view('App\Views\Layout\dashheader') ?>
<?= view('App\Views\Layout\dashmenu') ?>

<div class="container mt-4">
    <h2>Add FAQ</h2>
    <form method="post" action="<?= site_url('admin/faq/store') ?>">
        <div class="mb-3">
            <label class="form-label">Question</label>
            <input type="text" name="question" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Answer</label>
            <textarea name="answer" class="form-control" rows="4" required></textarea>
        </div>
        <button class="btn btn-success">Save</button>
        <a href="<?= site_url('admin/faq') ?>" class="btn btn-secondary">Cancel</a>
    </form>
</div>

<?= view('App\Views\Layout\dashfooter') ?>
