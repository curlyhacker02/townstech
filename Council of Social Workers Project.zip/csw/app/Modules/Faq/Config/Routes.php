<?php

$routes->group('admin/faq', [
    'namespace' => 'App\Modules\Faq\Controllers',
], function($routes) {
    $routes->get('',             'Faq_c::index');
    $routes->get('create',       'Faq_c::create');
    $routes->post('store',       'Faq_c::store');
    $routes->get('edit/(:num)',  'Faq_c::edit/$1');
    $routes->post('update/(:num)','Faq_c::update/$1');
    $routes->get('delete/(:num)','Faq_c::delete/$1');
});
