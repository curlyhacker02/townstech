<?php

namespace App\Modules\Faq\Controllers;

use App\Controllers\BaseController;
use App\Modules\Faq\Models\Faq_m;

class Faq_c extends BaseController
{
    protected $faqModel;

    public function __construct()
    {
        $this->faqModel = new Faq_m();
    }

    /** List all FAQs */
    public function index()
    {
        $data['faqs'] = $this->faqModel->findAll();
        return view('App\Modules\Faq\Views\index', $data);
    }

    /** Show “create new” form */
    public function create()
    {
        return view('App\Modules\Faq\Views\create');
    }

    /** Process new FAQ */
    public function store()
    {
        $this->faqModel->save([
            'question' => $this->request->getPost('question'),
            'answer'   => $this->request->getPost('answer'),
        ]);
        return redirect()->to(site_url('admin/faq'));
    }

    /** Show “edit” form */
    public function edit($id)
    {
        $data['faq'] = $this->faqModel->find($id);
        if (! $data['faq']) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException("FAQ not found");
        }
        return view('App\Modules\Faq\Views\edit', $data);
    }

    /** Process update */
    public function update($id)
    {
        $this->faqModel->update($id, [
            'question' => $this->request->getPost('question'),
            'answer'   => $this->request->getPost('answer'),
        ]);
        return redirect()->to(site_url('admin/faq'));
    }

    /** Delete an FAQ */
    public function delete($id)
    {
        $this->faqModel->delete($id);
        return redirect()->to(site_url('admin/faq'));
    }
}
