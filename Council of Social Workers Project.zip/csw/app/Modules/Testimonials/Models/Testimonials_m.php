<?php

namespace App\Modules\Testimonials\Models;
use CodeIgniter\Model;

class Testimonials_m extends Model
{
    protected $table = 'testimonials';
    protected $primaryKey = 'id';
    protected $allowedFields = ['name', 'role', 'photo', 'message', 'status'];
}
