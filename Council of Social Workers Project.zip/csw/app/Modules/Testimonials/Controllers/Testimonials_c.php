<?php

namespace App\Modules\Testimonials\Controllers;

use App\Controllers\BaseController;
use App\Modules\Testimonials\Models\Testimonials_m;

class Testimonials_c extends BaseController
{
    protected $testimonialModel;

    public function __construct()
    {
        $this->testimonialModel = new Testimonials_m();
    }

    public function index()
    {
         helper('text');
         
        $data['testimonials'] = $this->testimonialModel->findAll();
        return view('App\Modules\Testimonials\Views\index', $data);
    }

    public function create()
    {
        return view('App\Modules\Testimonials\Views\create');
    }

    public function store()
    {
        $this->testimonialModel->save([
            'name' => $this->request->getPost('name'),
            'role' => $this->request->getPost('role'),
            'photo' => $this->request->getPost('photo'),
            'message' => $this->request->getPost('message'),
            'status' => $this->request->getPost('status'),
        ]);

        return redirect()->to('admin/testimonials');
    }

    public function edit($id)
    {
        $data['testimonial'] = $this->testimonialModel->find($id);
        return view('App\Modules\Testimonials\Views\edit', $data);
    }

    public function update($id)
    {
        $this->testimonialModel->update($id, [
            'name' => $this->request->getPost('name'),
            'role' => $this->request->getPost('role'),
            'photo' => $this->request->getPost('photo'),
            'message' => $this->request->getPost('message'),
            'status' => $this->request->getPost('status'),
        ]);

        return redirect()->to('admin/testimonials');
    }

    public function delete($id)
    {
        $this->testimonialModel->delete($id);
        return redirect()->to('admin/testimonials');
    }
}
