<?php 
$routes->group('admin/settings', ['namespace' => 'App\Modules\Settings\Controllers'], function($routes) {
    $routes->get('/', 'Settings_c::index');
    $routes->post('update', 'Settings_c::update');
});
