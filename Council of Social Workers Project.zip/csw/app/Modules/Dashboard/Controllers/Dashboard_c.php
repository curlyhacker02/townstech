<?php

namespace App\Modules\Dashboard\Controllers;
use App\Controllers\BaseController;
use Config\Database;

class Dashboard_c extends BaseController
{
    public function index()
    {
        $db = Database::connect();

        $data = [
    
            'news_count'       => $db->table('news')->countAllResults(),
            'download_count'   => $db->table('downloads')->countAllResults(),
            'contact_count'    => $db->table('contact_messages')->countAllResults(),
            'faq_count'        => $db->table('faqs')->countAllResults(),
            'testimonial_count' => $db->table('testimonials')->countAllResults(),
            'user_count'       => $db->table('users')->countAllResults(), // Adjust if your table name differs
        ];

        return view('App\Modules\Dashboard\Views\index', $data);
    }
}
