<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Council of Social Workers</title>
  <meta name="description" content="">
  <meta name="keywords" content="">

  <!-- Favicons -->
  <link href="<?= base_url('assets/img/favicon.png') ?>" rel="icon">
  <link href="<?= base_url('assets/img/apple-touch-icon.png') ?>" rel="apple-touch-icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&family=Montserrat:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="<?= base_url('assets/vendor/bootstrap/css/bootstrap.min.css') ?>" rel="stylesheet">
  <link href="<?= base_url('assets/vendor/bootstrap-icons/bootstrap-icons.css') ?>" rel="stylesheet">
  <link href="<?= base_url('assets/vendor/aos/aos.css') ?>" rel="stylesheet">
  <link href="<?= base_url('assets/vendor/glightbox/css/glightbox.min.css') ?>" rel="stylesheet">
  <link href="<?= base_url('assets/vendor/swiper/swiper-bundle.min.css') ?>" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="<?= base_url('assets/css/main.css') ?>" rel="stylesheet">
  <link href="<?= base_url('assets/css/custom.css') ?>" rel="stylesheet">
</head>

<?= view('App\Views\Layout\dashmenu') ?>

<div class="content-wrapper">
    <section class="content-header">
        <h1>Dashboard</h1>
    </section>

    <section class="content">
        <div class="row">
            <?php 
            $boxes = [

                ['label' => 'News', 'count' => $news_count, 'color' => 'success', 'icon' => 'newspaper', 'link' => 'admin/news'],
                ['label' => 'Downloads', 'count' => $download_count, 'color' => 'warning', 'icon' => 'download', 'link' => 'admin/downloads'],
                ['label' => 'Contacts', 'count' => $contact_count, 'color' => 'danger', 'icon' => 'envelope', 'link' => 'admin/contact_messages'],
                 ['label' => 'FAQs', 'count' => $faq_count, 'color' => 'secondary', 'icon' => 'question-circle', 'link' => 'admin/faq'],
                   ['label' => 'Testimonials', 'count' => $testimonial_count, 'color' => 'secondary', 'icon' => 'question-circle', 'link' => 'admin/testimonials'],
                ['label' => 'Users', 'count' => $user_count, 'color' => 'primary', 'icon' => 'users', 'link' => 'admin/users'],
            ];

            foreach ($boxes as $box): ?>
            <div class="col-lg-3 col-6">
                <div class="small-box bg-<?= $box['color'] ?>">
                    <div class="inner">
                        <h3><?= $box['count'] ?></h3>
                        <p><?= $box['label'] ?></p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-<?= $box['icon'] ?>"></i>
                    </div>
                    <a href="<?= base_url($box['link']) ?>" class="small-box-footer">
                        More info <i class="fas fa-arrow-circle-right"></i>
                    </a>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </section>
</div>

<?= view('App\Views\Layout\dashfooter') ?>
