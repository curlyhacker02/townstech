<?= view('App\Views\Layout\dashheader') ?>
<?= view('App\Views\Layout\dashmenu') ?>

<div class="container mt-4">
    <h2>Edit Home Page</h2>

    <?php if(session()->getFlashdata('success')): ?>
    <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
    <?php endif; ?>

    <form method="post" action="<?= site_url('admin/home/update') ?>">
        <div class="mb-3">
            <label>Welcome Message</label>
            <textarea name="welcome_message" class="form-control" required><?= esc($home['welcome_message']) ?></textarea>
        </div>

        <div class="mb-3">
            <label>Intro Paragraph</label>
            <textarea name="intro_paragraph" class="form-control" required><?= esc($home['intro_paragraph']) ?></textarea>
        </div>

        <div class="mb-3">
            <label>Why Join CSW</label>
            <textarea name="why_join_csw" class="form-control" required><?= esc($home['why_join_csw']) ?></textarea>
        </div>

        <div class="row">
            <div class="col-md-4 mb-3">
                <label>Years of Service</label>
                <input type="number" name="years_of_service" class="form-control" value="<?= esc($home['years_of_service']) ?>" required>
            </div>
            <div class="col-md-4 mb-3">
                <label>Training Events</label>
                <input type="number" name="training_events" class="form-control" value="<?= esc($home['training_events']) ?>" required>
            </div>
            <div class="col-md-4 mb-3">
                <label>Professional Partners</label>
                <input type="number" name="professional_partners" class="form-control" value="<?= esc($home['professional_partners']) ?>" required>
            </div>
        </div>

        <button type="submit" class="btn btn-primary">Update Home Page</button>
    </form>
</div>

<?= view('App\Views\Layout\dashfooter') ?>
