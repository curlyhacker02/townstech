<?php 
$routes->group('admin/pages', ['namespace' => 'App\Modules\Pages\Controllers'], function($routes) {
    $routes->get('/', 'Pages_c::index');
    $routes->get('add', 'Pages_c::add');
    $routes->post('store', 'Pages_c::store');
    $routes->get('edit/(:num)', 'Pages_c::edit/$1');
    $routes->post('update/(:num)', 'Pages_c::update/$1');
    $routes->get('delete/(:num)', 'Pages_c::delete/$1');
});

