<?php

namespace App\Modules\Pages\Controllers;

use App\Controllers\BaseController;
use App\Modules\Pages\Models\Pages_m;

class Pages_c extends BaseController
{
    protected $pagesModel;

    public function __construct()
    {
        $this->pagesModel = new Pages_m();
    }

    public function index()
    {
        $data['pages'] = $this->pagesModel->findAll();
        return view('App\Modules\Pages\Views\index', $data);
    }

    public function add()
    {
    return view('App\Modules\Pages\Views\add', [
        'action'  => 'admin/pages/store',
        'btnText' => 'Save',
        'page'    => []
    ]);
    }

    public function store()
    {
        $fileHero = $this->request->getFile('hero_image');
        $filePage = $this->request->getFile('page_image');

        $heroImageName = $fileHero->isValid() && !$fileHero->hasMoved() ? $fileHero->getRandomName() : null;
        $pageImageName = $filePage->isValid() && !$filePage->hasMoved() ? $filePage->getRandomName() : null;

        if ($heroImageName) $fileHero->move('uploads/pages', $heroImageName);
        if ($pageImageName) $filePage->move('uploads/pages', $pageImageName);

        $this->pagesModel->save([
            'title'      => $this->request->getPost('title'),
            'slug'       => url_title($this->request->getPost('title'), '-', true),
            'intro'      => $this->request->getPost('intro'),
            'content'    => $this->request->getPost('content'),
            'mission'    => $this->request->getPost('mission'),
            'vision'     => $this->request->getPost('vision'),
            'values'     => $this->request->getPost('values'),
            'history'    => $this->request->getPost('history'),
            'hero_image' => $heroImageName,
            'page_image' => $pageImageName,
        ]);

        return redirect()->to(base_url('admin/pages'))->with('message', 'Page added successfully.');
    }

    public function edit($id)
{
    $page = $this->pagesModel->find($id);

    return view('App\Modules\Pages\Views\edit', [
        'action'  => 'admin/pages/update/' . $id,
        'btnText' => 'Update',
        'page'    => $page
    ]);
}

    public function update($id)
{
    $page = $this->pagesModel->find($id);

    $fileHero = $this->request->getFile('hero_image');
    $filePage = $this->request->getFile('page_image');

    $heroImageName = $fileHero && $fileHero->isValid() && !$fileHero->hasMoved()
        ? $fileHero->getRandomName()
        : $page['hero_image'];

    $pageImageName = $filePage && $filePage->isValid() && !$filePage->hasMoved()
        ? $filePage->getRandomName()
        : $page['page_image'];

    if ($fileHero && $fileHero->isValid() && !$fileHero->hasMoved()) {
        $fileHero->move('uploads/pages', $heroImageName);
    }

    if ($filePage && $filePage->isValid() && !$filePage->hasMoved()) {
        $filePage->move('uploads/pages', $pageImageName);
    }

    $this->pagesModel->update($id, [
        'title'     => $this->request->getPost('title'),
        'slug'      => $this->request->getPost('slug'),
        'content'   => $this->request->getPost('content'),
        'mission'   => $this->request->getPost('mission'),
        'vision'    => $this->request->getPost('vision'),
        'history'   => $this->request->getPost('history'),
        'hero_image'=> $heroImageName,
        'page_image'=> $pageImageName,
    ]);

    return redirect()->to(base_url('admin/pages'))->with('message', 'Page updated successfully.');
}

    public function delete($id)
    {
        $this->pagesModel->delete($id);
        return redirect()->to(base_url('admin/pages'))->with('message', 'Page deleted.');
    }
}
