<?= view('App\Views\Layout\dashheader') ?>
<?= view('App\Views\Layout\dashmenu') ?>

<div class="container">
    <h2>Pages</h2>
    
<a href="<?= base_url('admin/pages/add') ?>" class="btn btn-primary mb-2">Add Page</a>
<table class="table table-bordered">
    <thead><tr>
        <th>Title</th><th>Slug</th><th>Actions</th>
    </tr></thead>
    <tbody>
        <?php foreach ($pages as $page): ?>
            <tr>
                <td><?= $page['title'] ?></td>
                <td><?= $page['slug'] ?></td>
                <td>
                    <a href="<?= base_url('admin/pages/edit/' . $page['id']) ?>" class="btn btn-sm btn-warning">Edit</a>
                    <a href="<?= base_url('admin/pages/delete/' . $page['id']) ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this page?')">Delete</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>


<?= view('App\Views\Layout\dashfooter') ?>
