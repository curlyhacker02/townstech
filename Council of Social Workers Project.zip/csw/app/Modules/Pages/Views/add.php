<?= view('Layout/dashheader') ?>
<?= view('Layout/dashmenu') ?>

<div class="container">
    <h2>Add New Page</h2>
    <form method="post" action="<?= base_url($action) ?>" enctype="multipart/form-data">
    <input type="text" name="title" value="<?= $page['title'] ?? '' ?>" class="form-control mb-2" placeholder="Page Title">
    <textarea name="intro" class="form-control mb-2" placeholder="Intro"><?= $page['intro'] ?? '' ?></textarea>
    <textarea name="content" class="form-control mb-2" placeholder="Content"><?= $page['content'] ?? '' ?></textarea>
    <textarea name="mission" class="form-control mb-2" placeholder="Mission"><?= $page['mission'] ?? '' ?></textarea>
    <textarea name="vision" class="form-control mb-2" placeholder="Vision"><?= $page['vision'] ?? '' ?></textarea>
    <textarea name="values" class="form-control mb-2" placeholder="Values"><?= $page['values'] ?? '' ?></textarea>
    <textarea name="history" class="form-control mb-2" placeholder="History"><?= $page['history'] ?? '' ?></textarea>

    <label>Hero Image:</label>
    <input type="file" name="hero_image" class="form-control mb-2">
    <?php if (!empty($page['hero_image'])): ?>
        <img src="<?= base_url('uploads/pages/' . $page['hero_image']) ?>" height="100">
    <?php endif; ?>

    <label>Page Image:</label>
    <input type="file" name="page_image" class="form-control mb-2">
    <?php if (!empty($page['page_image'])): ?>
        <img src="<?= base_url('uploads/pages/' . $page['page_image']) ?>" height="100">
    <?php endif; ?>

    <button class="btn btn-success"><?= $btnText ?></button>
</form>
</div>

<?= view('Layout/dashfooter') ?>
