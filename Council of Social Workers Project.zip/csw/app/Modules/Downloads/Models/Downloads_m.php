<?php

namespace App\Modules\Downloads\Models;

use CodeIgniter\Model;

class Downloads_m extends Model
{
    protected $table = 'downloads';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'title',
        'description',
        'file',
        'download_category_id',
        'status',
        'created_at',
        'updated_at'
    ];

    protected $useTimestamps = true;
}
