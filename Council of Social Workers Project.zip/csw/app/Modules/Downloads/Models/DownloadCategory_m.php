<?php

namespace App\Modules\Downloads\Models;

use CodeIgniter\Model;

class DownloadCategory_m extends Model
{
    protected $table = 'download_categories';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'name'
    ];

    public $timestamps = false;
}
