<?= view('layout/dashheader') ?>
<?= view('layout/dashmenu') ?>

<div class="container">
    <h2>Add Download</h2>
    <form action="<?= base_url('admin/downloads/create') ?>" method="post">
        <div class="mb-3">
            <label>Title</label>
            <input type="text" name="title" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Description</label>
            <textarea name="description" class="form-control" required></textarea>
        </div>

        <div class="mb-3">
            <label>Category</label>
            <select name="download_category_id" class="form-control" required>
                <option value="">-- Select Category --</option>
                <?php foreach ($categories as $cat): ?>
                    <option value="<?= $cat['id'] ?>"><?= esc($cat['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="mb-3">
            <label>File Path</label>
            <input type="text" name="file_path" class="form-control" required>
        </div>

        <button type="submit" class="btn btn-success">Save</button>
    </form>
</div>

<?= view('layout/dashfooter') ?>
