<?= view('layout/dashheader') ?>
<?= view('layout/dashmenu') ?>

<div class="container">
    <h2>Download Details</h2>

    <table class="table table-bordered">
        <tr>
            <th>Title</th>
            <td><?= esc($download['title']) ?></td>
        </tr>
        <tr>
            <th>Description</th>
            <td><?= esc($download['description']) ?></td>
        </tr>
        <tr>
            <th>Category</th>
            <td><?= esc($download['category_name'] ?? 'Uncategorized') ?></td>
        </tr>
        <tr>
            <th>File Path</th>
            <td><?= esc($download['file_path']) ?></td>
        </tr>
    </table>

    <a href="<?= base_url('admin/downloads') ?>" class="btn btn-secondary">Back to List</a>
</div>

<?= view('layout/dashfooter') ?>
