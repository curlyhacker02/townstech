<?= view('layout/dashheader') ?>
<?= view('layout/dashmenu') ?>

<div class="container">
    <h2>Edit Download</h2>
    <form action="<?= base_url('admin/downloads/update/' . $download['id']) ?>" method="post">
        <div class="mb-3">
            <label>Title</label>
            <input type="text" name="title" value="<?= esc($download['title']) ?>" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Description</label>
            <textarea name="description" class="form-control" required><?= esc($download['description']) ?></textarea>
        </div>

        <div class="mb-3">
            <label>Category</label>
            <select name="download_category_id" class="form-control" required>
                <?php foreach ($categories as $cat): ?>
                    <option value="<?= $cat['id'] ?>" <?= $cat['id'] == $download['download_category_id'] ? 'selected' : '' ?>>
                        <?= esc($cat['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="mb-3">
            <label>File Path</label>
            <input type="text" name="file_path" value="<?= esc($download['file_path']) ?>" class="form-control" required>
        </div>

        <button type="submit" class="btn btn-primary">Update</button>
    </form>
</div>

<?= view('layout/dashfooter') ?>
