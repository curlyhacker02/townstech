<?= view('App\Views\Layout\dashheader') ?>
<?= view('App\Views\Layout\dashmenu') ?>

<div class="container mt-4">
    <h2>Edit About Page</h2>

    <form method="post" action="<?= site_url('admin/about/update/' . $about['id']) ?>">
        <?= csrf_field() ?>

        <div class="form-group mb-3">
            <label>Who We Are</label>
            <textarea name="who_we_are" class="form-control" rows="3" required><?= esc($about['who_we_are']) ?></textarea>
        </div>

        <div class="form-group mb-3">
            <label>Our Work</label>
            <textarea name="our_work" class="form-control" rows="3" required><?= esc($about['our_work']) ?></textarea>
        </div>

        <div class="form-group mb-3">
            <label>Mission</label>
            <textarea name="mission" class="form-control" rows="3" required><?= esc($about['mission']) ?></textarea>
        </div>

        <div class="form-group mb-3">
            <label>Vision</label>
            <textarea name="vision" class="form-control" rows="3" required><?= esc($about['vision']) ?></textarea>
        </div>

        <div class="form-group mb-3">
            <label>Core Values</label>
            <textarea name="core_values" class="form-control" rows="3" required><?= esc($about['core_values']) ?></textarea>
        </div>

        <button type="submit" class="btn btn-success">Save Changes</button>
        <a href="<?= site_url('admin/about') ?>" class="btn btn-secondary">Cancel</a>
    </form>
</div>

<?= view('App\Views\Layout\dashfooter') ?>
