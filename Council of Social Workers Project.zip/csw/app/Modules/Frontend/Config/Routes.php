<?php 
$routes->group('', ['namespace' => 'App\Modules\Frontend\Controllers'], function($routes) {
   //home routes
    $routes->get('/', 'Frontend\Home::index');
    $routes->post('testimonials/submit', 'Home_c::submitTestimonial');


   //about routes
     $routes->get('about', 'About_c::index');

   //contact routes
    $routes->get('contact', 'Frontend_c::contact');
    $routes->post('contact', 'Frontend_c::contact');

    //faq routes
     $routes->get('faqs', 'Faq_c::index');

   // News listing
    $routes->get('news', 'News_c::index');
    // Single news with slug
    $routes->get('news/(:segment)', 'News_c::show/$1');
    $routes->post('news/(:segment)', 'News_c::postComment/$1');
   $routes->get('news/tag/(:segment)', 'News_c::tag/$1');



    // downloads routes
    $routes->get('downloads', 'DownloadController::index');

    // Catch-all (must be last!)
    
});



