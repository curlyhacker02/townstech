<?= view('App\Modules\Frontend\Views\layout/header') ?>

<div class="container my-5">
  <div class="row">
    <div class="col-md-8">
      <?php if($news['image']): ?>
        <img src="<?= base_url('uploads/news/' . $news['image']) ?>" class="img-fluid rounded mb-3">
      <?php endif; ?>

      <h1><?= esc($news['title']) ?></h1>
      <p class="text-muted">
        <?= esc($news['category_name']) ?> &bull;
        <?= date('F j, Y', strtotime($news['created_at'])) ?> &bull;
        <?= esc($news['author_name']) ?>
        (<?= date('F j, Y', strtotime($news['created_at'])) ?>)
      </p>

      <div><?= $news['content'] ?></div>

      <?php if(!empty($tags)): ?>
      <div class="mt-3">
        <strong>Tags:</strong>
        <?php foreach($tags as $tag): ?>
          <a href="<?= base_url('news?tag=' . esc($tag['slug'])) ?>" class="badge bg-secondary"><?= esc($tag['name']) ?></a>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>

      <hr>

      <h4 id="comments"><?= count($comments) ?> Comments</h4>
      <?php foreach($comments as $c): ?>
        <div class="mb-3">
          <strong><?= esc($c['name']) ?></strong>
          <small class="text-muted">
            <?= date('F j, Y', strtotime($c['updated_at'] ?? $c['created_at'])) ?>
          </small>
          <p><?= esc($c['comment']) ?></p>
        </div>

      <?php endforeach; ?>

      <?php if(session()->getFlashdata('success')): ?>
        <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
      <?php endif; ?>

      <h5>Leave a Comment</h5>
      <form action="<?= site_url('news/' . $news['slug']) ?>" method="post">
        <div class="mb-2">
          <label>Your Name*</label>
          <input type="text" name="name" class="form-control" required>
        </div>
        <div class="mb-2">
          <label>Your Email*</label>
          <input type="email" name="email" class="form-control" required>
        </div>
        <div class="mb-2">
          <label>Your Comment*</label>
          <textarea name="comment" rows="4" class="form-control" required></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Post Comment</button>
      </form>
    </div>

    <div class="col-md-4">
      <?= view('App\Modules\Frontend\Views\news/_sidebar', [
        'categories' => $categories,
        'recentPosts' => $recentPosts
      ]) ?>
    </div>

  </div>
</div>

<?= view('App\Modules\Frontend\Views\layout/footer') ?>
