<div class="mb-4">
  <h5>Search</h5>
  <form action="<?= base_url('news') ?>" method="get">
    <input type="text" name="search" class="form-control" placeholder="Search...">
  </form>
</div>

<div class="mb-4">
  <h5>Categories</h5>
  <ul class="list-unstyled">
    <?php foreach($categories as $cat): ?>
      <li>
        <a href="<?= base_url('news?category=' . esc($cat['slug'])) ?>">
          <?= esc($cat['name']) ?> (<?= esc($cat['news_count']) ?>)
        </a>
      </li>
    <?php endforeach; ?>
  </ul>
</div>

<div class="mb-4">
  <h5>Recent Posts</h5>
  <?php foreach($recentPosts as $rp): ?>
    <div class="d-flex mb-2">
      <?php if($rp['image']): ?>
        <img src="<?= base_url('uploads/news/' . $rp['image']) ?>" width="60" class="me-2">
      <?php endif; ?>
      <div>
        <a href="<?= base_url('news/' . esc($rp['slug'])) ?>"><?= esc($rp['title']) ?></a><br>
        <small class="text-muted"><?= date('F j, Y', strtotime($rp['created_at'])) ?></small>
      </div>
    </div>
  <?php endforeach; ?>

  <div class="mb-4">
    <h5>Tags</h5>
    <div class="tag-cloud">
      <?php if (!empty($tags)) : ?>
        <?php foreach ($tags as $tag) : ?>
          <a href="<?= site_url('news/tag/' . esc($tag['slug'])) ?>" class="badge bg-secondary text-decoration-none"><?= esc($tag['name']) ?></a>
        <?php endforeach; ?>
      <?php else : ?>
        <p>No tags found.</p>
      <?php endif; ?>
    </div>
  </div>
</div>
