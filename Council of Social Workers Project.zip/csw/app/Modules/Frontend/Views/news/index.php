<?= view('App\Modules\Frontend\Views\layout/header') ?>

<div class="container my-5">
  <div class="row">
    <div class="col-md-8">
      <?php foreach($newsList as $item): ?>
        <div class="card mb-4">
          <?php if($item['image']): ?>
            <img src="<?= base_url('uploads/news/' . $item['image']) ?>" class="card-img-top">
          <?php endif; ?>
          <div class="card-body">
            <p class="text-muted"><?= esc($item['category_name']) ?> &bull; <?= date('F j, Y', strtotime($item['created_at'])) ?></p>
            <h3><a href="<?= base_url('news/' . esc($item['slug'])) ?>"><?= esc($item['title']) ?></a></h3>
            <div class="mt-3 d-flex align-items-center">
              <?php if($item['author_image']): ?>
                <img src="<?= base_url('uploads/news/authors/' . $item['author_image']) ?>" width="40" class="rounded-circle me-2">
              <?php endif; ?>
              <span><?= esc($item['author_name']) ?></span>
            </div>
          </div>
        </div>
      <?php endforeach; ?>

      <?= $pager->links('group1', 'default_full') ?>
    </div>

    <div class="col-md-4">
      <?= view('App\Modules\Frontend\Views\news/_sidebar', [
        'categories' => $categories,
        'recentPosts' => $recentPosts
      ]) ?>
    </div>
  </div>
</div>

<?= view('App\Modules\Frontend\Views\layout/footer') ?>
