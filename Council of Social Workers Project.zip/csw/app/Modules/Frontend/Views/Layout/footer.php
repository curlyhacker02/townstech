<footer>
    <p>&copy; <?= date('Y') ?> <?= esc($settings['site_name'] ?? 'CSW') ?></p>

    <div class="social">
        <?php if (!empty($settings['facebook_url'])): ?>
            <a href="<?= esc($settings['facebook_url']) ?>" target="_blank">Facebook</a>
        <?php endif; ?>
        <?php if (!empty($settings['twitter_url'])): ?>
            | <a href="<?= esc($settings['twitter_url']) ?>" target="_blank">Twitter</a>
        <?php endif; ?>
        <?php if (!empty($settings['linkedin_url'])): ?>
            | <a href="<?= esc($settings['linkedin_url']) ?>" target="_blank">LinkedIn</a>
        <?php endif; ?>
    </div>
</footer>
