<!DOCTYPE html>
<html>
<head>
    <title><?= esc(get_setting('site_name') ?? 'CSW Site') ?></title>
    <link rel="icon" href="<?= base_url('uploads/settings/' . (get_setting('site_logo') ?? 'favicon.ico')) ?>">
</head>
<body>
    <header>
        <div class="logo">
            <a href="<?= base_url('/') ?>">
                <img 
                    src="<?= base_url('uploads/settings/' . (get_setting('site_logo') ?? 'default-logo.jpg')) ?>" 
                    alt="<?= esc(get_setting('site_name') ?? 'CSW Logo') ?>" 
                    height="80"
                >
            </a>
        </div>
    </header>
