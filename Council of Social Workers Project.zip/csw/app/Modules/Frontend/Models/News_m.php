<?php

namespace App\Modules\Frontend\Models;

use CodeIgniter\Model;

class News_m extends Model
{
    protected $table = 'news';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'title', 'slug', 'content', 'image',
        'author_name', 'author_image', 'news_category_id',
        'created_at'
    ];

    // List with category count and pagination
    public function getPagedNews($perPage = 6, $page = 1)
    {
        return $this->select('news.*, news_categories.name AS category_name')
            ->join('news_categories', 'news_categories.id = news.news_category_id', 'left')
            ->orderBy('created_at', 'DESC')
            ->paginate($perPage, 'group1', $page);
    }

    public function getPager() {
        return $this->pager;
    }

    public function getNewsBySlug($slug)
    {
        return $this->select('news.*, news_categories.name AS category_name')
            ->join('news_categories', 'news_categories.id = news.news_category_id', 'left')
            ->where('news.slug', $slug)
            ->first();
    }

    public function getCategoriesWithCount()
    {
        $builder = $this->db->table('news_categories nc')
            ->select('nc.*, COUNT(n.id) as news_count')
            ->join('news n', 'n.news_category_id = nc.id', 'left')
            ->groupBy('nc.id')
            ->orderBy('nc.name');

        return $builder->get()->getResultArray();
    }

    public function getRecentPosts($limit = 5)
    {
        return $this->orderBy('created_at', 'DESC')
                    ->select('id, title, slug, image, created_at')
                    ->findAll($limit);
    }

    public function getComments($newsId)
    {
        return $this->db->table('news_comments')
            ->where('news_id', $newsId)
            ->orderBy('created_at', 'DESC')
            ->get()->getResultArray();
    }

    public function addComment($data)
    {
        return $this->db->table('news_comments')->insert($data);
    }

    public function getTags($newsId)
    {
        return $this->db->table('news_tags nt')
            ->select('nt.*')
            ->join('news_tag_map ntm', 'ntm.tag_id = nt.id')
            ->where('ntm.news_id', $newsId)
            ->get()->getResultArray();
    }

    public function getCategoryBySlug($slug)
    {
        return $this->db->table('news_categories')
            ->where('slug', $slug)
            ->get()
            ->getRowArray();
    }

    public function getRelatedNews($newsId, $limit = 3)
    {
        return $this->select('news.*')
            ->join('news_categories', 'news_categories.id = news.news_category_id', 'left')
            ->where('news.id !=', $newsId)
            ->where('news.news_category_id', function($subquery) use ($newsId) {
                $subquery->select('news_category_id')
                         ->from('news')
                         ->where('id', $newsId);
            })
            ->orderBy('created_at', 'DESC')
            ->limit($limit)
            ->get()->getResultArray();
    }

    public function getNewsByTag($tagId, $limit = 6, $offset = 0)
    {
        return $this->select('news.*')
            ->join('news_tag_map', 'news.id = news_tag_map.news_id')
            ->where('news_tag_map.tag_id', $tagId)
            ->orderBy('created_at', 'DESC')
            ->findAll($limit, $offset);
    }

    public function getArticlesByCategorySlug($categorySlug)
    {
        return $this->select('news.*, news_categories.name AS category_name')
            ->join('news_categories', 'news_categories.id = news.news_category_id', 'left')
            ->where('news_categories.slug', $categorySlug)
            ->orderBy('created_at', 'DESC')
            ->findAll();
    }

    public function getTagsForCategorySlug($slug)
    {
        return $this->db->table('news_tags nt')
            ->select('nt.*, COUNT(ntm.news_id) as article_count')
            ->join('news_tag_map ntm', 'ntm.tag_id = nt.id')
            ->join('news n', 'n.id = ntm.news_id')
            ->join('news_categories nc', 'nc.id = n.news_category_id')
            ->where('nc.slug', $slug)
            ->groupBy('nt.id')
            ->orderBy('nt.name')
            ->get()
            ->getResultArray();
    }

}
