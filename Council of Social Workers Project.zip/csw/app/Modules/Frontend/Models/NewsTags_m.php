<?php
namespace App\Modules\Frontend\Models;

use CodeIgniter\Model;

class NewsTags_m extends Model
{
    protected $table = 'news_tags';
    protected $primaryKey = 'id';
    protected $returnType = 'array';
    protected $allowedFields = ['name', 'slug', 'created_at'];

    // Get all tags
    public function getAllTags()
    {
        return $this->orderBy('name', 'ASC')->findAll();
    }
}
