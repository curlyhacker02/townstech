<?php
namespace App\Modules\Frontend\Models;

use CodeIgniter\Model;

class FrontendSettings_m extends Model
{
    protected $table = 'settings';

    public function getAll()
    {
        $result = $this->findAll();
        $settings = [];

        foreach ($result as $item) {
            $settings[$item['key']] = $item['value'];
        }

        return $settings;
    }

    public function get($key)
    {
        return $this->where('key', $key)->first()['value'] ?? null;
    }
}
