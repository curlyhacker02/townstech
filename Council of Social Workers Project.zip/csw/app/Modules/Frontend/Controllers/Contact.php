<?php
namespace App\Modules\Frontend\Controllers;

use App\Controllers\BaseController;
use App\Modules\Frontend\Models\Frontend_m;

class Frontend_c extends BaseFrontendController

{
    protected $frontendModel;

   public function submitContactForm()
{
    $db = \Config\Database::connect();
    $request = \Config\Services::request();

    // Get form data
    $name = $request->getPost('name');
    $email = $request->getPost('email');
    $subject = $request->getPost('subject');
    $message = $request->getPost('message');

    // Validate inputs
    if (empty($name) || empty($email) || empty($subject) || empty($message)) {
        session()->setFlashdata('error', 'All fields are required.');
        return redirect()->to('/contact');
    }

    // Insert data into the database
    $builder = $db->table('contact_messages');
    $data = [
        'name' => $name,
        'email' => $email,
        'subject' => $subject,
        'message' => $message
    ];

    if ($builder->insert($data)) {
        session()->setFlashdata('success', 'Your message has been sent successfully.');
    } else {
        session()->setFlashdata('error', 'There was an error sending your message.');
    }

    return redirect()->to('/contact');
}
eturn view('App\Modules\Frontend\Views\contact', $data);
    }
}
