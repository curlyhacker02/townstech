<?php

namespace App\Modules\Frontend\Controllers;

use App\Controllers\BaseController;
use App\Modules\Frontend\Models\Faq_m;

class Faq_c extends BaseController
{
    public function index()
    {
        $faqModel = new Faq_m();
        $data['faqs'] = $faqModel->findAll();

        return view('App\Modules\Frontend\Views\faq', $data);
    }
}
