<?php

namespace App\Modules\Frontend\Controllers;

use App\Controllers\BaseController;
use App\Modules\Home\Models\Home_m;
use App\Modules\Testimonials\Models\Testimonials_m;
use Config\Database;

class Home_c extends BaseController
{
    public function index()
    {
        
        $homeModel = new Home_m();
        $testimonialModel = new Testimonials_m();
        $db = Database::connect();

        $home = $homeModel->first();

        $registeredUsers = $db->table('users')->countAllResults(); // Count from users table

        $data = [
            'home' => $home,
            'registered_users' => $registeredUsers,
            'testimonials' => $testimonialModel->where('status', 'approved')->findAll(),
        ];

        return view('App\Modules\Frontend\Views\home', $data);
    }
      public function submitTestimonial()
    {
        $testimonialModel = new Testimonials_m();

        // Validate the input
        $validationRules = [
            'name'   => 'required|min_length[3]',
            'role'   => 'required',
            'message' => 'required',
            'photo'  => 'uploaded[photo]|max_size[photo,2048]|is_image[photo]'
        ];

        if (!$this->validate($validationRules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        // Handle file upload
        $photo = $this->request->getFile('photo');
        if ($photo->isValid() && !$photo->hasMoved()) {
            $photoName = $photo->getRandomName();
            $photo->move(ROOTPATH . 'public/uploads/testimonials/', $photoName);
        }

        // Save testimonial
        $data = [
            'name'    => $this->request->getPost('name'),
            'role'    => $this->request->getPost('role'),
            'photo'   => $photoName,
            'message' => $this->request->getPost('message'),
            'status'  => 'pending' // Testimonials require approval before being displayed
        ];

        $testimonialModel->insert($data);

        return redirect()->to('/')->with('success', 'Your testimonial has been submitted successfully!');
    }
}
