<?php
namespace App\Controllers;

use App\Controllers\FrontendController;
use App\Modules\Frontend\Models\Frontend_m;

class Frontend_c extends FrontendController

{
    protected $frontendModel;

    public function __construct()
    {
        $this->frontendModel = new Frontend_m();
    }

    public function contact()
    {
        $data['info'] = $this->frontendModel->getContactInfo();

        if ($this->request->getMethod() === 'post') {
            $form = $this->request->getPost(['name', 'email', 'subject', 'message']);
            $form['created_at'] = date('Y-m-d H:i:s');
            $this->frontendModel->saveContactMessage($form);

            return redirect()->to('/contact')->with('success', 'Message sent successfully!');
        }

        // Use view() instead of $this->render() since this controller does not have a render() method
        return view('frontend/pages/contact', $data);
    }
}
