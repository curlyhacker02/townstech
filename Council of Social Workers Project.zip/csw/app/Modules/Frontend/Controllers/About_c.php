<?php

namespace App\Modules\Frontend\Controllers;

use App\Controllers\BaseController;
use App\Modules\About\Models\About_m;

class About_c extends BaseController
{
    protected $aboutModel;

    public function __construct()
    {
        $this->aboutModel = new About_m();
    }

    public function index()
    {
        $data['about'] = $this->aboutModel->first(); // Assumes one record

        return view('App\Modules\Frontend\Views\about', $data);
    }
}
