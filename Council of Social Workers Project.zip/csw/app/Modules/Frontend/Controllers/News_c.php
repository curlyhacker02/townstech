<?php

namespace App\Controllers;

use App\Controllers\FrontendController;
use App\Modules\Frontend\Models\News_m;

class News_c extends FrontendController
{
    protected $newsModel;

    public function __construct()
    {
        $this->newsModel = new News_m();
    }

    public function index()
    {
        helper('text');

        $tagsModel = new \App\Modules\Frontend\Models\NewsTags_m();
        $tags = $tagsModel->getAllTags();

        $data['tags'] = $tags;

        
        $page = (int) ($this->request->getVar('page') ?? 1);
        $perPage = 6;

        $data['newsList'] = $this->newsModel->getPagedNews($perPage, $page);
        $data['pager'] = $this->newsModel->getPager();
        $data['categories'] = $this->newsModel->getCategoriesWithCount();
        $data['recentPosts'] = $this->newsModel->getRecentPosts();
        return view('App\Modules\Frontend\Views\news/index', $data);
    }

    public function show($slug)
    {
        helper('text');

        $data['news'] = $this->newsModel->getNewsBySlug($slug);
        if (!$data['news']) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound("News not found");
        }
        $data['comments'] = $this->newsModel->getComments($data['news']['id']);
        $data['tags'] = $this->newsModel->getTags($data['news']['id']);
        $data['categories'] = $this->newsModel->getCategoriesWithCount();
        $data['recentPosts'] = $this->newsModel->getRecentPosts();

        if ($this->request->getMethod() === 'post') {
            $this->newsModel->addComment([
                'news_id' => $data['news']['id'],
                'name' => $this->request->getPost('name'),
                'email' => $this->request->getPost('email'),
                'comment' => $this->request->getPost('comment'),
                'created_at' => date('Y-m-d H:i:s'),
            ]);
            return redirect()->to(current_url() . '#comments')->with('success', 'Comment added');
        }

        return view('App\Modules\Frontend\Views\news\show', $data);
    }

        public function postComment($slug)
{
    $request = service('request');
    $commentModel = new \App\Modules\Frontend\Models\NewsComments_m();
    $newsModel = new \App\Modules\Frontend\Models\News_m();

    $newsItem = $newsModel->where('slug', $slug)->first();

    if (!$newsItem) {
        throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
    }

    $data = [
        'news_id' => $newsItem['id'],
        'name'    => $request->getPost('name'),
        'email'   => $request->getPost('email'),
        'comment' => $request->getPost('comment'),
    ];

    $commentModel->insert($data);

    return redirect()->to(site_url('news/' . $slug) . '#comments')->with('success', 'Comment posted!');
}

public function sidebarData()
{
    $tagsModel = new \App\Modules\Frontend\Models\NewsTags_m();
    $tags = $tagsModel->getAllTags();

    return $tags;
}

public function tag($slug)
{
    $tagsModel = new \App\Modules\Frontend\Models\NewsTags_m();
    $newsModel = new \App\Modules\Frontend\Models\News_m();

    $tag = $tagsModel->where('slug', $slug)->first();

    if (!$tag) {
        throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound("Tag not found");
    }

    $news = $newsModel->getNewsByTag($tag['id']);  // You'll need to implement this method

    return view('App\Modules\Frontend\Views\news/tag', [
    'tag' => $tag,
    'news' => $news
]);

}


}
