<?php

namespace App\Modules\Frontend\Controllers;

use App\Controllers\BaseController;
use App\Modules\Frontend\Models\DownloadModel;

class DownloadController extends BaseController
{
    public function index()
    {
        $model = new DownloadModel();
        $data = $this->loadCommonData();
        $data['downloads_by_category'] = $model->getDownloadsGroupedByCategory();

        return view('App\Modules\Frontend\Views\downloads', $data);
    }
}
