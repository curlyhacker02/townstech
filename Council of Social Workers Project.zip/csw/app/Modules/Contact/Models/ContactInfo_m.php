<?php
namespace App\Modules\Contact\Models;
use CodeIgniter\Model;

class Contactinfo_m extends Model
{
    protected $table = 'contact_info';
    protected $allowedFields = ['slug', 'address', 'phone', 'email'];
    protected $useTimestamps = true;
}
