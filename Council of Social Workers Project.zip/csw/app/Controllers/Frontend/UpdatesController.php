<?php

namespace App\Controllers\Frontend;

use App\Controllers\FrontendController;
use App\Modules\Frontend\Models\News_m;

class UpdatesController extends FrontendController
{
    protected $newsModel;

    public function __construct()
    {
        helper('text');
        $this->newsModel = new News_m();
    }

    public function index()
    {
        // Get all articles
        $articles = $this->newsModel->findAll();
        $recentPosts = $this->newsModel->orderBy('created_at', 'DESC')->limit(5)->findAll();
        $categories = $this->newsModel->getCategoriesWithCount();
        
        // Get tags for the first article as a sample
        $tags = !empty($articles) ? $this->newsModel->getTags($articles[0]['id']) : [];

        return $this->render('frontend/pages/updates', [
            'page_title' => 'Updates',
            'articles' => $articles,
            'recentPosts' => $recentPosts,
            'categories' => $categories,
            'tags' => $tags
        ]);
    }

    public function view($slug = null)
    {
        if ($slug === null) {
            return redirect()->to('/updates');
        }

        $article = $this->newsModel->getNewsBySlug($slug);

        if ($article === null) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        // Get related articles
        $relatedArticles = $this->newsModel->getRelatedNews($article['id']);

        // Get author information
        $author = [
            'name' => $article['author_name'] ?? 'Admin',
            'photo' => $article['author_image'] ?? base_url('assets/img/blog/blog-author.jpg'),
            'twitter' => $article['author_twitter'] ?? '#',
            'facebook' => $article['author_facebook'] ?? '#',
            'instagram' => $article['author_instagram'] ?? '#',
            'bio' => $article['author_bio'] ?? 'Author of the article'
        ];

        // Get comments
        $comments = $this->newsModel->getComments($article['id']);

        // Get categories
        $categories = $this->newsModel->getCategoriesWithCount();
        
        // Get recent posts
        $recentPostsWidget = $this->newsModel->getRecentPosts(5);

        // Check if user is logged in
        $isLoggedIn = session()->get('isLoggedIn') ?? false;

        return $this->render('frontend/pages/updatesDetails', [
            'page_title' => $article['title'],
            'article' => $article,
            'relatedArticles' => $relatedArticles,
            'tags' => $this->newsModel->getTags($article['id']),
            'author' => $author,
            'comments' => $comments,
            'categories' => $categories,
            'recentPostsWidget' => $recentPostsWidget,
            'isLoggedIn' => $isLoggedIn
        ]);
    }

    public function category($categorySlug)
    {
        // Get category and its articles
        $category = $this->newsModel->getCategoryBySlug($categorySlug);
        if (!$category) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        $articles = $this->newsModel->getArticlesByCategorySlug($categorySlug);
        $recentPosts = $this->newsModel->orderBy('created_at', 'DESC')->limit(5)->findAll();
        $categories = $this->newsModel->getCategoriesWithCount();
        $tags = $this->newsModel->getTagsForCategorySlug($categorySlug);

        return $this->render('frontend/pages/category', [
            'page_title' => $category['name'],
            'category' => $category,
            'articles' => $articles,
            'recentPosts' => $recentPosts,
            'categories' => $categories,
            'tags' => $tags
        ]);
    }
}
