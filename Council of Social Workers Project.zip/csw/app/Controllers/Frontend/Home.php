<?php

namespace App\Controllers\Frontend;

use App\Controllers\FrontendController;

class Home extends FrontendController
{
    public function index()
    {
        $newsModel = new \App\Modules\Frontend\Models\News_m();
        // Fetch latest 5 articles for home page
        $articles = $newsModel->orderBy('created_at', 'DESC')
            ->select('id, title, slug, image, content, created_at')
            ->findAll(5);

        // Fetch testimonials from database
        $testimonialsModel = new \App\Modules\Testimonials\Models\Testimonials_m();
        $testimonials = $testimonialsModel
            ->where('status', 'approved')
            ->orderBy('created_at', 'DESC')
            ->findAll(3); // Fetch 3 testimonials

        // If no testimonials found in DB, use default ones
        if (empty($testimonials)) {
            $testimonials = [
                [
                    'photo' => 'https://via.placeholder.com/50',
                    'text' => '"The ZCSW Portal has transformed how I connect with colleagues and access professional resources. It\'s an invaluable tool for any social worker in Zimbabwe."',
                    'name' => 'Tendai Moyo',
                    'role' => 'Clinical Social Worker, Harare'
                ],
                [
                    'photo' => 'https://via.placeholder.com/50',
                    'text' => '"The training opportunities through ZCSW have helped me stay current in my practice. I\'ve attended several workshops that directly improved my work with clients."',
                    'name' => 'Sarah Chikwava',
                    'role' => 'Child Welfare Specialist, Bulawayo'
                ],
                [
                    'photo' => 'https://via.placeholder.com/50',
                    'text' => '"As a new social worker, the mentorship connections I made through ZCSW have been invaluable. The portal makes it easy to find support and guidance."',
                    'name' => 'Tinashe Banda',
                    'role' => 'Community Social Worker, Mutare'
                ]
            ];
        }

        return $this->render('frontend/pages/home', [
            'page_title' => 'Welcome to the Homepage',
            'articles' => $articles,
            'testimonials' => $testimonials
        ]);
    } 

    public function support()
    {
        $faqModel = new \App\Modules\Frontend\Models\Faq_m();
        $faqs = $faqModel->findAll();
        return $this->render('frontend/pages/support', [
            'page_title' => 'Help & Support',
            'faqs' => $faqs,
        ]);
    }

    public function downloads()
    {
        $downloadsModel = new \App\Modules\Downloads\Models\Downloads_m();
        $categoryModel = new \App\Modules\Downloads\Models\DownloadCategory_m();

        // Fetch all categories
        $categories = $categoryModel->orderBy('name', 'ASC')->findAll();

        // Fetch all downloads and join with category name
        $downloadsRaw = $downloadsModel
            ->select('downloads.*, download_categories.name as category')
            ->join('download_categories', 'download_categories.id = downloads.download_category_id', 'left')
            ->findAll();

        // Optional: filter by search query
        $search = isset($_GET['q']) ? trim($_GET['q']) : '';
        $downloads = $downloadsRaw;
        if ($search !== '') {
            $downloads = array_filter($downloadsRaw, function($doc) use ($search) {
                return stripos($doc['title'], $search) !== false
                    || stripos($doc['description'] ?? '', $search) !== false
                    || stripos($doc['category'], $search) !== false;
            });
        }

        // Add file URL for each download, only if 'file' key exists
        foreach ($downloads as &$doc) {
            $doc['url'] = !empty($doc['file']) ? base_url('uploads/downloads/' . $doc['file']) : '';
        }
        unset($doc);

        return $this->render('frontend/pages/downloads', [
            'page_title' => 'Downloads',
            'downloads' => $downloads,
            'categories' => $categories,
            'search' => $search,
        ]);
    }
    
    public function about()
    {
        $aboutModel = new \App\Modules\About\Models\About_m();
        $about = $aboutModel->first();
        $whyUsSlides = [
            [
                'title' => 'Vision',
                'content' => $about['vision'] ?? '',
            ],
            [
                'title' => 'Mission',
                'content' => $about['mission'] ?? '',
            ],
            [
                'title' => 'Values',
                'content' => $about['core_values'] ?? '',
            ],
        ];
        return $this->render('frontend/pages/about', [
            'page_title' => 'About Us',
            'about' => $about,
            'whyUsSlides' => $whyUsSlides,
        ]);
    }

    public function contact()
    {
        // Get contact info
        $contactModel = new \App\Modules\Contact\Models\Contact_m();
        $contact = $contactModel->getInfo('contact');
        
        // Handle phone numbers
        if (!empty($contact['phones']) && is_string($contact['phones'])) {
            $contact['phones'] = array_map('trim', explode(',', $contact['phones']));
        } elseif (empty($contact['phones'])) {
            $contact['phones'] = [];
        }

        // Handle form submission
        if ($this->request->getMethod() === 'post') {
            $data = [
                'name'    => $this->request->getPost('name'),
                'email'   => $this->request->getPost('email'),
                'subject' => $this->request->getPost('subject'),
                'message' => $this->request->getPost('message'),
            ];

            // Log the form data
            log_message('info', 'Contact form submission received: ' . json_encode($data));

            // Validate the data
            $rules = [
                'name' => 'required|min_length[2]|max_length[100]',
                'email' => 'required|valid_email|max_length[100]',
                'subject' => 'required|min_length[3]|max_length[255]',
                'message' => 'required|min_length[10]'
            ];

            if (!$this->validate($rules)) {
                log_message('error', 'Contact form validation failed: ' . json_encode($this->validator->getErrors()));
                session()->setFlashdata('error', 'Please fix the errors in the form.');
                return redirect()->to(base_url('contact'))->withInput();
            }

            try {
                $contactMessages = new \App\Models\ContactMessages();
                
                if ($contactMessages->saveMessage($data)) {
                    log_message('info', 'Contact form saved successfully');
                    session()->setFlashdata('success', 'Thank you for contacting us! We will get back to you soon.');
                    return redirect()->to(base_url('contact'));
                } else {
                    log_message('error', 'Contact form save failed');
                    session()->setFlashdata('error', 'There was an error submitting your message. Please try again later.');
                    return redirect()->to(base_url('contact'))->withInput();
                }
            } catch (\Exception $e) {
                log_message('error', 'Contact form error: ' . $e->getMessage());
                session()->setFlashdata('error', 'An unexpected error occurred. Please try again later.');
                return redirect()->to(base_url('contact'))->withInput();
            }
        }

        return $this->render('frontend/pages/contact', [
            'page_title' => 'Contact Us',
            'contact' => $contact,
        ]);
    }

    public function Updates()
    {
        $newsModel = new \App\Modules\Frontend\Models\News_m();
        $tagsModel = new \App\Modules\Frontend\Models\NewsTags_m();

        $categories = $newsModel->getCategoriesWithCount();
        $tags = $tagsModel->getAllTags();

        // Search functionality
        $q = $this->request->getGet('q');
        $page = (int)($this->request->getGet('page') ?? 1);
        if ($q) {
            $articles = $newsModel
                ->like('news.title', $q)
                ->orLike('news.content', $q)
                ->orLike('news.slug', $q)
                ->select('news.*, news_categories.name AS category_name')
                ->join('news_categories', 'news_categories.id = news.news_category_id', 'left')
                ->orderBy('news.created_at', 'DESC')
                ->paginate(6, 'group1', $page);
        } else {
            $articles = $newsModel->getPagedNews(6, $page);
        }
        $recentPosts = $newsModel->getRecentPosts(5);
        $pager = $newsModel->getPager();

        return $this->render('frontend/pages/updates', [
            'page_title' => 'Updates',
            'categories' => $categories,
            'tags' => $tags,
            'articles' => $articles,
            'recentPosts' => $recentPosts,
            'pager' => $pager,
        ]);
    }

    public function updatesDetails($slug = null)
    {
        $newsModel = new \App\Modules\Frontend\Models\News_m();
        $tagsModel = new \App\Modules\Frontend\Models\NewsTags_m();
        if (!$slug) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound('Article not found');
        }
        $article = $newsModel->getNewsBySlug($slug);
        if (!$article) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound('Article not found');
        }
        $comments = $newsModel->getComments($article['id']);
        $tags = $newsModel->getTags($article['id']); // Use getTags from News_m, not from NewsTags_m
        $categories = $newsModel->getCategoriesWithCount();
        $recentPostsWidget = $newsModel->getRecentPosts(5);
        $author = [
            'name' => $article['author_name'] ?? '',
            'photo' => $article['author_image'] ?? 'assets/img/blog/blog-author.jpg',
            'bio' => $article['author_bio'] ?? '',
            'twitter' => $article['author_twitter'] ?? '#',
            'facebook' => $article['author_facebook'] ?? '#',
            'instagram' => $article['author_instagram'] ?? '#',
        ];
        return $this->render('frontend/pages/updatesDetails', [
            'article' => $article,
            'comments' => $comments,
            'tags' => $tags,
            'categories' => $categories,
            'recentPostsWidget' => $recentPostsWidget,
            'author' => $author,
        ]);
    }

    public function login()
    {
        // Render a login page or redirect to actual auth module if exists
        return $this->render('frontend/pages/login', [
            'page_title' => 'Login',
        ]);
    }

    public function register()
    {
        // Render a register page or redirect to actual registration module if exists
        return $this->render('frontend/pages/register', [
            'page_title' => 'Register',
        ]);
    }
}

