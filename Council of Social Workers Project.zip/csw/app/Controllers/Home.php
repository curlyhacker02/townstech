<?php

namespace App\Controllers\Frontend;

use App\Controllers\FrontendController;

class Home extends FrontendController
{
    public function index()
    {
        return $this->render('frontend/pages/home', [
            'page_title' => 'Welcome to the Homepage',
        ]);
    } 

    public function support()
    {
        return $this->render('frontend/pages/support', [
            'page_title' => 'Help & Support',
        ]);
    }

    public function downloads()
    {
        return $this->render('frontend/pages/downloads', [
            'page_title' => 'Downsloads',
        ]);
    }
    
    public function about()
    {
        return $this->render('frontend/pages/about', [
            'page_title' => 'About Us',
        ]);
    }

    public function contact()
    {
        return $this->render('frontend/pages/contact', [
            'page_title' => 'Contact Us',
        ]);
    }

    public function Updates()
    {
        return $this->render('frontend/pages/updates', [
            'page_title' => 'Updates',
        ]);
    }
}

